import{a as e,c as t,l as n,n as r,o as i,r as a,s as o,u as s}from"./dff-CEhadQ32.js";var c=class{bones;holdPositions;holdQuats;lastPositions;lastQuats;local=new Float32Array(16);position=new Float32Array(3);positionB=new Float32Array(3);quat=new Float32Array(4);quatB=new Float32Array(4);worlds;constructor(e){this.bones=e,this.worlds=new Float32Array(e.length*16),this.lastQuats=new Float32Array(e.length*4),this.lastPositions=new Float32Array(e.length*3),this.holdQuats=new Float32Array(e.length*4),this.holdPositions=new Float32Array(e.length*3),e.forEach((e,t)=>{this.lastQuats.set(e.bindRotation,t*4),this.lastPositions.set(e.bindPosition,t*3)}),this.holdQuats.set(this.lastQuats),this.holdPositions.set(this.lastPositions)}holdPose(){this.holdQuats.set(this.lastQuats),this.holdPositions.set(this.lastPositions)}sample(e,t,n,r=1){let i=v(t,e.duration);for(let t=0;t<this.bones.length;t+=1)this.evaluateBone(e,i,t,this.quat,this.position),this.writeBone(t,n,r)}sampleBlended(e,t,n,r,i,a,o=1){if(i<=0){this.sample(e,t,a,o);return}if(i>=1){this.sample(n,r,a,o);return}let s=v(t,e.duration),c=v(r,n.duration);for(let t=0;t<this.bones.length;t+=1)this.evaluateBone(e,s,t,this.quat,this.position),this.evaluateBone(n,c,t,this.quatB,this.positionB),this.blendScratch(i),this.writeBone(t,a,o)}sampleFromHold(e,t,n,r,i=1){if(n>=1){this.sample(e,t,r,i);return}let a=v(t,e.duration);for(let t=0;t<this.bones.length;t+=1)this.quat.set(this.holdQuats.subarray(t*4,t*4+4)),this.position.set(this.holdPositions.subarray(t*3,t*3+3)),this.evaluateBone(e,a,t,this.quatB,this.positionB),this.blendScratch(n),this.writeBone(t,r,i)}blendScratch(e){_(this.quat,this.quatB,e);for(let t=0;t<3;t+=1)this.position[t]+=(this.positionB[t]-this.position[t])*e}evaluateBone(e,t,n,r,i){let a=this.bones[n],o=e.tracks[n];o&&o.times.length>0?h(o,t,r):r.set(a.bindRotation),o?.positions&&o.times.length>0?m(o,t,i):i.set(a.bindPosition)}writeBone(e,t,n){let r=this.bones[e];this.lastQuats.set(this.quat,e*4),this.lastPositions.set(this.position,e*3),d(this.local,this.quat,this.position);let i=this.worlds.subarray(e*16,e*16+16);r.parent>=0?p(i,this.worlds.subarray(r.parent*16,r.parent*16+16),this.local):i.set(this.local),p(t.subarray((n+e)*16,(n+e)*16+16),i,r.inverseBind)}};function l(e,t,n){d(e,t,n)}function u(e,t,n){p(e,t,n)}function d(e,t,n){let[r,i,a,o]=[t[0],t[1],t[2],t[3]],s=r+r,c=i+i,l=a+a,u=r*s,d=r*c,f=r*l,p=i*c,m=i*l,h=a*l,g=o*s,_=o*c,v=o*l;e[0]=1-(p+h),e[1]=d+v,e[2]=f-_,e[3]=0,e[4]=d-v,e[5]=1-(u+h),e[6]=m+g,e[7]=0,e[8]=f+_,e[9]=m-g,e[10]=1-(u+p),e[11]=0,e[12]=n[0],e[13]=n[1],e[14]=n[2],e[15]=1}function f(e,t,n){e[0]=t[n],e[1]=t[n+1],e[2]=t[n+2],e[3]=t[n+3]}function p(e,t,n){for(let r=0;r<4;r+=1){let i=n[r*4],a=n[r*4+1],o=n[r*4+2],s=n[r*4+3];e[r*4]=t[0]*i+t[4]*a+t[8]*o+t[12]*s,e[r*4+1]=t[1]*i+t[5]*a+t[9]*o+t[13]*s,e[r*4+2]=t[2]*i+t[6]*a+t[10]*o+t[14]*s,e[r*4+3]=t[3]*i+t[7]*a+t[11]*o+t[15]*s}}function m(e,t,n){let r=e.positions;if(!r)return;let i=e.times,a=i.length-1;if(t<=i[0]){n.set(r.slice(0,3));return}if(t>=i[a]){n.set(r.slice(a*3,a*3+3));return}let o=0,s=a;for(;s-o>1;){let e=o+s>>1;i[e]<=t?o=e:s=e}let c=i[s]-i[o]||1,l=(t-i[o])/c;for(let e=0;e<3;e+=1)n[e]=r[o*3+e]+(r[s*3+e]-r[o*3+e])*l}function h(e,t,n){let r=e.times,i=r.length-1;if(t<=r[0]){f(n,e.quats,0);return}if(t>=r[i]){f(n,e.quats,i*4);return}let a=0,o=i;for(;o-a>1;){let e=a+o>>1;r[e]<=t?a=e:o=e}let s=(t-r[a])/(r[o]-r[a]||1);g(n,e.quats,a*4,o*4,s)}function g(e,t,n,r,i){let a=t[r],o=t[r+1],s=t[r+2],c=t[r+3],l=t[n],u=t[n+1],d=t[n+2],f=t[n+3],p=l*a+u*o+d*s+f*c;p<0&&(p=-p,a=-a,o=-o,s=-s,c=-c);let m,h;if(1-p>1e-6){let e=Math.acos(Math.min(1,p)),t=Math.sin(e);m=Math.sin((1-i)*e)/t,h=Math.sin(i*e)/t}else m=1-i,h=i;e[0]=m*l+h*a,e[1]=m*u+h*o,e[2]=m*d+h*s,e[3]=m*f+h*c}function _(e,t,n){let r=t[0],i=t[1],a=t[2],o=t[3],s=e[0]*r+e[1]*i+e[2]*a+e[3]*o;s<0&&(s=-s,r=-r,i=-i,a=-a,o=-o);let c,l;if(1-s>1e-6){let e=Math.acos(Math.min(1,s)),t=Math.sin(e);c=Math.sin((1-n)*e)/t,l=Math.sin(n*e)/t}else c=1-n,l=n;e[0]=c*e[0]+l*r,e[1]=c*e[1]+l*i,e[2]=c*e[2]+l*a,e[3]=c*e[3]+l*o}function v(e,t){return t>0?e%t:0}function y(e,t,n=2){let r=e.getContext(`webgpu`);if(!r)throw Error(`canvas.getContext("webgpu") returned null`);let i=Math.min(window.devicePixelRatio||1,n);return e.width=Math.max(1,Math.floor(e.clientWidth*i)),e.height=Math.max(1,Math.floor(e.clientHeight*i)),r.configure({alphaMode:`opaque`,device:t.device,format:t.presentationFormat,viewFormats:[t.colorFormat]}),r}function b(e,t,n=typeof window>`u`?1:window.devicePixelRatio){return{adapter:e.adapterInfo,css:`${t.clientWidth}x${t.clientHeight}`,dpr:n,featureLevel:e.featureLevel,features:e.adapterFeatures,missing:[`texture-compression-astc`,`texture-compression-bc`,`texture-compression-etc2`,`timestamp-query`].filter(t=>!e.adapterFeatures.includes(t))}}async function x(){if(!navigator.gpu)throw Error(`WebGPU is not available in this browser (WebGPU is required — there is no fallback renderer)`);let e=await navigator.gpu.requestAdapter({powerPreference:`high-performance`});if(!e)throw Error(`WebGPU adapter request failed (blocklisted GPU or disabled flag?)`);let t=[`texture-compression-astc`,`texture-compression-bc`,`texture-compression-etc2`,`timestamp-query`].filter(t=>e.features.has(t)),n=e.features.has(`texture-compression-bc`),r=e.features.has(`timestamp-query`),i=await e.requestDevice({requiredFeatures:t}),a=e.info,o=navigator.gpu.getPreferredCanvasFormat(),s=[...e.features].sort();return{adapterFeatures:s,adapterInfo:`${a?.vendor??`?`} ${a?.architecture??``}`.trim(),colorFormat:`${o}-srgb`,device:i,featureLevel:s.includes(`core-features-and-limits`)?`core`:`compatibility`,hasBc:n,hasTimestamps:r,presentationFormat:o}}function S(e,t){let n=[[t[0],t[4],t[8],t[12]],[t[1],t[5],t[9],t[13]],[t[2],t[6],t[10],t[14]],[t[3],t[7],t[11],t[15]]],r=[[n[3][0]+n[0][0],n[3][1]+n[0][1],n[3][2]+n[0][2],n[3][3]+n[0][3]],[n[3][0]-n[0][0],n[3][1]-n[0][1],n[3][2]-n[0][2],n[3][3]-n[0][3]],[n[3][0]+n[1][0],n[3][1]+n[1][1],n[3][2]+n[1][2],n[3][3]+n[1][3]],[n[3][0]-n[1][0],n[3][1]-n[1][1],n[3][2]-n[1][2],n[3][3]-n[1][3]],[n[2][0],n[2][1],n[2][2],n[2][3]],[n[3][0]-n[2][0],n[3][1]-n[2][1],n[3][2]-n[2][2],n[3][3]-n[2][3]]];for(let t=0;t<6;t+=1){let[n,i,a,o]=r[t],s=1/(Math.hypot(n,i,a)||1);e[t*4]=n*s,e[t*4+1]=i*s,e[t*4+2]=a*s,e[t*4+3]=o*s}return e}function C(e,t,n,r,i){for(let a=0;a<6;a+=1)if(e[a*4]*t+e[a*4+1]*n+e[a*4+2]*r+e[a*4+3]<-i)return!1;return!0}function w(){let e=new Float32Array(16);return e[0]=1,e[5]=1,e[10]=1,e[15]=1,e}function T(e,t){let n=t[0],r=t[1],i=t[2],a=t[3],o=t[4],s=t[5],c=t[6],l=t[7],u=t[8],d=t[9],f=t[10],p=t[11],m=t[12],h=t[13],g=t[14],_=t[15],v=n*s-r*o,y=n*c-i*o,b=n*l-a*o,x=r*c-i*s,S=r*l-a*s,C=i*l-a*c,T=u*h-d*m,E=u*g-f*m,D=u*_-p*m,O=d*g-f*h,k=d*_-p*h,A=f*_-p*g,j=v*A-y*k+b*O+x*D-S*E+C*T;return j===0?(e.set(w()),e):(j=1/j,e[0]=(s*A-c*k+l*O)*j,e[1]=(i*k-r*A-a*O)*j,e[2]=(h*C-g*S+_*x)*j,e[3]=(f*S-d*C-p*x)*j,e[4]=(c*D-o*A-l*E)*j,e[5]=(n*A-i*D+a*E)*j,e[6]=(g*b-m*C-_*y)*j,e[7]=(u*C-f*b+p*y)*j,e[8]=(o*k-s*D+l*T)*j,e[9]=(r*D-n*k-a*T)*j,e[10]=(m*S-h*b+_*v)*j,e[11]=(d*b-u*S-p*v)*j,e[12]=(s*E-o*O-c*T)*j,e[13]=(n*O-r*E+i*T)*j,e[14]=(h*y-m*x-g*v)*j,e[15]=(u*x-d*y+f*v)*j,e)}function E(e,t,n,r){let i=t[0]-n[0],a=t[1]-n[1],o=t[2]-n[2],s=Math.hypot(i,a,o)||1,c=[i/s,a/s,o/s],l=r[1]*c[2]-r[2]*c[1],u=r[2]*c[0]-r[0]*c[2],d=r[0]*c[1]-r[1]*c[0];s=Math.hypot(l,u,d)||1;let f=[l/s,u/s,d/s],p=[c[1]*f[2]-c[2]*f[1],c[2]*f[0]-c[0]*f[2],c[0]*f[1]-c[1]*f[0]];return e[0]=f[0],e[1]=p[0],e[2]=c[0],e[3]=0,e[4]=f[1],e[5]=p[1],e[6]=c[1],e[7]=0,e[8]=f[2],e[9]=p[2],e[10]=c[2],e[11]=0,e[12]=-(f[0]*t[0]+f[1]*t[1]+f[2]*t[2]),e[13]=-(p[0]*t[0]+p[1]*t[1]+p[2]*t[2]),e[14]=-(c[0]*t[0]+c[1]*t[1]+c[2]*t[2]),e[15]=1,e}function D(e,t,n){for(let r=0;r<4;r+=1){let i=n[r*4],a=n[r*4+1],o=n[r*4+2],s=n[r*4+3];for(let n=0;n<4;n+=1)e[r*4+n]=t[n]*i+t[4+n]*a+t[8+n]*o+t[12+n]*s}return e}function O(e,t,n,r,i){return e.fill(0),e[0]=1/(t*n),e[5]=1/t,e[10]=1/(r-i),e[14]=r/(r-i),e[15]=1,e}function k(e,t,n,r,i){let a=1/Math.tan(t/2);return e.fill(0),e[0]=a/n,e[5]=a,e[10]=i/(r-i),e[11]=-1,e[14]=i*r/(r-i),e}function A(e,t,n,r,i,a){let o=t-e[0],s=n-e[1],c=r-e[2],l=a+i;return o*o+s*s+c*c>=l*l}var j=class{bytes=new Map;counts=new Map;device;constructor(e){this.device=e}createBuffer(e,t){let n=this.device.createBuffer(t);return this.track(e,t.size),n}createTexture(e,t,n){let r=this.device.createTexture(t);return this.track(e,n),r}destroyBuffer(e,t){this.track(e,-t.size,-1),t.destroy()}destroyTexture(e,t,n){this.track(e,-n,-1),t.destroy()}ledger(){let e={};for(let t of[`cellIndex`,`cellVertex`,`target`,`texture`,`uniform`])e[t]={bytes:this.bytes.get(t)??0,count:this.counts.get(t)??0};return e}totalBytes(){let e=0;for(let t of this.bytes.values())e+=t;return e}track(e,t,n=1){this.bytes.set(e,(this.bytes.get(e)??0)+t),this.counts.set(e,(this.counts.get(e)??0)+n)}},M=class{nested=[];totalMs=0;totals=new Map;add(e,t){this.totals.set(e,(this.totals.get(e)??0)+t),this.totalMs+=t}drain(){let e={byName:[...this.totals.entries()].sort((e,t)=>t[1]-e[1]),totalMs:this.totalMs};return this.totals.clear(),this.totalMs=0,e}measure(e,t){let n=performance.now();this.nested.push(0);try{return t()}finally{let t=performance.now()-n,r=this.nested.pop()??0;this.add(e,Math.max(0,t-r)),this.nested.length>0&&(this.nested[this.nested.length-1]+=t)}}},ee=new M;function te(e,t){let n=new Map;for(let[t,r]of e.byName){let e=t.indexOf(`:`),i=e===-1?t:t.slice(0,e),a=e===-1?t:t.slice(e+1),o=n.get(i)??{count:0,ms:0,worst:a,worstMs:0};o.count+=1,o.ms+=r,r>o.worstMs&&(o.worst=a,o.worstMs=r),n.set(i,o)}return[...[...n.entries()].filter(([,e])=>e.ms>=.05).sort((e,t)=>t[1].ms-e[1].ms).map(([e,t])=>t.count===1?`${e===t.worst?e:`${e}:${t.worst}`} ${t.ms.toFixed(1)}`:`${e} ×${t.count} ${t.ms.toFixed(1)} (worst ${t.worst} ${t.worstMs.toFixed(1)})`),`unattributed ${t.toFixed(1)}`].join(` · `)}var ne=class{available;lastPassMs=0;lastPostMs=0;lastProbeMs=0;device;mapInFlight=!1;probeWritten=!1;querySet=null;readBuffer=null;resolveBuffer=null;constructor(e,t){this.device=e,this.available=t,t&&(this.querySet=e.createQuerySet({count:6,label:`pass`,type:`timestamp`}),this.resolveBuffer=e.createBuffer({label:`ts-resolve`,size:48,usage:GPUBufferUsage.QUERY_RESOLVE|GPUBufferUsage.COPY_SRC}),this.readBuffer=e.createBuffer({label:`ts-read`,size:48,usage:GPUBufferUsage.COPY_DST|GPUBufferUsage.MAP_READ}))}passTimestampWrites(){return this.querySet?{timestampWrites:{beginningOfPassWriteIndex:0,endOfPassWriteIndex:1,querySet:this.querySet}}:{}}postBeginTimestampWrites(){return this.querySet?{timestampWrites:{beginningOfPassWriteIndex:2,querySet:this.querySet}}:{}}postEndTimestampWrites(){return this.querySet?{timestampWrites:{endOfPassWriteIndex:3,querySet:this.querySet}}:{}}postOnlyTimestampWrites(){return this.querySet?{timestampWrites:{beginningOfPassWriteIndex:2,endOfPassWriteIndex:3,querySet:this.querySet}}:{}}probeBeginTimestampWrites(){return this.querySet?(this.probeWritten=!0,{timestampWrites:{beginningOfPassWriteIndex:4,querySet:this.querySet}}):{}}probeEndTimestampWrites(){return this.querySet?{timestampWrites:{endOfPassWriteIndex:5,querySet:this.querySet}}:{}}probeSkipped(){this.probeWritten=!1,this.lastProbeMs=0}read(){let e=this.readBuffer;if(!e||this.mapInFlight)return;this.mapInFlight=!0;let t=this.probeWritten;e.mapAsync(GPUMapMode.READ).then(()=>{let n=new BigUint64Array(e.getMappedRange().slice(0));e.unmap(),this.lastPassMs=Number(n[1]-n[0])/1e6,this.lastPostMs=Math.max(0,Number(n[3]-n[1])/1e6),t&&(this.lastProbeMs=Math.max(0,Number(n[5]-n[4])/1e6)),this.mapInFlight=!1}).catch(()=>{this.mapInFlight=!1})}resolve(e){!this.querySet||!this.resolveBuffer||!this.readBuffer||this.mapInFlight||(e.resolveQuerySet(this.querySet,0,6,this.resolveBuffer,0),e.copyBufferToBuffer(this.resolveBuffer,0,this.readBuffer,0,48))}};function re(e,t){return t.orthoHalfHeight===void 0?k(e,t.fovYRad,t.aspect,t.far,t.near):O(e,t.orthoHalfHeight,t.aspect,t.far,t.near)}var N=class{position=0;get byteLength(){return this.view.byteLength}view;constructor(e){this.view=new DataView(e.buffer,e.byteOffset,e.byteLength)}f32(){let e=this.view.getFloat32(this.position,!0);return this.position+=4,e}i8(){let e=this.view.getInt8(this.position);return this.position+=1,e}i32(){let e=this.view.getInt32(this.position,!0);return this.position+=4,e}raw(e){if(this.position+e>this.view.byteLength)throw RangeError(`raw(${e}) overruns buffer (at ${this.position}/${this.view.byteLength})`);let t=new Uint8Array(this.view.buffer,this.view.byteOffset+this.position,e);return this.position+=e,t}seek(e){if(e<0||e>this.view.byteLength)throw RangeError(`seek(${e}) outside buffer (${this.view.byteLength})`);this.position=e}u8(){let e=this.view.getUint8(this.position);return this.position+=1,e}u16(){let e=this.view.getUint16(this.position,!0);return this.position+=2,e}u32(){let e=this.view.getUint32(this.position,!0);return this.position+=4,e}u64(){let e=this.view.getUint32(this.position,!0),t=this.view.getUint32(this.position+4,!0);this.position+=8;let n=t*2**32+e;if(!Number.isSafeInteger(n))throw RangeError(`u64 ${t}:${e} is not an exact double`);return n}},P=class{get offset(){return this.length}buffer;length=0;view;constructor(e=1024){this.buffer=new ArrayBuffer(e),this.view=new DataView(this.buffer)}align(e){let t=this.length%e;t!==0&&(this.ensure(e-t),this.length+=e-t)}bytes(){return new Uint8Array(this.buffer,0,this.length)}f32(e){this.ensure(4),this.view.setFloat32(this.length,e,!0),this.length+=4}i8(e){this.ensure(1),this.view.setInt8(this.length,e),this.length+=1}i32(e){this.ensure(4),this.view.setInt32(this.length,e,!0),this.length+=4}patchU32(e,t){this.view.setUint32(e,t>>>0,!0)}raw(e){this.ensure(e.byteLength),new Uint8Array(this.buffer,this.length,e.byteLength).set(e),this.length+=e.byteLength}reserveU32(){let e=this.length;return this.u32(0),e}u8(e){this.ensure(1),this.view.setUint8(this.length,e),this.length+=1}u16(e){this.ensure(2),this.view.setUint16(this.length,e,!0),this.length+=2}u32(e){this.ensure(4),this.view.setUint32(this.length,e>>>0,!0),this.length+=4}u64(e){if(!Number.isSafeInteger(e)||e<0)throw RangeError(`u64 ${e} is not an exact non-negative integer`);this.ensure(8),this.view.setUint32(this.length,e>>>0,!0),this.view.setUint32(this.length+4,Math.floor(e/2**32),!0),this.length+=8}ensure(e){if(this.length+e<=this.buffer.byteLength)return;let t=this.buffer.byteLength*2;for(;t<this.length+e;)t*=2;let n=new ArrayBuffer(t);new Uint8Array(n).set(new Uint8Array(this.buffer,0,this.length)),this.buffer=n,this.view=new DataView(n)}};function ie(e){let t=2166136261;if(typeof e==`string`)for(let n=0;n<e.length;n+=1)t^=e.charCodeAt(n)&255,t=Math.imul(t,16777619);else for(let n of e)t^=n,t=Math.imul(t,16777619);return t>>>0}var ae=826495823,F={INDEX16:1},I={AO_SKY_VIS:4,EMISSIVE:8,NIGHT_PRELIT:1,SUN_VIS:16,SWAY:2};function oe(e){let t=new N(e),n=t.u32();if(n!==826495823)throw Error(`not an .oscell (magic 0x${n.toString(16)})`);let r=t.u16(),i=t.u16();if(r!==0)throw Error(`unsupported .oscell major ${r} (reader supports 0)`);let a=t.u32(),o=t.u32(),s=[t.f32(),t.f32(),t.f32(),t.f32()],c=[t.f32(),t.f32(),t.f32()];t.f32();let l=t.u32(),u=t.u32(),d=t.u32(),f=t.u32(),p=t.u32(),m=i>=2?t.u32():0,h=i>=3?t.u32():0,g=i>=6?t.u32():0,_=i>=8?t.u32():0,v=t.u32(),y=t.u32(),b=t.u32(),x=(a&F.INDEX16)!==0;t.seek(v);let S=t.raw(l*36);t.seek(y);let C=t.raw(u*(x?2:4));t.seek(b);let w=[];for(let e=0;e<d;e+=1){let e=t.u8(),n=t.u8(),r=t.u16(),i=t.u32(),a=t.u32(),o=[t.f32(),t.f32(),t.f32(),t.f32()];t.u32(),w.push({bounds:o,indexCount:a,indexOffset:i,pipelineClass:e,side:n,textureArrayRef:r})}let T=de(t,f),E=le(t,p,i),D=fe(t,m),O=ce(t,h),k=pe(t,g);return{bounds:s,breakables:O,channelMask:o,groups:w,index16:x,indexCount:u,indexData:C,lights:E,names:g>0?ue(t):[],objects:T,origin:c,particles:D,placements:k,roadsignQuads:_,vertexCount:l,vertexData:S}}function se(e){if(e.vertexData.byteLength!==e.vertexCount*36)throw Error(`vertexData ${e.vertexData.byteLength} B ≠ vertexCount ${e.vertexCount} × stride 36`);let t=e.index16?2:4;if(e.indexData.byteLength!==e.indexCount*t)throw Error(`indexData ${e.indexData.byteLength} B ≠ indexCount ${e.indexCount} × ${t}`);let n=new P(e.vertexData.byteLength+e.indexData.byteLength+4096);n.u32(ae),n.u16(0),n.u16(8),n.u32(e.index16?F.INDEX16:0),n.u32(e.channelMask);for(let t of e.bounds)n.f32(t);for(let t of e.origin)n.f32(t);n.f32(0),n.u32(e.vertexCount),n.u32(e.indexCount),n.u32(e.groups.length),n.u32(e.objects.length),n.u32(e.lights.length),n.u32(e.particles.length),n.u32(e.breakables.length),n.u32(e.placements.length),n.u32(e.roadsignQuads);let r=n.reserveU32(),i=n.reserveU32(),a=n.reserveU32();n.align(4),n.patchU32(r,n.offset),n.raw(e.vertexData),n.align(4),n.patchU32(i,n.offset),n.raw(e.indexData),n.align(4),n.patchU32(a,n.offset);for(let t of e.groups){n.u8(t.pipelineClass),n.u8(t.side),n.u16(t.textureArrayRef),n.u32(t.indexOffset),n.u32(t.indexCount);for(let e of t.bounds)n.f32(e);n.u32(0)}for(let t of e.objects){if(n.u8(t.kind),n.u8(0),n.u16(0),n.u32(t.params),n.u32(t.groupStart),n.u32(t.groupCount),t.transform.length!==12)throw Error(`object transform must be 12 floats (3×4), got ${t.transform.length}`);for(let e of t.transform)n.f32(e)}me(n,e.lights),ge(n,e.particles);for(let t of e.breakables)n.u32(t.keyHash),n.u32(t.indexOffset),n.u32(t.indexCount);return _e(n,e.placements,e.names),n.bytes()}function ce(e,t){let n=[];for(let r=0;r<t;r+=1){let t=e.u32(),r=e.u32(),i=e.u32();n.push({indexCount:i,indexOffset:r,keyHash:t})}return n}function le(e,t,n){let r=[];for(let i=0;i<t;i+=1){let t=[e.f32(),e.f32(),e.f32()],i=[e.u8(),e.u8(),e.u8(),e.u8()],a=e.f32(),o=e.f32(),s=n>=4?e.u32():0;r.push({color:i,farClip:o,owner:s,position:t,size:a})}return r}function ue(e){let t=e.u16(),n=[];for(let r=0;r<t;r+=1){let t=e.u8(),r=``;for(let n=0;n<t;n+=1)r+=String.fromCharCode(e.u8());n.push(r)}return n}function de(e,t){let n=[];for(let r=0;r<t;r+=1){let t=e.u8();e.u8(),e.u16();let r=e.u32(),i=e.u32(),a=e.u32(),o=[];for(let t=0;t<12;t+=1)o.push(e.f32());n.push({groupCount:a,groupStart:i,kind:t,params:r,transform:o})}return n}function fe(e,t){let n=[];for(let r=0;r<t;r+=1){let t=[e.f32(),e.f32(),e.f32()],r=e.u8(),i=``;for(let t=0;t<r;t+=1)i+=String.fromCharCode(e.u8());n.push({effectName:i,position:t})}return n}function pe(e,t){let n=[];for(let r=0;r<t;r+=1){let t=e.u32(),r=e.u16(),i=e.u16(),a=e.u32(),o=e.u32(),s=[e.f32(),e.f32(),e.f32(),e.f32(),e.f32(),e.f32()];n.push({bounds:s,id:t,indexCount:o,indexOffset:a,nameRef:r,txdRef:i})}return n}function me(e,t){for(let n of t){for(let t of n.position)e.f32(t);for(let t of n.color)e.u8(t);e.f32(n.size),e.f32(n.farClip),e.u32(n.owner)}}function he(e,t){e.u16(t.length);for(let n of t){let t=n.slice(0,255);e.u8(t.length);for(let n=0;n<t.length;n+=1)e.u8(t.charCodeAt(n))}}function ge(e,t){for(let n of t){for(let t of n.position)e.f32(t);let t=n.effectName.slice(0,255);e.u8(t.length);for(let n=0;n<t.length;n+=1)e.u8(t.charCodeAt(n))}}function _e(e,t,n){for(let n of t){if(n.bounds.length!==6)throw Error(`placement bounds must be 6 floats (min+max), got ${n.bounds.length}`);e.u32(n.id),e.u16(n.nameRef),e.u16(n.txdRef),e.u32(n.indexOffset),e.u32(n.indexCount);for(let t of n.bounds)e.f32(t)}t.length>0&&he(e,n)}function ve(e){let t=new N(e),n=t.u32();if(n!==1279480655)throw Error(`not an .oscol (magic 0x${n.toString(16)})`);let r=t.u32();if(r!==2)throw Error(`unsupported .oscol version ${r} (reader supports 2) — re-pack with opensa-pack --bake-collision`);let i=t.u32(),a=[];for(let e=0;e<i;e+=1)a.push(be(t));return{regions:a}}function ye(e){let t=e.u8();return t===255?void 0:t}function be(e){let t=xe(e),n=e.u8()===1,r=e.u8()===1;e.u16();let i=e.u32(),a=e.u32(),o=e.u32(),s=e.u32(),c=e.u32(),l=[];for(let t=0;t<i;t+=1){let t=[e.f32(),e.f32(),e.f32()],n=e.f32(),r=ye(e);Se(e),l.push({center:t,...r===void 0?{}:{material:r},radius:n})}let u=[];for(let t=0;t<a;t+=1){let t=[e.f32(),e.f32(),e.f32()],n=[e.f32(),e.f32(),e.f32()],r=ye(e);Se(e),u.push({max:n,...r===void 0?{}:{material:r},min:t})}let d=new Float32Array(o*3);for(let t=0;t<d.length;t+=1)d[t]=e.f32();let f=new Uint32Array(s);for(let t=0;t<s;t+=1)f[t]=e.u32();let p=n?e.raw(s/3).slice():void 0;n&&Se(e);let m=[];for(let t=0;t<c;t+=1){let t=new Float32Array(16);for(let n=0;n<16;n+=1)t[n]=e.f32();m.push(t)}let h=r?Array.from({length:c},()=>xe(e)):void 0;return{boxes:u,indices:f,...h===void 0?{}:{instanceKeys:h},...p===void 0?{}:{materials:p},name:t,spheres:l,transforms:m,vertices:d}}function xe(e){let t=e.u16(),n=e.raw(t);return Se(e),new TextDecoder().decode(n)}function Se(e){e.seek(e.position+(4-e.position%4)%4)}var Ce={COLL:L(`COLL`),DESC:L(`DESC`),GEOM:L(`GEOM`),HULL:L(`HULL`),SHAT:L(`SHAT`),SKEL:L(`SKEL`),TEXS:L(`TEXS`)};function we(e){let t=new N(e),n=t.u32();if(n!==827151183)throw Error(`not a .osm file (magic 0x${n.toString(16)})`);let r=t.u16(),i=t.u16();if(r!==0)throw Error(`.osm major version ${r} ≠ 0`);let a=t.u32(),o=[];for(let e=0;e<a;e+=1){let e=t.u32(),n=t.u32(),r=t.u32();o.push({length:r,offset:n,tag:e})}let s=new Map;for(let t of o){if(t.offset+t.length>e.byteLength)throw RangeError(`.osm section ${Ee(t.tag)} overruns the file (${t.offset}+${t.length} > ${e.byteLength})`);s.set(t.tag,e.subarray(t.offset,t.offset+t.length))}return{sections:s,versionMajor:r,versionMinor:i}}function Te(e,t){return e.sections.get(t)??null}function L(e){if(e.length!==4)throw Error(`.osm section tags are 4 characters: '${e}'`);return(e.charCodeAt(0)|e.charCodeAt(1)<<8|e.charCodeAt(2)<<16|e.charCodeAt(3)<<24)>>>0}function Ee(e){return String.fromCharCode(e&255,e>>8&255,e>>16&255,e>>>24&255)}function De(e){let t=new N(e),n=[t.f32(),t.f32(),t.f32()],r=t.u32(),i=t.u32(),a=t.u32(),o=t.u32(),s=[];for(let e=0;e<r;e+=1){let e=[t.f32(),t.f32(),t.f32()];s.push({center:e,radius:t.f32()})}let c=[];for(let e=0;e<i;e+=1){let e=[t.f32(),t.f32(),t.f32()],n=[t.f32(),t.f32(),t.f32()];c.push({max:n,min:e})}let l=new Float32Array(a*3);for(let e=0;e<l.length;e+=1)l[e]=t.f32();let u=new Uint32Array(o);for(let e=0;e<o;e+=1)u[e]=t.u32();return{boxes:c,halfExtents:n,indices:u,spheres:s,vertices:l}}function Oe(e){let t=new N(e),n=[t.f32(),t.f32(),t.f32()],r=[t.f32(),t.f32(),t.f32()],i=t.u32(),a=new Float32Array(i*3);for(let e=0;e<a.length;e+=1)a[e]=t.f32();return{centre:n,half:r,points:a}}function ke(e){let t=new N(e),n=t.u32(),r=t.u32(),i=t.u32(),a=[];for(let e=0;e<i;e+=1){let e=[t.f32(),t.f32(),t.f32()];a.push({ambient:e,mask:Ae(t),texture:Ae(t)})}let o=new Float32Array(n*3);for(let e=0;e<o.length;e+=1)o[e]=t.f32();let s=new Float32Array(n*2);for(let e=0;e<s.length;e+=1)s[e]=t.f32();let c=t.raw(n*4).slice(),l=new Uint16Array(r*3);for(let e=0;e<l.length;e+=1)l[e]=t.u16();let u=new Uint16Array(r);for(let e=0;e<u.length;e+=1)u[e]=t.u16();return{colours:c,materials:a,positions:o,triangleMaterials:u,triangles:l,uvs:s}}function Ae(e){return new TextDecoder().decode(e.raw(e.u16()))}function je(e){let t=new N(e),n=t.u32(),r=[];for(let e=0;e<n;e+=1){let e=new TextDecoder().decode(t.raw(t.u16())),n=t.i32(),i=t.i32(),a=[t.f32(),t.f32(),t.f32()],o=[];for(let e=0;e<9;e+=1)o.push(t.f32());r.push({boneId:i,name:e,parentIndex:n,position:a,rotation:o})}return{frames:r}}var Me=827609935,R={ASTC4x4:5,BC1:0,BC2:4,BC3:1,BC7:2,RGBA8:3},Ne={[R.ASTC4x4]:`texture-compression-astc`,[R.BC1]:`texture-compression-bc`,[R.BC2]:`texture-compression-bc`,[R.BC3]:`texture-compression-bc`,[R.BC7]:`texture-compression-bc`,[R.RGBA8]:void 0},Pe={CUTOUT:1,OPAQUE:0,SOFT_BLEND:2},Fe={[R.ASTC4x4]:16,[R.BC1]:8,[R.BC2]:16,[R.BC3]:16,[R.BC7]:16,[R.RGBA8]:4};function Ie(e){let t=new N(e),n=t.u32();if(n!==827609935)throw Error(`not an .ostex (magic 0x${n.toString(16)})`);let r=t.u16();if(t.u16(),r!==0)throw Error(`unsupported .ostex major ${r} (reader supports 0)`);let i=t.u8(),a=t.u8()===1;t.u16();let o=t.u16(),s=t.u16(),c=t.u16(),l=t.u8();t.u8();let u=[];for(let e=0;e<c;e+=1){let e=t.u32(),n=t.u8(),r=t.u8(),i=t.u8();t.u8(),u.push({alphaClass:n,cutoutRef:r,nameHash:e,wrap:i})}return t.seek(t.position+(4-t.position%4)%4),{format:i,height:s,layers:u,mipCount:l,payload:t.raw(Re(i,o,s,l)*c),premultiplied:a,width:o}}function Le(e){let t=Re(e.format,e.width,e.height,e.mipCount)*e.layers.length;if(e.payload.byteLength!==t)throw Error(`payload ${e.payload.byteLength} B ≠ expected ${t} B (layout mismatch)`);let n=new P(e.payload.byteLength+1024);n.u32(Me),n.u16(0),n.u16(2),n.u8(e.format),n.u8(+!!e.premultiplied),n.u16(0),n.u16(e.width),n.u16(e.height),n.u16(e.layers.length),n.u8(e.mipCount),n.u8(0);for(let t of e.layers)n.u32(t.nameHash),n.u8(t.alphaClass),n.u8(t.cutoutRef),n.u8(t.wrap),n.u8(0);return n.align(4),n.raw(e.payload),n.bytes()}function Re(e,t,n,r){let i=0;for(let a=0;a<r;a+=1)i+=Be(e,t,n,a).totalBytes;return i}function ze(e,t,n){let r=e===R.RGBA8?1:4,i=0,a=t,o=n;for(;a>=r&&o>=r;)i+=1,a>>=1,o>>=1;return Math.max(1,i)}function Be(e,t,n,r){let i=Math.max(1,t>>r),a=Math.max(1,n>>r),o=e===R.RGBA8?a:Math.ceil(a/4),s=Ve(e,i),c=Math.ceil(s/256)*256;return{bytesPerRow:c,mipHeight:a,mipWidth:i,rows:o,totalBytes:c*o}}function Ve(e,t){return e===R.RGBA8?t*Fe[e]:Math.ceil(t/4)*Fe[e]}function He(e){let t=new N(e),n=t.u32(),r=[];for(let e=0;e<n;e+=1)r.push(t.u32());return{arrays:r.map(e=>t.raw(e).slice())}}var Ue=4096;function We(e){let t=new Set;for(let n of Object.values(e.textures)){let e=Ne[n.format];e!==void 0&&t.add(e)}return[...t].sort()}function Ge(e){if(e.version!==1)throw Error(`unsupported .ospak manifest version ${e.version} (reader supports 1)`);if(e.collision!==void 0&&e.collisionCellSize===void 0)throw Error(`manifest carries collision entries without collisionCellSize (the grid they are keyed on)`);let t=[...Object.entries(e.cells),...Object.entries(e.collision??{}),...Object.entries(e.textures)];for(let[n,r]of t){if(r.offset%4096!=0)throw Error(`entry ${n} offset ${r.offset} not ${Ue}-aligned`);if(r.offset+r.length>e.byteLength)throw Error(`entry ${n} range overruns pak (${r.offset}+${r.length}>${e.byteLength})`)}}var Ke=`PMTiles`,qe=16384,Je=26,Ye={BROTLI:3,GZIP:2,NONE:1,UNKNOWN:0,ZSTD:4},Xe={AVIF:5,JPEG:3,MVT:1,PNG:2,UNKNOWN:0,WEBP:4};function Ze(e){let t={at:0},n=z(e,t),r=Array(n),i=Array(n),a=Array(n),o=Array(n),s=0;for(let i=0;i<n;i+=1)s+=z(e,t),r[i]=s;for(let r=0;r<n;r+=1)i[r]=z(e,t);for(let r=0;r<n;r+=1)a[r]=z(e,t);for(let r=0;r<n;r+=1){let n=z(e,t);o[r]=n===0&&r>0?o[r-1]+a[r-1]:n-1}return r.map((e,t)=>({length:a[t],offset:o[t],runLength:i[t],tileId:e}))}function Qe(e){if(e.byteLength<127)throw Error(`pmtiles: header needs 127 bytes, got ${e.byteLength}`);let t=new N(e),n=new TextDecoder().decode(t.raw(7));if(n!==`PMTiles`)throw Error(`pmtiles: not a PMTiles archive (magic "${n}")`);let r=t.u8();if(r!==3)throw Error(`pmtiles: version ${r} is not v3`);let i=t.u64(),a=t.u64(),o=t.u64(),s=t.u64(),c=t.u64(),l=t.u64(),u=t.u64(),d=t.u64();t.u64(),t.u64(),t.u64();let f=t.u8()===1,p=t.u8(),m=t.u8(),h=t.u8(),g=t.u8(),_=t.u8();if(p!==Ye.NONE)throw Error(`pmtiles: directory compression ${p} is not supported (this reader has no inflater)`);return{clustered:f,internalCompression:p,leafDirsLength:l,leafDirsOffset:c,maxZoom:_,metadataLength:s,metadataOffset:o,minZoom:g,rootLength:a,rootOffset:i,tileCompression:m,tileDataLength:d,tileDataOffset:u,tileType:h}}function $e(e){let t=[...e.tiles].map(e=>({...e,id:nt(e.z,e.x,e.y)})).sort((e,t)=>e.id-t.id);for(let e=1;e<t.length;e+=1)if(t[e].id===t[e-1].id)throw Error(`pmtiles: duplicate tile ${t[e].z}/${t[e].x}/${t[e].y}`);let n=new P(1<<20),r=new Map,i=[];for(let e of t){let t=rt(e.bytes),a=r.get(t);a||(a={length:e.bytes.byteLength,offset:n.offset},n.raw(e.bytes),r.set(t,a)),i.push({length:a.length,offset:a.offset,runLength:1,tileId:e.id})}let a=new TextEncoder().encode(JSON.stringify(e.metadata)),{leaves:o,root:s}=it(i),c=127+s.byteLength,l=c+a.byteLength,u=l+o.byteLength,d=t.map(e=>e.z),f=at({addressedTiles:t.length,bounds:e.bounds,contents:r.size,entries:i.length,header:{clustered:!0,internalCompression:Ye.NONE,leafDirsLength:o.byteLength,leafDirsOffset:l,maxZoom:d.length>0?Math.max(...d):0,metadataLength:a.byteLength,metadataOffset:c,minZoom:d.length>0?Math.min(...d):0,rootLength:s.byteLength,rootOffset:127,tileCompression:Ye.NONE,tileDataLength:n.offset,tileDataOffset:u,tileType:e.tileType}}),p=new Uint8Array(u+n.offset);return p.set(f,0),p.set(s,127),p.set(a,c),p.set(o,l),p.set(n.bytes(),u),p}function et(e){let t=new P(256+e.length*8);B(t,e.length);let n=0;for(let r of e)B(t,r.tileId-n),n=r.tileId;for(let n of e)B(t,n.runLength);for(let n of e)B(t,n.length);for(let[n,r]of e.entries()){let i=n>0?e[n-1]:null;B(t,i!==null&&r.offset===i.offset+i.length?0:r.offset+1)}return new Uint8Array(t.bytes())}function tt(e,t){let n=0,r=e.length-1,i=-1;for(;n<=r;){let a=n+r>>1;e[a].tileId<=t?(i=a,n=a+1):r=a-1}if(i<0)return null;let a=e[i];return a.runLength===0||t<a.tileId+a.runLength?a:null}function nt(e,t,n){if(e<0||e>Je||!Number.isInteger(e))throw RangeError(`pmtiles: zoom ${e} outside 0..${Je}`);let r=2**e;if(t<0||n<0||t>=r||n>=r||!Number.isInteger(t)||!Number.isInteger(n))throw RangeError(`pmtiles: tile ${e}/${t}/${n} outside the pyramid`);let i=0,a=0,o=0,s=t,c=n;for(let e=r/2;e>=1;e/=2)if(i=+((s&e)>0),a=+((c&e)>0),o+=e*e*(3*i^a),a===0){i===1&&(s=e-1-s,c=e-1-c);let t=s;s=c,c=t}return ot(e)+o}function rt(e){let t=2166136261;for(let n of e)t^=n,t=Math.imul(t,16777619);return`${e.byteLength}:${t>>>0}`}function it(e){let t=et(e);if(t.byteLength<=16257)return{leaves:new Uint8Array,root:t};for(let t=512;t<=1<<20;t*=2){let n=new P(65536),r=[];for(let i=0;i<e.length;i+=t){let a=e.slice(i,i+t),o=et(a);r.push({length:o.byteLength,offset:n.offset,runLength:0,tileId:a[0].tileId}),n.raw(o)}let i=et(r);if(i.byteLength<=16257)return{leaves:new Uint8Array(n.bytes()),root:i}}throw Error(`pmtiles: the pyramid does not fit a two-level directory`)}function z(e,t){let n=0,r=1;for(;;){if(t.at>=e.byteLength)throw RangeError(`pmtiles: varint runs past the end of the directory`);let i=e[t.at];if(t.at+=1,n+=(i&127)*r,!(i&128))return n;if(r*=128,r>2**53-1)throw RangeError(`pmtiles: varint wider than an exact double`)}}function at(e){let{bounds:t,header:n}=e,r=new P(127);r.raw(new TextEncoder().encode(Ke)),r.u8(3);for(let t of[n.rootOffset,n.rootLength,n.metadataOffset,n.metadataLength,n.leafDirsOffset,n.leafDirsLength,n.tileDataOffset,n.tileDataLength,e.addressedTiles,e.entries,e.contents])r.u64(t);return r.u8(+!!n.clustered),r.u8(n.internalCompression),r.u8(n.tileCompression),r.u8(n.tileType),r.u8(n.minZoom),r.u8(n.maxZoom),r.i32(Math.round(t.minLon*1e7)),r.i32(Math.round(t.minLat*1e7)),r.i32(Math.round(t.maxLon*1e7)),r.i32(Math.round(t.maxLat*1e7)),r.u8(t.centerZoom),r.i32(Math.round((t.minLon+t.maxLon)/2*1e7)),r.i32(Math.round((t.minLat+t.maxLat)/2*1e7)),new Uint8Array(r.bytes())}function B(e,t){let n=t;for(;n>=128;)e.u8(n&127|128),n=Math.floor(n/128);e.u8(n)}function ot(e){return(4**e-1)/3}var st={[R.ASTC4x4]:`astc-4x4-unorm-srgb`,[R.BC1]:`bc1-rgba-unorm-srgb`,[R.BC2]:`bc2-rgba-unorm-srgb`,[R.BC3]:`bc3-rgba-unorm-srgb`,[R.BC7]:`bc7-rgba-unorm-srgb`,[R.RGBA8]:`rgba8unorm-srgb`};function ct(e,t,n,r){let i=Ie(n);ut(e,i.format,r);let a=i.payload.byteLength,o=t.createTexture(`texture`,{dimension:`2d`,format:st[i.format],label:r,mipLevelCount:i.mipCount,size:{depthOrArrayLayers:i.layers.length,height:i.height,width:i.width},usage:GPUTextureUsage.TEXTURE_BINDING|GPUTextureUsage.COPY_DST},a),s=0,c=0,l=0;return{byteEstimate:a,layers:i.layers.length,step(){if(s>=i.layers.length)return!0;let t=Be(i.format,i.width,i.height,c);return e.queue.writeTexture({mipLevel:c,origin:{x:0,y:0,z:s},texture:o},i.payload.subarray(l,l+t.totalBytes),{bytesPerRow:t.bytesPerRow,rowsPerImage:t.rows},{depthOrArrayLayers:1,height:t.mipHeight,width:t.mipWidth}),l+=t.totalBytes,c+=1,c>=i.mipCount&&(c=0,s+=1),s>=i.layers.length},texture:o}}function lt(e,t,n,r){let i=ct(e,t,n,r);for(;!i.step(););return{byteEstimate:i.byteEstimate,layers:i.layers,texture:i.texture}}function ut(e,t,n){let r=Ne[t];if(r!==void 0&&!e.features.has(r))throw Error(`${n}: this texture is ${st[t]} and the GPU has no ${r}. The world's pak must be built with textures this device can read.`)}var dt=class{parts;matrices;get partCount(){return this.parts.length}animQuat;animTranslation;detached;detachedMatrix;local=new Float32Array(16);offset=new Float32Array(16);quat=new Float32Array(4);root=new Float32Array(16);scratch=new Float32Array(16);translation=[0,0,0];constructor(e){this.parts=e,this.matrices=new Float32Array(e.length*16),this.animQuat=new Float32Array(e.length*4),this.animTranslation=new Float32Array(e.length*3),this.detached=new Uint8Array(e.length),this.detachedMatrix=new Float32Array(e.length*16);for(let t=0;t<e.length;t+=1)this.animQuat[t*4+3]=1;this.root.set([1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1])}flatten(){for(let e=0;e<this.parts.length;e+=1){let t=this.matrices.subarray(e*16,e*16+16);if(this.detached[e]===1){t.set(this.detachedMatrix.subarray(e*16,e*16+16));continue}let n=this.parts[e];ft(this.quat,n.localRotation,this.animQuat.subarray(e*4,e*4+4));let r=e*3;this.translation[0]=n.localTranslation[0]+this.animTranslation[r],this.translation[1]=n.localTranslation[1]+this.animTranslation[r+1],this.translation[2]=n.localTranslation[2]+this.animTranslation[r+2],pt(this.local,this.quat,this.translation,n.scale??1),n.offset&&(this.scratch.set(this.local),this.offset.set(n.offset),u(this.local,this.scratch,this.offset)),u(t,this.root,this.local)}}partIndex(e){return this.parts.findIndex(t=>t.name===e)}setPartRotation(e,t){this.animQuat.set(t,e*4)}setPartTranslation(e,t){this.animTranslation.set(t,e*3)}setPartWorldMatrix(e,t){if(t===null){this.detached[e]=0;return}this.detached[e]=1,this.detachedMatrix.set(t,e*16)}setRoot(e){this.root.set(e)}};function ft(e,t,n){let[r,i,a,o]=[t[0],t[1],t[2],t[3]],[s,c,l,u]=[n[0],n[1],n[2],n[3]];e[0]=o*s+r*u+i*l-a*c,e[1]=o*c+i*u+a*s-r*l,e[2]=o*l+a*u+r*c-i*s,e[3]=o*u-r*s-i*c-a*l}function pt(e,t,n,r){if(l(e,t,n),r!==1)for(let t of[0,4,8])e[t]*=r,e[t+1]*=r,e[t+2]*=r}var V=9,mt=1024,ht=class{capacity;count=0;data;deaths;constructor(e){this.capacity=e,this.data=new Float32Array(e*V),this.deaths=new Float64Array(e)}prune(e){let t=!1;for(let n=this.count-1;n>=0;--n){if(this.deaths[n]>e)continue;let r=this.count-1;n!==r&&(this.data.copyWithin(n*V,r*V,r*V+V),this.deaths[n]=this.deaths[r]),this.count=r,t=!0}return t}spawn(e,t,n,r,i,a,o,s,c,l=1){if(this.count>=this.capacity||t<=0)return!1;let u=this.count*V,d=this.data;return d[u]=r,d[u+1]=i,d[u+2]=a,d[u+3]=o,d[u+4]=s,d[u+5]=c,d[u+6]=t,d[u+7]=-e,d[u+8]=n+Math.min(.999,Math.max(0,1-l)),this.deaths[this.count]=e+t,this.count+=1,!0}},gt=class{get count(){return this.add.pool.count+this.blend.pool.count}add;additive;bindGroup;blend;device;resources;systems;texture;textureBytes;constructor(e,t,n,r){this.additive=r.additive,this.device=e,this.resources=t,this.systems=t.createBuffer(`debris`,{label:`dyn-particle-systems`,size:Math.max(16,r.systems.byteLength),usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST}),e.queue.writeBuffer(this.systems,0,r.systems);let i=r.atlas.width*r.atlas.height*4;this.textureBytes=r.atlas.rgba.byteLength,this.texture=t.createTexture(`texture`,{format:`rgba8unorm-srgb`,label:`dyn-particle-atlas`,size:{depthOrArrayLayers:Math.max(1,r.atlas.layers),height:r.atlas.height,width:r.atlas.width},usage:GPUTextureUsage.TEXTURE_BINDING|GPUTextureUsage.COPY_DST},this.textureBytes);for(let t=0;t<r.atlas.layers;t+=1)e.queue.writeTexture({origin:{x:0,y:0,z:t},texture:this.texture},r.atlas.rgba.subarray(t*i,(t+1)*i),{bytesPerRow:r.atlas.width*4},{height:r.atlas.height,width:r.atlas.width});this.bindGroup=e.createBindGroup({entries:[{binding:0,resource:{buffer:this.systems}},{binding:1,resource:this.texture.createView({dimension:`2d-array`})},{binding:2,resource:e.createSampler({label:`dyn-particle`,magFilter:`linear`,minFilter:`linear`})}],label:`dyn-particle`,layout:n});let a=(e,n)=>({buffer:t.createBuffer(`debris`,{label:n,size:mt*V*4,usage:GPUBufferUsage.VERTEX|GPUBufferUsage.COPY_DST}),dirty:!1,pipeline:e,pool:new ht(mt)});this.add=a(`particle-add-once`,`dyn-particle-add`),this.blend=a(`particle-blend-once`,`dyn-particle-blend`)}destroy(){this.resources.destroyBuffer(`debris`,this.systems),this.resources.destroyBuffer(`debris`,this.add.buffer),this.resources.destroyBuffer(`debris`,this.blend.buffer),this.resources.destroyTexture(`texture`,this.texture,this.textureBytes)}draw(e,t,n,r,i){let a=0;for(let o of[this.blend,this.add])(o.pool.prune(i)||o.dirty)&&(this.device.queue.writeBuffer(o.buffer,0,o.pool.data,0,o.pool.count*V),o.dirty=!1),o.pool.count!==0&&(e.setPipeline(t.get(o.pipeline)),e.setBindGroup(0,n),e.setBindGroup(1,this.bindGroup),e.setVertexBuffer(0,r),e.setVertexBuffer(1,o.buffer),e.draw(6,o.pool.count),a+=1);return a}spawn(e,t,n,r,i,a,o,s,c,l=1){if(!Number.isInteger(t)||t<0||t>=this.additive.length)return!1;let u=this.additive[t]?this.add:this.blend,d=u.pool.spawn(e,c,t,n,r,i,a,o,s,l);return u.dirty=u.dirty||d,d}},_t={bloom:`
struct Bloom {
  // texel = [1/inputW, 1/inputH, 0, 0] of the INPUT texture; params = [threshold, smoothing, radius, 0].
  texel: vec4f,
  params: vec4f,
};
@group(0) @binding(0) var<uniform> bloom: Bloom;
@group(0) @binding(1) var inputTex: texture_2d<f32>;
@group(0) @binding(2) var inputSampler: sampler;
// Upsample only: the same-size DOWNSAMPLE mip the tent result composites over.
@group(0) @binding(3) var supportTex: texture_2d<f32>;

struct BloomOut {
  @builtin(position) clip: vec4f,
  @location(0) uv: vec2f,
};

@vertex
fn vsBloom(@builtin(vertex_index) index: u32) -> BloomOut {
  var corners = array<vec2f, 3>(vec2f(-1.0, -3.0), vec2f(3.0, 1.0), vec2f(-1.0, 1.0));
  let corner = corners[index];
  var out: BloomOut;
  out.clip = vec4f(corner, 0.0, 1.0);
  out.uv = vec2f(corner.x * 0.5 + 0.5, 0.5 - corner.y * 0.5);
  return out;
}

// Rec709 luminance — three's luminance() (the prod threshold is measured on this).
fn bloomLuma(rgb: vec3f) -> f32 {
  return dot(rgb, vec3f(0.2126, 0.7152, 0.0722));
}

@fragment
fn fsBloomPrefilter(in: BloomOut) -> @location(0) vec4f {
  let texel = textureSampleLevel(inputTex, inputSampler, in.uv, 0.0);
  let mask = smoothstep(bloom.params.x, bloom.params.x + bloom.params.y, bloomLuma(texel.rgb));
  return texel * mask;
}

// 1 inside [0,1]², 0 outside — prod's clampToBorder (edge taps must not smear the frame border).
fn insideFrame(uv: vec2f) -> f32 {
  let inside = step(vec2f(0.0), uv) * step(uv, vec2f(1.0));
  return inside.x * inside.y;
}

fn borderTap(uv: vec2f) -> vec4f {
  return textureSampleLevel(inputTex, inputSampler, uv, 0.0) * insideFrame(uv);
}

const DOWN_INNER = 0.125;
const DOWN_OUTER = 0.05556;

@fragment
fn fsBloomDown(in: BloomOut) -> @location(0) vec4f {
  let t = bloom.texel.xy;
  var c = vec4f(0.0);
  // Inner ring (half-texel corners at the input resolution).
  c += borderTap(in.uv + t * vec2f(-1.0, 1.0)) * DOWN_INNER;
  c += borderTap(in.uv + t * vec2f(1.0, 1.0)) * DOWN_INNER;
  c += borderTap(in.uv + t * vec2f(-1.0, -1.0)) * DOWN_INNER;
  c += borderTap(in.uv + t * vec2f(1.0, -1.0)) * DOWN_INNER;
  // Outer ring + centre.
  c += borderTap(in.uv + t * vec2f(-2.0, 2.0)) * DOWN_OUTER;
  c += borderTap(in.uv + t * vec2f(0.0, 2.0)) * DOWN_OUTER;
  c += borderTap(in.uv + t * vec2f(2.0, 2.0)) * DOWN_OUTER;
  c += borderTap(in.uv + t * vec2f(-2.0, 0.0)) * DOWN_OUTER;
  c += borderTap(in.uv + t * vec2f(2.0, 0.0)) * DOWN_OUTER;
  c += borderTap(in.uv + t * vec2f(-2.0, -2.0)) * DOWN_OUTER;
  c += borderTap(in.uv + t * vec2f(0.0, -2.0)) * DOWN_OUTER;
  c += borderTap(in.uv + t * vec2f(2.0, -2.0)) * DOWN_OUTER;
  c += textureSampleLevel(inputTex, inputSampler, in.uv, 0.0) * DOWN_OUTER;
  return c;
}

@fragment
fn fsBloomUp(in: BloomOut) -> @location(0) vec4f {
  let t = bloom.texel.xy;
  var c = vec4f(0.0);
  c += textureSampleLevel(inputTex, inputSampler, in.uv + t * vec2f(-1.0, 1.0), 0.0) * 0.0625;
  c += textureSampleLevel(inputTex, inputSampler, in.uv + t * vec2f(0.0, 1.0), 0.0) * 0.125;
  c += textureSampleLevel(inputTex, inputSampler, in.uv + t * vec2f(1.0, 1.0), 0.0) * 0.0625;
  c += textureSampleLevel(inputTex, inputSampler, in.uv + t * vec2f(-1.0, 0.0), 0.0) * 0.125;
  c += textureSampleLevel(inputTex, inputSampler, in.uv, 0.0) * 0.25;
  c += textureSampleLevel(inputTex, inputSampler, in.uv + t * vec2f(1.0, 0.0), 0.0) * 0.125;
  c += textureSampleLevel(inputTex, inputSampler, in.uv + t * vec2f(-1.0, -1.0), 0.0) * 0.0625;
  c += textureSampleLevel(inputTex, inputSampler, in.uv + t * vec2f(0.0, -1.0), 0.0) * 0.125;
  c += textureSampleLevel(inputTex, inputSampler, in.uv + t * vec2f(1.0, -1.0), 0.0) * 0.0625;
  let support = textureSampleLevel(supportTex, inputSampler, in.uv, 0.0);
  return mix(support, c, bloom.params.z);
}
`,"cloud-field":`
#include <frame>

struct CloudFieldOut {
  @builtin(position) clip: vec4f,
  @location(0) uv: vec2f,
};

@vertex
fn vsCloudField(@builtin(vertex_index) index: u32) -> CloudFieldOut {
  var corners = array<vec2f, 3>(vec2f(-1.0, -3.0), vec2f(3.0, 1.0), vec2f(-1.0, 1.0));
  let corner = corners[index];
  var out: CloudFieldOut;
  out.clip = vec4f(corner, 0.0, 1.0);
  out.uv = vec2f(corner.x * 0.5 + 0.5, 0.5 - corner.y * 0.5);
  return out;
}

@fragment
fn fsCloudField(in: CloudFieldOut) -> @location(0) vec4f {
  let t = frame.params2.z;
  let p = (in.uv - vec2f(0.5)) * 12.0;
  let cuv = p * (0.45 * frame.cloudTop.w) + vec2f(t * 0.004, t * 0.002);
  return vec4f(skyFbm(cuv), skyFbm(cuv * 0.4 + vec2f(19.0)), 0.0, 1.0);
}
`,clutter:`
#include <frame>

@group(1) @binding(0) var<storage, read> clutterMatrices: array<mat4x4f>;
@group(1) @binding(1) var clutterTexture: texture_2d_array<f32>;
@group(1) @binding(2) var clutterSampler: sampler;
// .x = this group's SQUARED draw distance — the per-category visibility range. Applied per INSTANCE because
// the clutter grid is 256 units: a whole-group test cannot express a radius under a cell diagonal.
@group(1) @binding(3) var<uniform> clutterRange: vec4f;

// Geometry is the shared vehicle-model layout (buildVehicleModel): slots.x = texture-array layer (the only
// meta clutter uses — paint slot / lamp tags are ignored). One draw covers every submesh; the per-vertex
// layer selects the right texture, exactly like the rigid path. Named slots (not meta) — meta is a WGSL
// reserved word, the same rename the rigid shader made.
struct ClutterIn {
  @builtin(instance_index) instance: u32,
  @location(0) position: vec3f,
  @location(1) normal: vec3f,
  @location(2) uv: vec2f,
  @location(3) color: vec4f,
  @location(4) slots: vec4<u32>,
  // The NIGHT vertex colours — every one of the 56 species procobj scatters carries an AUTHORED set, so
  // the old in-shader day x ambient guess was overwriting art that shipped with the model.
  @location(5) night: vec4f,
};

struct ClutterOut {
  @builtin(position) clip: vec4f,
  @location(0) uv: vec2f,
  @location(1) prelit: vec3f,
  @location(2) world: vec3f,
  @location(3) sunNdl: f32,
  @location(4) moonNdl: f32,
  @location(5) @interpolate(flat) layer: u32,
};

@vertex
fn vsClutter(in: ClutterIn) -> ClutterOut {
  let model = clutterMatrices[in.instance];
  let world = model * vec4f(in.position, 1.0);
  var out: ClutterOut;
  out.clip = frame.viewProj * world;
  out.world = world.xyz;
  out.uv = in.uv;
  out.layer = in.slots.x;
  // Day → night on the authored sets, the same blend the world and rigid paths use. The builder synthesizes
  // day × ambient where a species truly has no night set, so this is one formula everywhere.
  out.prelit = mix(in.color.rgb, in.night.rgb, frame.params.x);
  let n = normalize((model * vec4f(in.normal, 0.0)).xyz);
  out.sunNdl = max(dot(n, frame.sunDir.xyz), 0.0);
  out.moonNdl = clamp((dot(n, frame.moonDir.xyz) + 0.6) / 1.6, 0.0, 1.0);
  // Per-category range: an instance whose ORIGIN is past this group's draw distance is pushed outside the
  // clip volume, so the triangle is rejected before any fragment work. Every vertex of the instance takes the
  // same branch and lands on the same point, so the rejection is total rather than a torn primitive. Measured
  // from the instance ORIGIN (not the vertex) so a species never half-disappears, and squared to keep the
  // sqrt out of the vertex path.
  let toInstance = model[3].xyz - frame.camera.xyz;
  if (dot(toInstance, toInstance) > clutterRange.x) {
    out.clip = vec4f(2.0, 2.0, 2.0, 1.0);
  }
  return out;
}

fn clutterShade(in: ClutterOut, cutout: bool) -> vec4f {
  var texel = textureSample(clutterTexture, clutterSampler, in.uv, in.layer);
  if (cutout) {
    // Sharpen the sampled alpha toward the vanilla alpha-test look (the world-cutout trick), so minified grass
    // does not turn into a uniform A2C screen-door.
    texel.a = clamp((texel.a - 0.5) / max(fwidth(texel.a), 0.0001) + 0.5, 0.0, 1.0);
  }
  // frame.ambient (plan 093): the same additive SA ambient floor the world shader carries (no AO
  // channel on clutter).
  let lit = in.prelit * frame.params.y + frame.ambient.rgb +
    frame.sunColor.rgb * (in.sunNdl * frame.params.z) +
    frame.moonColor.rgb * in.moonNdl;
  var color = texel.rgb * lit;
  // Unified fog (the 068 shape — identical math to fsWorld).
  let toCamera = in.world - frame.camera.xyz;
  let dist = length(toCamera);
  let viewDir = toCamera / max(dist, 0.001);
  let fogD = max(dist - frame.fog.y, 0.0);
  let fogK = 2.0 / max(frame.fog.x - frame.fog.y, 1.0);
  var fogFactor = 1.0 - exp(-(fogK * fogD) * (fogK * fogD));
  fogFactor = fogFactor * mix(frame.fog.w, 1.0, exp(-max(in.world.y, 0.0) * frame.fog.z));
  fogFactor = max(fogFactor, smoothstep(frame.fog.x * 0.85, frame.fog.x, dist));
  color = mix(color, fogColorFor(viewDir, fogFactor), fogFactor);
  return vec4f(color, texel.a);
}

@fragment
fn fsClutter(in: ClutterOut) -> @location(0) vec4f {
  return clutterShade(in, false);
}

@fragment
fn fsClutterCutout(in: ClutterOut) -> @location(0) vec4f {
  return clutterShade(in, true);
}
`,corona:`
#include <frame>

// 2dfx coronas (074/06 row 13 v1): instanced camera-facing quads, PROCEDURAL radial glow (the particle.txd
// sprites arrive with the texture path later), additive premultiplied blending, depth READ (occluders hide
// coronas). Night-gated on the CPU side (dn scales the instance colour before upload).
struct CoronaIn {
  @location(0) corner: vec2f,
  @location(1) center: vec3f,
  @location(2) size: f32,
  @location(3) color: vec4f,
};

struct CoronaOut {
  @builtin(position) clip: vec4f,
  @location(0) offset: vec2f,
  @location(1) color: vec4f,
};

@vertex
fn vsCorona(in: CoronaIn) -> CoronaOut {
  var out: CoronaOut;
  // Camera basis from the inverse view-projection is overkill — build right/up from the view matrix baked
  // into viewProj via the camera position: cheap billboard using the eye-to-center frame.
  let toEye = normalize(frame.camera.xyz - in.center);
  let right = normalize(cross(vec3f(0.0, 1.0, 0.0), toEye));
  let up = cross(toEye, right);
  let world = in.center + (right * in.corner.x + up * in.corner.y) * in.size;
  out.clip = frame.viewProj * vec4f(world, 1.0);
  out.offset = in.corner;
  out.color = in.color;
  return out;
}

@fragment
fn fsCorona(in: CoronaOut) -> @location(0) vec4f {
  // The real SA coronastar sprite (particle.txd) — it has the cross flare a procedural blob cannot fake.
  // The host normalises the alpha (SA ships these shape-in-RGB with alpha pinned at 255), so trust it here.
  let uv = in.offset * 0.5 + vec2f(0.5); // the quad spans [-1, 1] — see the particle shader's note
  let texel = textureSample(coronaSprites, skyLutSampler, uv, 0u);
  return vec4f(in.color.rgb * texel.rgb * (texel.a * in.color.a), 0.0);
}
`,debris:`
#include <frame>

struct DebrisUniform {
  spawn: vec4f,   // x = spawn time (frame clock), y = lifetime, z = fade seconds, w = gravity
};
@group(1) @binding(0) var<uniform> debris: DebrisUniform;
@group(1) @binding(1) var shards: texture_2d_array<f32>;
@group(1) @binding(2) var shardSampler: sampler;

struct DebrisIn {
  @location(0) position: vec3f,
  @location(1) uv: vec2f,
  @location(2) color: vec4f,
  @location(3) center: vec3f,
  @location(4) velocity: vec3f,
  @location(5) angular: vec3f,
  @location(6) landLayer: vec2f,   // x = land time (s), y = texture layer
};

struct DebrisOut {
  @builtin(position) clip: vec4f,
  @location(0) uv: vec2f,
  @location(1) color: vec4f,
  @location(2) @interpolate(flat) layer: u32,
  @location(3) fade: f32,
};

/** Rodrigues: rotate v about a unit axis by the given angle. */
fn rotateAxis(v: vec3f, axis: vec3f, angle: f32) -> vec3f {
  let c = cos(angle);
  let s = sin(angle);
  return v * c + cross(axis, v) * s + axis * dot(axis, v) * (1.0 - c);
}

@vertex
fn vsDebris(in: DebrisIn) -> DebrisOut {
  var out: DebrisOut;
  let age = max(frame.params2.z - debris.spawn.x, 0.0);
  // Frozen once it lands: both the arc and the spin stop at the same instant, or a resting shard would
  // keep twitching on the ground.
  let t = min(age, in.landLayer.x);
  let speed = length(in.angular);
  let axis = select(vec3f(0.0, 1.0, 0.0), in.angular / max(speed, 1e-5), speed > 1e-5);
  let spun = rotateAxis(in.position - in.center, axis, speed * t);
  let center = in.center + in.velocity * t + vec3f(0.0, -0.5 * debris.spawn.w, 0.0) * t * t;
  out.clip = frame.viewProj * vec4f(center + spun, 1.0);
  out.uv = in.uv;
  out.color = in.color;
  out.layer = u32(in.landLayer.y);
  out.fade = 1.0 - smoothstep(debris.spawn.y - debris.spawn.z, debris.spawn.y, age);
  return out;
}

@fragment
fn fsDebris(in: DebrisOut) -> @location(0) vec4f {
  let texel = textureSample(shards, shardSampler, in.uv, in.layer);
  let color = texel.rgb * in.color.rgb;
  let alpha = texel.a * in.color.a * in.fade;
  return vec4f(color * alpha, alpha);   // premultiplied, like every other blended pass here
}
`,"debug-line":`
#include <frame>

struct DebugLineUniform {
  color: vec4f,
};
@group(1) @binding(0) var<uniform> debugLine: DebugLineUniform;

struct DebugLineOut {
  @builtin(position) clip: vec4f,
};

@vertex
fn vsDebugLine(@location(0) position: vec3f) -> DebugLineOut {
  var out: DebugLineOut;
  out.clip = frame.viewProj * vec4f(position, 1.0);
  return out;
}

@fragment
fn fsDebugLine() -> @location(0) vec4f {
  return debugLine.color;
}
`,frame:`
struct Frame {
  viewProj: mat4x4f,
  invViewProj: mat4x4f,
  // camera.w = cloud dome slot A→B crossfade blend (row 15 weather fade; spare vec4 slot).
  camera: vec4f,
  // Environment (plan 074/06): sun direction (unit, towards the sun; .w = CURRENT ARC ELEVATION 0..1,
  // the sun-vis v2 threshold input — 074/07), sun colour,
  // params  = [dn (0 day → 1 night), indirectScale, directScale, emissiveBoost],
  // skyTop / skyHorizon = LINEAR sky gradient colours (row 4 v1 — the PBR LUT replaces them later),
  // fog     = [cutDistance, startDistance, heightK, heightMin] (row 5 — the 068 shape),
  // params2 = [aoStrength (074/07 baked skyVis → indirect), sunVisStrength (074/07 baked sun shadows),
  //            time seconds (the wind clock), windStrength (074/06 row 10)],
  // moonDir/moonColor = the night light (074/06 row 6; colour is BLACK by day — the CPU arc gates it);
  // moonDir.w = stochastic de-tiling toggle (074/12); moonColor.w = spare (held the retired
  // cloud-panorama rotation speed).
  sunDir: vec4f,
  sunColor: vec4f,
  params: vec4f,
  skyTop: vec4f,
  skyHorizon: vec4f,
  fog: vec4f,
  params2: vec4f,
  moonDir: vec4f,
  moonColor: vec4f,
  // params3 = [localLightCount (row 7), spare (held the retired panorama enable), cloudDark, cloudLayerAlpha].
  params3: vec4f,
  // The SUN VISUAL (timecyc columns): sunCore = disc colour (.w = angular core radius, rad, from
  // timecyc sunSize); sunCorona = halo/godray colour (.w = weather cloud COVER 0..1 — prod's uCloudClear
  // source: stars fade GLOBALLY under overcast). env.sunColor above stays the LIGHT.
  sunCore: vec4f,
  sunCorona: vec4f,
  // Water v1 (074/06 row 12): timecyc WaterRGBA — deep tint (linear rgb) + base opacity in .w.
  waterColor: vec4f,
  // params4 = [dynamicLightCount, moonPhase (B6), reflectionStrength (B5r), probeMix (074/16 step 2 —
  // 0 = analytic sky fallback, 1 = all six faces of the scene probe rendered)]. The pool is ordered
  // DYNAMIC first, then static 2dfx: the world shades the static half per vertex and the dynamic half per
  // pixel; vehicles and peds take the STATIC half only, so a car is never lit by its own lamps.
  params4: vec4f,
  // timecyc cloud colours (074/09 sky round 2): lowClouds (lit tops) / bottomClouds (shadowed undersides)
  // tint the cloud deck — the authored dawn/dusk palette turns the WHOLE sky's clouds pink, not just
  // the sun side (prod applyClouds colours its deck from exactly these columns).
  cloudTop: vec4f,
  cloudBottom: vec4f,
  // World ambient floor (plan 093): linear timecyc Amb. SA's building pipe ADDS this on top of the
  // blended prelight (ps2BuildingVS: Color.rgb += ambient*surfAmb) — normal-independent, which is
  // why vanilla ships pure-black shadow prelit and still reads as shadow. .w spare.
  ambient: vec4f,
};
@group(0) @binding(0) var<uniform> frame: Frame;
@group(0) @binding(1) var skyLut: texture_2d<f32>;
@group(0) @binding(2) var skyLutSampler: sampler;
// Bindings 4/5 held the painted cloud-panorama dome — REMOVED 2026-07-17 (procedural cirrus+cumulus
// carry the clouds); the numbers stay vacant so the rest never renumbers.
// SA corona billboards from particle.txd: layer 0 = coronastar (lamps, headlights), layer 1 = coronamoon.
@group(0) @binding(6) var coronaSprites: texture_2d_array<f32>;
// Baked cumulus field (sky v2 perf): rg = [n, mass] fbm baked over the sky projection by the tiny
// cloud-field pass each frame — full-deck weathers pay one tap here instead of 10 vnoise per pixel.
@group(0) @binding(7) var cloudField: texture_2d<f32>;

// ASSET-INSPECTION debug knobs (074/13 phase 4), riding two spare frame lanes so the uniform never grows
// (it would invalidate every recorded cell bundle). Both are inert at their defaults — scale 1, unlit 0 —
// so normal play multiplies by one and selects the untouched lit term. NOTE: no backticks in WGSL
// comments — these modules are JS template literals and a stray backtick ends the string.

/**
 * Baked vertex light: 1 = as authored, 0 = OFF, 2 = SA's MODULATE2X.
 * "Off" is a NEUTRAL multiplier (white), not a zero one — the point is to see the texture without the
 * baked light, not to black the model out. ×2 saturates, as MODULATE2X does on real hardware.
 */
fn debugPrelit(color: vec3f) -> vec3f {
  let scale = frame.params3.y;
  return select(min(color * scale, vec3f(1.0)), vec3f(1.0), scale < 0.5);
}

/**
 * Debug VIEW mode on the same spare lane: 0 = normal shading, 1 = unlit (flat albedo), 2 = normals.
 *
 * One lane, one view at a time — the three build shared a single scene-wide override slot for exactly this
 * reason, so enabling one debug view disabled the other. Widening the existing flag keeps the uniform the
 * same size, which is load-bearing: growing it invalidates every recorded cell bundle.
 */
fn debugView() -> f32 {
  return frame.moonColor.w;
}

/** Flat albedo (no sun/moon/pool response) when the unlit view is selected. */
fn debugLit(lit: vec3f) -> vec3f {
  return select(lit, vec3f(1.0), abs(debugView() - 1.0) < 0.5);
}

/**
 * Normal visualisation, the same mapping the three MeshNormalMaterial used: n * 0.5 + 0.5. Returned INSTEAD
 * of the shaded colour and before fog — a fogged normal is a fogged debug view, which is no debug view.
 */
fn debugNormalColor(normal: vec3f) -> vec3f {
  return normalize(normal) * 0.5 + vec3f(0.5);
}

/** Whether the normals view is selected. */
fn debugShowNormals() -> bool {
  return debugView() > 1.5;
}

// Shared sky colour by view direction (the sky pass AND the world fog sample the same PBR dome — fully
// fogged geometry dissolves into exactly the sky behind it, the 068 invariant). The dome is a CPU-built
// Preetham LUT (074/06 row 4): u = azimuthal angle from the sun (the dome is sun-symmetric), v = elevation.
// The moon's angular radius as a multiple of the sun's (they are famously close in the real sky; SA draws a
// bigger, friendlier moon). MOON_BODY_GAIN keeps the lit disc HDR so it feeds the bloom/godray pass.
const MOON_DISC_SCALE = 3.2;
const MOON_BODY_GAIN = 10.0;

fn skyBaseFor(dir: vec3f) -> vec3f {
  let dirXz = normalize(vec2f(dir.x, dir.z) + vec2f(1e-5, 0.0));
  let sunXz = normalize(vec2f(frame.sunDir.x, frame.sunDir.z) + vec2f(1e-5, 0.0));
  let azimuth = acos(clamp(dot(dirXz, sunXz), -1.0, 1.0)) / 3.14159265;
  let v = clamp((dir.y + 0.05) / 1.05, 0.0, 1.0);
  var col = textureSampleLevel(skyLut, skyLutSampler, vec2f(azimuth, v), 0.0).rgb;
  // Night sky glow (074/09 sky round — the prod skyBase port): the authored SA night gradient is
  // near-black, so prod adds the moon's cool Rayleigh scatter (halo + a soft lift of its hemisphere) and
  // the warm URBAN skyglow band at the horizon (San Andreas is a metropolis — city nights are never
  // black; the deck reflects the city light, so overcast makes it BRIGHTER). Living in the shared base,
  // it feeds the world fog too — night fog matches the glowing horizon, the 068 invariant.
  // FADE (sky round 3 — "it kicks in abruptly", the field report, paraphrased): the sink window is widened to the whole post-sunset margin
  // AND the glow rides dn (the hour-long dusk ramp) — the city light breathes in with the darkness
  // instead of snapping on in the ~40 s the sun needs to cross a narrow horizon band.
  let pbrNight = (1.0 - smoothstep(-0.22, -0.01, frame.sunDir.y)) * frame.params.x;
  if (pbrNight > 0.01) {
    // env.moonColor ≈ (0.34, 0.44, 0.72) × its CPU gate (peak 0.5 × skylight 0.6 → b = 0.216) — recover
    // the gate so the glow follows the night band/cloud fade without a new UBO slot.
    let moonGate = clamp(frame.moonColor.b / 0.216, 0.0, 1.0);
    let moonGlow = vec3f(0.45, 0.62, 1.0) * (0.055 * moonGate);
    let cityGlow = vec3f(1.0, 0.58, 0.3) * (0.03 * (1.0 + frame.sunCorona.w * 1.2));
    let moonHalo = pow(max(dot(dir, frame.moonDir.xyz), 0.0), 8.0);
    let moonHemi = 0.5 + 0.5 * dot(dir, frame.moonDir.xyz);
    let band = pow(1.0 - clamp(dir.y, 0.0, 1.0), 6.0);
    col += (moonGlow * (moonHalo * 0.6 + moonHemi * moonHemi * 0.12) + cityGlow * band) * pbrNight;
  }
  return col;
}

// Sun + moon discs, split from the gradient so the cloud layer can OCCLUDE them (row 15): the disc
// overshoot survives a partial alpha mix, so clouds must attenuate this term, not blend over it.
fn skyCelestialFor(dir: vec3f) -> vec3f {
  // The prod-look sun (field round 3): a FILLED disc in the timecyc sunCore colour (yellow/orange —
  // prod colours its sun mesh with exactly this column) + an exponential warm corona in sunCorona.
  // Angular sizing comes from timecyc sunSize via sunCore.w. The 3–6× overshoot feeds the godrays
  // post pass (bright-pass threshold) and clips to a hot centre in the swapchain.
  let sunDot = clamp(dot(dir, frame.sunDir.xyz), -1.0, 1.0);
  let ang = acos(sunDot);
  let coreR = max(frame.sunCore.w, 1e-4);
  let disc = (1.0 - smoothstep(coreR * 0.75, coreR, ang)) * 6.0;
  let corona = exp(-ang / (coreR * 2.2)) * 2.6;
  let glow = exp(-ang / (coreR * 8.0)) * 0.5;
  let sun = frame.sunCore.rgb * disc + frame.sunCorona.rgb * (corona + glow);
  let moon = moonFor(dir);
  // The sea-horizon line CLIPS the discs (field: the sun used to just fade out at ground level): drivers
  // now let the arcs sink below y=0, and pixels under the horizon drop the disc — the sun/moon visibly
  // set INTO the ocean, upper sliver last. Soft edge = a few arcminutes of waterline shimmer.
  let horizonClip = smoothstep(-0.003, 0.005, dir.y);
  return (sun + moon) * horizonClip;
}

// Shared value-noise stack (prod SKY_BASE port): hash21 seeds the starfield (sky module) AND the
// procedural cloud layers; skyFbm drives cirrus (sky module) + the cumulus deck below. Lives in the
// frame include because cloudLayerFor (car reflections, every rigid consumer) needs cumulus too.
fn hash21(cell: vec2f) -> f32 {
  return fract(sin(dot(cell, vec2f(127.1, 311.7))) * 43758.5453);
}

fn skyVnoise(p: vec2f) -> f32 {
  let i = floor(p);
  let f = fract(p);
  let u = f * f * (3.0 - 2.0 * f);
  return mix(
    mix(hash21(i), hash21(i + vec2f(1.0, 0.0)), u.x),
    mix(hash21(i + vec2f(0.0, 1.0)), hash21(i + vec2f(1.0, 1.0)), u.x),
    u.y,
  );
}

fn skyFbm(p: vec2f) -> f32 {
  var v = 0.0;
  var a = 0.5;
  var q = p;
  for (var i = 0u; i < 5u; i += 1u) {
    v += a * skyVnoise(q);
    q = q * 2.03 + vec2f(1.7);
    a *= 0.5;
  }
  return v;
}

// Cloud palette (sky v2): timecyc lowClouds/bottomClouds carry the authored HUE (pink dawns, blue
// nights) but their LUMINANCE was authored for SA's gamma-space multiply — used raw under linear+ACES
// the noon deck reads as near-black smudges (field: the panorama looked navy for the same reason).
// Same move as the sky-LUT mood tint: normalize the palette to a hue and drive brightness from a wide
// day ease (sunlit white tops ~1.05, shaded bases ~0.58; night floors keep moonlit decks visible).
struct CloudPalette {
  top: vec3f,
  bottom: vec3f,
}

fn cloudPalette() -> CloudPalette {
  let day = smoothstep(-0.08, 0.25, frame.sunDir.y);
  let top = frame.cloudTop.rgb;
  let bottom = frame.cloudBottom.rgb;
  let topHue = top / max(max(top.r, max(top.g, top.b)), 1e-3);
  let botHue = bottom / max(max(bottom.r, max(bottom.g, bottom.b)), 1e-3);
  return CloudPalette(topHue * mix(0.10, 1.05, day), botHue * mix(0.05, 0.58, day));
}

// CUMULUS (074/06 row 4 sky v2 — the prod applyClouds layer-2 port; the painted panorama is REMOVED):
// coverage-thresholded fbm masses driven by the weather's cloud cover, lit tops / dark undersides shaped
// by a second mass octave, one high-frequency detail octave (full coverage otherwise degenerates into
// huge soft smears), the normalized cloud palette above, golden-hour sun rims with the horizon EASE
// (the audit rule — a bare sunDir.y sign test snaps at 20:00/6:00). rgb = lit cloud colour, a = density.
fn cumulusFor(dir: vec3f, sunDot: f32) -> vec4f {
  if (dir.y <= 0.02) {
    return vec4f(0.0);
  }
  let t = frame.params2.z;
  // SOFTENED plane projection dir.xz/(dir.y + 0.18) — a hard floor (max(dir.y, k)) FREEZES the mapping
  // below k: every elevation under it samples the same field point along a vertical line, and storm
  // decks smeared DOWN to the horizon in vertical streaks (field bug, present in prod too at k=0.12).
  // The soft denominator compresses features toward the horizon like real perspective instead.
  let p = dir.xz / (dir.y + 0.18);
  // n/mass come from the BAKED field (one tap — the field pass owns the 10-vnoise cost per 256² texel,
  // so a full storm deck no longer scales with the swapchain resolution; field round: cloudy stuttered
  // at 2× retina). The field bakes drift and the per-weather clump scale in, so p maps statically.
  let field = textureSampleLevel(cloudField, skyLutSampler, p / 12.0 + vec2f(0.5), 0.0);
  let n = field.r;
  let cover = clamp(frame.sunCorona.w, 0.0, 1.0);
  // Clear-sky edge 0.62 (prod ran 0.92): prod could afford an empty procedural deck because the painted
  // panorama carried the fair-weather clouds — retired now, so a sunny LS day (cover ~0.14) must still
  // scatter real puffs (~35-40 % of the dome at density ~0.25 — measured; 0.74 read as an empty sky in
  // the field). Heavy weathers converge to the same full deck as prod.
  let edge = mix(0.62, -0.25, cover);
  let density = smoothstep(edge, edge + 0.20, n);
  // Early out for clear pixels — skip the detail octave and the palette math.
  if (density <= 0.002) {
    return vec4f(0.0);
  }
  let mass = field.g;
  // cloudTop.w = the per-weather clump-size multiplier (sky v2: SMOG big dirty clumps, storm banks) —
  // recomputed here only for the in-shader DETAIL octave (it needs a higher frequency than the field).
  let cuv = p * (0.45 * frame.cloudTop.w) + vec2f(t * 0.004, t * 0.002);
  let palette = cloudPalette();
  var cloud = mix(palette.bottom, palette.top, smoothstep(0.30, 0.80, n));
  let bright = smoothstep(0.20, 0.72, n) * mix(0.35, 1.0, smoothstep(0.30, 0.72, mass));
  cloud *= mix(1.0, mix(0.16, 1.0, bright), frame.params3.z);
  // Detail octave STRENGTHENS with coverage: a full deck has density 1 everywhere, so all its readable
  // structure must come from colour modulation (field: CLOUDY read as a flat grey wash without this).
  let det = skyVnoise(cuv * 5.7 + vec2f(t * 0.006, 0.0));
  cloud *= 1.0 + (det - 0.5) * mix(0.48, 0.9, cover);
  let golden = (0.25 + 0.65 * (1.0 - clamp(frame.sunDir.y, 0.0, 1.0))) *
    smoothstep(0.0, 0.045, frame.sunDir.y);
  let clearness = 1.0 - cover * 0.85;
  cloud += frame.sunCorona.rgb * (pow(sunDot, 5.0) * golden * clearness * (0.25 + 0.75 * bright));
  let horizon = smoothstep(0.02, 0.30, dir.y);
  return vec4f(cloud, density * horizon);
}

// CIRRUS (prod applyClouds layer 1): thin, high, stretched wisps drifting slowly on their own heading —
// what makes a clear day sky read ALIVE. They belong to clear skies, so coverage suppresses them;
// timecyc cloud colours tint them. Lives in the FRAME include (074/21 P2): the fog colour composites it
// too, and a sky-module-only helper would be an unresolved call target for world/rigid/water consumers
// (the black-canvas gotcha, twice already).
fn cirrusFor(dir: vec3f, sunDot: f32) -> vec4f {
  if (dir.y <= 0.02) {
    return vec4f(0.0);
  }
  let t = frame.params2.z;
  // Same softened projection as the cumulus (a hard floor froze the band under it into vertical smears).
  let cuv = dir.xz / (dir.y + 0.18) * vec2f(0.9, 0.35) + vec2f(t * 0.0013, t * -0.0007) + vec2f(31.7);
  let cover = clamp(frame.sunCorona.w, 0.0, 1.0);
  let amount = smoothstep(0.60, 0.92, skyFbm(cuv)) * (1.0 - cover) * 0.55;
  // The golden term peaks AT the horizon, so a hard y-above-0 select SNAPPED it (0 → 0.9) the frame the
  // sun crossed — the 19:59/5:59 sky jump. ~8 game-minutes of climb (y 0 → 0.045) ease it in/out instead.
  let golden = (0.25 + 0.65 * (1.0 - clamp(frame.sunDir.y, 0.0, 1.0))) *
    smoothstep(0.0, 0.045, frame.sunDir.y);
  // The normalized palette (sky v2) — the raw timecyc luminance read as dark smears under linear+ACES.
  let palette = cloudPalette();
  let tint = mix(palette.bottom, palette.top, 0.85) +
    frame.sunCorona.rgb * (golden * 0.2 + pow(sunDot, 5.0) * golden * 0.5);
  let horizon = smoothstep(0.02, 0.30, dir.y);
  return vec4f(tint, amount * horizon);
}

// The cloud layer in a direction, factored out of fsSky so a CAR can reflect the clouds too: rgb = the lit
// cloud colour, a = its coverage. The analytic reflection fallback mirrors the procedural cumulus, so
// probe-off cars still catch clouds; the probe path renders the real fsSky and needs nothing here.
// (The painted-panorama branch that lived here was REMOVED 2026-07-17 with the dome textures.)
fn cloudLayerFor(dir: vec3f) -> vec4f {
  if (dir.y <= 0.0) {
    return vec4f(0.0);
  }
  return cumulusFor(dir, max(dot(dir, frame.sunDir.xyz), 0.0));
}

/**
 * The MOON (074/06 row 6, B6): the real SA coronamoon sprite plus a PHASE.
 *
 * Vanilla SA fakes its phases by cropping the sprite, which gives a sliced disc rather than a crescent. We
 * light a sphere instead: the moon's surface normal is reconstructed from the disc coordinates, and the lit
 * fraction follows a phase angle (params4.y, advanced by the host with the in-game days). That yields a real
 * terminator — waxing crescent through full and back — for the cost of a dot product.
 *
 * moonColor is BLACK by day, so this whole term dies with it.
 */
fn moonFor(dir: vec3f) -> vec3f {
  let moonDot = dot(dir, frame.moonDir.xyz);
  // Local disc frame: where in the moon's face this view direction lands, in [-1, 1].
  let right = normalize(cross(vec3f(0.0, 1.0, 0.0), frame.moonDir.xyz));
  let up = cross(frame.moonDir.xyz, right);
  let radius = max(frame.sunCore.w * MOON_DISC_SCALE, 1e-4);
  let disc = vec2f(dot(dir, right), dot(dir, up)) / radius;
  let r = length(disc);

  // The sprite across the disc: rgb carries the CRATERS, alpha the round shape (normalised by the host).
  let uv = disc * 0.5 + vec2f(0.5);
  let texel = textureSample(coronaSprites, skyLutSampler, uv, 1u);
  let face = texel.a;

  // Phase: rebuild the surface normal of the sphere at this point and light it from the phase direction.
  let z = sqrt(max(0.0, 1.0 - min(r * r, 1.0)));
  let normal = normalize(right * disc.x + up * disc.y + frame.moonDir.xyz * z);
  let angle = frame.params4.y * 6.2831853;
  let sunward = normalize(right * sin(angle) + frame.moonDir.xyz * (-cos(angle)));
  // A soft terminator: earthshine keeps the dark limb faintly visible, as it is in life.
  let lit = smoothstep(-0.08, 0.12, dot(normal, sunward)) * 0.92 + 0.08;

  let body = texel.rgb * (face * lit * step(r, 1.0) * MOON_BODY_GAIN);
  // A wide soft halo marks the moon's place in the horizon band even when the disc is a thin crescent.
  let halo = pow(max(moonDot, 0.0), 96.0) * 2.2;
  // moonColor now carries the prod-strength LIGHT (peak b 0.216, was 0.105) — rescale so the shipped
  // disc/halo brightness stays exactly as field-accepted.
  return frame.moonColor.rgb * 0.486 * (body + vec3f(halo));
}

// The sky the WORLD FOG dissolves into (068 invariant): the gradient + only the WIDE sun haze. The hot
// disc/corona must NOT be here — fogged silhouettes picked it up and the sun "shone through buildings"
// (field round 3). Prod's disc is a separate mesh for the same reason.
fn skyFogFor(dir: vec3f) -> vec3f {
  let sunDot = max(dot(dir, frame.sunDir.xyz), 0.0);

  return skyBaseFor(dir) + frame.sunCorona.rgb * pow(sunDot, 8.0) * 0.06;
}

// Fog v2 (074/21 P2): a pixel dissolving at the cut must equal the sky INCLUDING its procedural cloud
// decks — with the base-only colour, distant towers read as flat pale silhouettes against any clouded
// sky, and close-fog weathers (FOGGY farClip 250) seam hard against a coloured dawn deck. Same
// cirrus+cumulus composite as fsSky; discs/stars stay excluded (the sun-through-buildings regression,
// field round 3). The clouds ride a NEAR-DISSOLVE weight, not the raw fog factor (074/21 field round,
// "clouds walk onto buildings"): partial fog is in-scattered HAZE — the atmosphere gradient — while the
// building still OCCLUDES the deck behind it, so a mid-fog tower must not pick up the deck's colour
// (a red dawn deck painted tower facades pink). The weight reaches 1 inside the hard-cut band
// (fog ≥ 0.85·cut), exactly where the pale-silhouette fix lives — the dissolve stays seamless.
// The cloud math only runs on meaningfully fogged pixels — the branch is legal in non-uniform control
// flow because every cloud tap uses explicit-LOD sampling — and cumulus/cirrus carry their own
// early-outs, so the clear-range majority of the frame pays one comparison.
fn fogColorFor(dir: vec3f, fogFactor: f32) -> vec3f {
  var col = skyFogFor(dir);
  let cloudW = smoothstep(0.7, 1.0, fogFactor) * frame.params3.w;
  if (cloudW > 0.002) {
    let sunDot = max(dot(dir, frame.sunDir.xyz), 0.0);
    let cirrus = cirrusFor(dir, sunDot);
    col = mix(col, cirrus.rgb, cirrus.a * cloudW);
    let cumulus = cumulusFor(dir, sunDot);
    col = mix(col, cumulus.rgb, cumulus.a * cloudW);
  }

  return col;
}

// Local light pool (074/06 row 7): up to 64 point lights (2dfx street lamps + host dynamics — vehicle
// headlights), CPU-filled each frame. The world consumes it in the VERTEX shader (SA is vertex-lit and
// world verts ≪ pixels); small dynamic entities sample it per pixel. Bounded loop (count ≤ 64 — guardrail).
struct LocalLight {
  position: vec4f, // xyz world + radius
  color: vec4f,    // linear RGB × intensity; w spare
  // xyz = the direction a SPOT points, w = the cosine of its half-angle. w >= 1.5 means POINT (no cone) —
  // the same sentinel the three pool uses. Headlights NEED this: as a point light a headlight floods the
  // whole street, the road behind the car included.
  dir: vec4f,
};
@group(0) @binding(3) var<storage, read> localLights: array<LocalLight>;

// A RANGE of the pool, so the world can split it: static lamps per vertex (they never move, and world verts
// ≪ pixels), moving lights per pixel. A headlight shaded per vertex is a disaster — SA's road polygons are
// tens of metres wide, so the beam lands between vertices: it blotches along the mesh normals and disappears
// outright when the car sits mid-polygon.
// NB: "from" is a WGSL RESERVED KEYWORD (so is "meta", which bit the B2 vertex layout) — hence first/last.
// The naga guardrails do not catch reserved words; assertGuardrails now does, so the browser stops being
// the first thing to notice.
fn localLightRange(world: vec3f, normal: vec3f, first: u32, last: u32) -> vec3f {
  var sum = vec3f(0.0);
  let count = min(last, 64u);
  for (var index = first; index < count; index += 1u) {
    let light = localLights[index];
    var toLight = light.position.xyz - world;
    let dist = length(toLight);
    let radius = light.position.w;
    if (dist < radius) {
      toLight = toLight / max(dist, 0.001);
      let spot = light.dir.w < 1.5;
      // Cone falloff SQUARED toward the rim — a flat plateau reads as a hard-edged searchlight blob.
      var cone = 1.0;
      if (spot) {
        cone = smoothstep(light.dir.w, min(light.dir.w + 0.30, 1.0), dot(-toLight, light.dir.xyz));
        cone = cone * cone;
      }
      // WRAP: a headlight grazes the road almost tangentially, so a hard N·L collapses the beam to nothing.
      // Wrapping keeps the road pool readable while walls still take more light when they face the lamp.
      let wrap = select(0.4, 0.25, spot);
      let ndl = clamp((dot(normal, toLight) + wrap) / (1.0 + wrap), 0.0, 1.0);
      let falloff = 1.0 - dist / radius;
      sum += light.color.rgb * (ndl * cone * falloff * falloff);
    }
  }
  return sum;
}

/** Dynamic half only — the world's PER-PIXEL term. */
fn localLightDynamic(world: vec3f, normal: vec3f) -> vec3f {
  return localLightRange(world, normal, 0u, u32(frame.params4.x));
}

/** Static 2dfx half only — the world's PER-VERTEX term. */
fn localLightStatic(world: vec3f, normal: vec3f) -> vec3f {
  return localLightRange(world, normal, u32(frame.params4.x), u32(frame.params3.x));
}

// The ground half of the hemisphere: the road under a dynamic model, dark, so the sky/ground split reads as
// shape rather than as a tint. Deliberately the same 0.10 the reflection path uses for asphalt.
const AMBIENT_GROUND = 0.10;

/**
 * Hemispheric indirect weight for a DYNAMIC model (car OR ped): how much SKY this surface sees, 1.0 on a
 * horizontal panel down to AMBIENT_GROUND on one facing straight down.
 *
 * What it fixes: the indirect term was a flat vec3f(frame.params.y) — one constant on every pixel, with no
 * normal, no position and no occlusion in it. By day the sun's N.L gradient hides that; at night there IS no
 * sun, the indirect term dominates, and the body collapsed into a single flat colour with no readable edges.
 * The map never had the problem because its indirect term is prelit x params.y x ao, i.e. baked lighting AND
 * baked AO — neither of which a car or ped has (no vehicle or ped in the game ships a prelit set).
 *
 * A WEIGHT, not a colour, and normalised against the sky rather than the hemisphere mean: the term can only
 * ever DARKEN relative to the old flat fill. Normalising against the mean would conserve energy but brighten
 * upward-facing surfaces by ~1.8x — on bodies already reported as too bright at night, that would have made
 * the loudest surfaces worse.
 *
 * Deliberately scalar and per-PIXEL over a normal the shader already has; params.y was neutral before this,
 * so no colour is lost. Shared by the rigid (vehicle) and ped paths through <frame>.
 */
fn skyVisibility(normal: vec3f) -> f32 {
  return mix(AMBIENT_GROUND, 1.0, normal.y * 0.5 + 0.5);
}

/**
 * What a DYNAMIC model's indirect term is worth against the WORLD's (plan 084).
 *
 * The map's indirect is prelit x params.y x ao and a car's was params.y alone — the same lamp, but the
 * map dims it twice and the car not at all. Measured at full night that read car 0.70 against map ~0.13.
 * The missing half is the two factors a car has no data for: this constant stands in for the mean PRELIT
 * (SA's map models average 88/255 luma), and (for vehicles) the per-instance AO the builder computes.
 */
const DYNAMIC_INDIRECT = 0.35;
`,particle:`
#include <frame>

// 2dfx PARTICLES (074/06 row 13, B6). The FX system's keyframed tracks are BAKED by the host into a small
// per-system record; the whole lifecycle then loops in the VERTEX shader, so a hundred smoke plumes cost
// zero CPU per frame. One draw per blend mode for the entire map (the system index rides per instance).
//
// A particle's life: it is born at its emitter, is thrown by its velocity, is pulled by the system's force
// (gravity for sparks, buoyancy for smoke), and grows/fades along piecewise-linear envelopes sampled at
// age 0 / 0.5 / 1 — exactly the shape the prod path bakes out of effects.fxp.
struct ParticleSystem {
  // xyz = force (gravity/buoyancy), w = texture layer.
  force: vec4f,
  // Size envelope at age 0 / 0.5 / 1, w = draw distance.
  size: vec4f,
  color0: vec4f, // rgb at age 0, a = alpha at age 0
  color1: vec4f, // rgb at age 0.5, a = alpha at 0.5
  color2: vec4f, // rgb at age 1, a = alpha at 1
};
@group(1) @binding(0) var<storage, read> systems: array<ParticleSystem>;
@group(1) @binding(1) var fxTexture: texture_2d_array<f32>;
@group(1) @binding(2) var fxSampler: sampler;

// One-shot lane (089/01): the dynamic pipelines flip this override — the age CLAMPS instead of looping,
// and a particle past its life collapses (its CPU pool prunes it on the same clock next frame).
override oneShot: bool = false;

struct ParticleIn {
  @location(0) corner: vec2f,
  @location(1) spawn: vec3f,
  @location(2) velocity: vec3f,
  // x = lifetime seconds, y = phase offset (so a plume is a continuous stream, not a pulse), z = system.
  @location(3) params: vec3f,
};

struct ParticleOut {
  @builtin(position) clip: vec4f,
  @location(0) uv: vec2f,
  @location(1) color: vec4f,
  @location(2) @interpolate(flat) layer: u32,
};

/** Piecewise-linear envelope through three keys at age 0 / 0.5 / 1. */
fn envelope3(k0: f32, k1: f32, k2: f32, age: f32) -> f32 {
  return select(mix(k1, k2, (age - 0.5) * 2.0), mix(k0, k1, age * 2.0), age < 0.5);
}

fn envelope3v(k0: vec3f, k1: vec3f, k2: vec3f, age: f32) -> vec3f {
  return select(mix(k1, k2, (age - 0.5) * 2.0), mix(k0, k1, age * 2.0), age < 0.5);
}

@vertex
fn vsParticle(in: ParticleIn) -> ParticleOut {
  let system = systems[u32(in.params.z)];
  let life = max(in.params.x, 0.01);
  // The phase staggers the stream: every particle of a plume is at a different point of the SAME loop.
  // One-shot instances instead carry phase = -spawnTime, so cycles is that particle's own age.
  let cycles = (frame.params2.z + in.params.y) / life;
  let age = select(fract(cycles), clamp(cycles, 0.0, 1.0), oneShot);
  let t = age * life;
  let world = in.spawn + in.velocity * t + system.force.xyz * (0.5 * t * t);
  let size = envelope3(system.size.x, system.size.y, system.size.z, age);
  let rgb = envelope3v(system.color0.rgb, system.color1.rgb, system.color2.rgb, age);
  let alpha = envelope3(system.color0.a, system.color1.a, system.color2.a, age);

  // Camera-facing quad, like the coronas. The quad spans [-1, 1], and the authored size is a DIAMETER (prod
  // projects it as a point-sprite width) — so the half-extent is size*0.5. Scaling by the full size makes
  // every particle twice as wide as authored, and a fire turns into a soft glowing cloud.
  let toEye = normalize(frame.camera.xyz - world);
  let right = normalize(cross(vec3f(0.0, 1.0, 0.0), toEye));
  let up = cross(toEye, right);
  let corner = world + (right * in.corner.x + up * in.corner.y) * (size * 0.5);

  var out: ParticleOut;
  out.clip = frame.viewProj * vec4f(corner, 1.0);
  // The unit quad spans [-1, 1], so the UV is corner*0.5 + 0.5. Using corner + 0.5 sends it to [-0.5, 1.5],
  // and the clamp-to-edge sampler then smears the sprite's border texels into a SQUARE of solid colour.
  out.uv = in.corner * 0.5 + vec2f(0.5);
  // Distance cull: collapse the quad rather than branch (a degenerate triangle costs nothing).
  let dist = length(world - frame.camera.xyz);
  let visible = f32(dist < system.size.w && size > 0.0 && !(oneShot && cycles >= 1.0));
  out.clip = select(vec4f(0.0, 0.0, -1.0, 1.0), out.clip, visible > 0.5);
  // Per-spawn opacity rides the FRACTION of the system slot (089/02): 1 - fract(z), so the baked lane's
  // integer slots read fully opaque and the instance layout stays untouched.
  let spawnAlpha = 1.0 - fract(in.params.z);
  out.color = vec4f(rgb, alpha * visible * spawnAlpha);
  out.layer = u32(system.force.w);
  return out;
}

@fragment
fn fsParticle(in: ParticleOut) -> @location(0) vec4f {
  let texel = textureSample(fxTexture, fxSampler, in.uv, in.layer);
  let a = texel.a * in.color.a;
  // PREMULTIPLIED: one pipeline blends (one, 1-src-a) for smoke, the other (one, one) for fire/sparks.
  return vec4f(texel.rgb * in.color.rgb * a, a);
}
`,ped:`
#include <frame>

// Skinning probe (074/08 B1): one skinned entity through the intended dynamics path — matrices in a
// STORAGE buffer (slot 0 = the model matrix carrying the GTA→engine axis change, bone palettes follow),
// 4-bone vertex blend, textured sun/indirect lighting + the shared fog. No prelit — peds are dynamically
// lit (the plan-034 night fill joins in M3).
struct PedVsIn {
  @location(0) position: vec3f,
  @location(1) normal: vec3f,
  @location(2) uv: vec2f,
  @location(3) joints: vec4<u32>,
  @location(4) weights: vec4f,
};

struct PedVsOut {
  @builtin(position) clip: vec4f,
  @location(0) uv: vec2f,
  @location(1) normal: vec3f,
  @location(2) world: vec3f,
};

@group(1) @binding(0) var<storage, read> pedMatrices: array<mat4x4f>;
@group(1) @binding(1) var pedTexture: texture_2d<f32>;
@group(1) @binding(2) var pedSampler: sampler;

@vertex
fn vsPed(in: PedVsIn) -> PedVsOut {
  let source = vec4f(in.position, 1.0);
  let skinned =
    (pedMatrices[1u + in.joints.x] * source) * in.weights.x +
    (pedMatrices[1u + in.joints.y] * source) * in.weights.y +
    (pedMatrices[1u + in.joints.z] * source) * in.weights.z +
    (pedMatrices[1u + in.joints.w] * source) * in.weights.w;
  let sourceNormal = vec4f(in.normal, 0.0);
  let skinnedNormal =
    (pedMatrices[1u + in.joints.x] * sourceNormal) * in.weights.x +
    (pedMatrices[1u + in.joints.y] * sourceNormal) * in.weights.y +
    (pedMatrices[1u + in.joints.z] * sourceNormal) * in.weights.z +
    (pedMatrices[1u + in.joints.w] * sourceNormal) * in.weights.w;
  let world = pedMatrices[0] * vec4f(skinned.xyz, 1.0);
  var out: PedVsOut;
  out.clip = frame.viewProj * world;
  out.uv = in.uv;
  out.normal = normalize((pedMatrices[0] * vec4f(skinnedNormal.xyz, 0.0)).xyz);
  out.world = world.xyz;
  return out;
}

@fragment
fn fsPed(in: PedVsOut) -> @location(0) vec4f {
  let texel = textureSample(pedTexture, pedSampler, in.uv);
  if (texel.a < 0.5) {
    discard;
  }
  let normal = normalize(in.normal);
  let sunNdl = max(dot(normal, frame.sunDir.xyz), 0.0);
  let moonNdl = clamp((dot(normal, frame.moonDir.xyz) + 0.6) / 1.6, 0.0, 1.0);
  // Hemispheric indirect, the SAME term the vehicles use (plan 084 → 087 ped): a flat vec3f(frame.params.y)
  // gave the body no readable edges at night, when the sun term is gone and indirect dominates. No per-model
  // AO for a ped (no baked set), so DYNAMIC_INDIRECT x skyVisibility is the whole weight.
  let ambient = frame.params.y * DYNAMIC_INDIRECT * skyVisibility(normal);
  // STATIC lamps only, like the vehicles: the driver sits a metre in FRONT of his own tail lights, and the
  // dynamic pool would wash him red from behind every time he brakes.
  let lit = vec3f(ambient) + frame.sunColor.rgb * (sunNdl * frame.params.z) + frame.moonColor.rgb * moonNdl +
    localLightStatic(in.world, normal);
  var color = texel.rgb * lit;
  // Same unified fog shape as fsWorld (068 invariant: distant peds dissolve into the sky behind them).
  let toCamera = in.world - frame.camera.xyz;
  let dist = length(toCamera);
  let viewDir = toCamera / max(dist, 0.001);
  let fogD = max(dist - frame.fog.y, 0.0);
  let fogK = 2.0 / max(frame.fog.x - frame.fog.y, 1.0);
  var fogFactor = 1.0 - exp(-(fogK * fogD) * (fogK * fogD));
  let heightAtten = mix(frame.fog.w, 1.0, exp(-max(in.world.y, 0.0) * frame.fog.z));
  fogFactor = fogFactor * heightAtten;
  fogFactor = max(fogFactor, smoothstep(frame.fog.x * 0.85, frame.fog.x, dist));
  color = mix(color, fogColorFor(viewDir, fogFactor), fogFactor);
  return vec4f(color, 1.0);
}
`,post:`
// Godrays composite (074/09 stage 1): the scene renders into a LINEAR rgba16float target (the sun disc's
// 3–6× overshoot survives), and this fullscreen pass radial-blurs the thresholded brightness toward the
// sun's screen position — occlusion is inherent (geometry in front of the sun leaves no bright pixels, so
// rays only stream through gaps: the prod GodRaysEffect look). Output goes to the sRGB swapchain view.
struct Post {
  // sun = [uv.x, uv.y, intensity (0 = off), decay per tap]; tint = [rgb godray colour, brightness threshold].
  sun: vec4f,
  tint: vec4f,
  // params = [ACES tonemap 0/1, bloom intensity (0 = off), reserved, reserved].
  params: vec4f,
};
@group(0) @binding(0) var<uniform> post: Post;
@group(0) @binding(1) var scene: texture_2d<f32>;
@group(0) @binding(2) var sceneSampler: sampler;
// Bloom chain result (half-res 16f, 074/09) — bilinear-upsampled here by the sampler.
@group(0) @binding(3) var bloomTex: texture_2d<f32>;

struct PostOut {
  @builtin(position) clip: vec4f,
  @location(0) uv: vec2f,
};

@vertex
fn vsPost(@builtin(vertex_index) index: u32) -> PostOut {
  // One oversized triangle covers the viewport (no vertex buffer).
  var corners = array<vec2f, 3>(vec2f(-1.0, -3.0), vec2f(3.0, 1.0), vec2f(-1.0, 1.0));
  let corner = corners[index];
  var out: PostOut;
  out.clip = vec4f(corner, 0.0, 1.0);
  out.uv = vec2f(corner.x * 0.5 + 0.5, 0.5 - corner.y * 0.5);
  return out;
}

const GODRAY_TAPS = 20u;

// ACES filmic (074/09): the EXACT curve prod is calibrated against — three's Stephen Hill fit as consumed
// by postprocessing's ToneMappingEffect (exposure 1). Matrices carry sRGB↔AP1 (columns, transposed from
// the source like three's); the /0.6 scale is three's brighter-viewing-environment adjustment (#19621).
fn rrtAndOdtFit(v: vec3f) -> vec3f {
  let a = v * (v + vec3f(0.0245786)) - vec3f(0.000090537);
  let b = v * (0.983729 * v + vec3f(0.4329510)) + vec3f(0.238081);
  return a / b;
}

fn acesFilmic(color: vec3f) -> vec3f {
  let inputMat = mat3x3f(
    vec3f(0.59719, 0.07600, 0.02840),
    vec3f(0.35458, 0.90834, 0.13383),
    vec3f(0.04823, 0.01566, 0.83777),
  );
  let outputMat = mat3x3f(
    vec3f(1.60475, -0.10208, -0.00327),
    vec3f(-0.53108, 1.10813, -0.07276),
    vec3f(-0.07367, -0.00605, 1.07602),
  );
  let mapped = outputMat * rrtAndOdtFit(inputMat * (color / 0.6));
  return clamp(mapped, vec3f(0.0), vec3f(1.0));
}

@fragment
fn fsPost(in: PostOut) -> @location(0) vec4f {
  var col = textureSampleLevel(scene, sceneSampler, in.uv, 0.0).rgb;
  if (post.sun.z > 0.0) {
    let delta = (post.sun.xy - in.uv) / f32(GODRAY_TAPS);
    var uv = in.uv;
    var weight = 1.0;
    var acc = vec3f(0.0);
    for (var tap = 0u; tap < GODRAY_TAPS; tap += 1u) {
      uv += delta;
      let sample_ = textureSampleLevel(scene, sceneSampler, uv, 0.0).rgb;
      acc += max(sample_ - vec3f(post.tint.w), vec3f(0.0)) * weight;
      weight *= post.sun.w;
    }
    col += acc * post.tint.rgb * (post.sun.z / f32(GODRAY_TAPS));
  }
  // Bloom composite (prod SCREEN blend: dst + src − min(dst·src, 1)); intensity 0 = a no-op.
  let bloomSrc = textureSampleLevel(bloomTex, sceneSampler, in.uv, 0.0).rgb * post.params.y;
  col = col + bloomSrc - min(col * bloomSrc, vec3f(1.0));
  // Tonemap LAST (prod order: godrays → bloom → ACES) — the HDR overshoot feeds the effects above,
  // ACES compresses the sum; the sRGB swapchain view encodes on write.
  if (post.params.x > 0.5) {
    col = acesFilmic(col);
  }
  return vec4f(col, 1.0);
}
`,probe:`
@group(0) @binding(0) var probeInput: texture_2d<f32>;
@group(0) @binding(1) var probeInputSampler: sampler;

struct ProbeMipOut {
  @builtin(position) clip: vec4f,
  @location(0) uv: vec2f,
};

@vertex
fn vsProbeMip(@builtin(vertex_index) index: u32) -> ProbeMipOut {
  var corners = array<vec2f, 3>(vec2f(-1.0, -3.0), vec2f(3.0, 1.0), vec2f(-1.0, 1.0));
  let corner = corners[index];
  var out: ProbeMipOut;
  out.clip = vec4f(corner, 0.0, 1.0);
  out.uv = vec2f(corner.x * 0.5 + 0.5, 0.5 - corner.y * 0.5);
  return out;
}

@fragment
fn fsProbeMip(in: ProbeMipOut) -> @location(0) vec4f {
  return textureSampleLevel(probeInput, probeInputSampler, in.uv, 0.0);
}

// Face blit, V-FLIPPED: cube faces are stored in the GL convention (t = 0 at the face's TOP direction),
// but a WebGPU render pass puts NDC y = +1 in row 0 — rendering straight into the face would come out
// upside-down, and fixing it in the projection would flip the triangle winding and break back-face culling
// inside the recorded bundles. The flip lives here instead: a pure-rotation camera renders the face, the
// resolve lands in a scratch target, and this pass writes it into the cube the right way up.
@fragment
fn fsProbeBlit(in: ProbeMipOut) -> @location(0) vec4f {
  return textureSampleLevel(probeInput, probeInputSampler, vec2f(in.uv.x, 1.0 - in.uv.y), 0.0);
}
`,"probe-view":`
#include <frame>

@group(1) @binding(0) var probeViewCube: texture_cube<f32>;
@group(1) @binding(1) var probeViewSampler: sampler;

struct ProbeViewOut {
  @builtin(position) clip: vec4f,
  @location(0) ndc: vec2f,
};

@vertex
fn vsProbeView(@builtin(vertex_index) index: u32) -> ProbeViewOut {
  var corners = array<vec2f, 3>(vec2f(-1.0, -3.0), vec2f(3.0, 1.0), vec2f(-1.0, 1.0));
  let corner = corners[index];
  var out: ProbeViewOut;
  // Reversed-Z near plane — the debug view overdraws everything.
  out.clip = vec4f(corner, 1.0, 1.0);
  out.ndc = corner;
  return out;
}

@fragment
fn fsProbeView(in: ProbeViewOut) -> @location(0) vec4f {
  let near = frame.invViewProj * vec4f(in.ndc, 1.0, 1.0);
  let far = frame.invViewProj * vec4f(in.ndc, 0.0, 1.0);
  let dir = normalize(far.xyz / far.w - near.xyz / near.w);
  // Left half = sharp mip, right half = the roughness mip the paint samples — both must look like the world.
  let lod = select(0.0, 1.2, in.ndc.x > 0.0);
  return vec4f(textureSampleLevel(probeViewCube, probeViewSampler, dir, lod).rgb, 1.0);
}
`,rigid:`
#include <frame>

// Rigid-part dynamics (074/08 B2→B5): vehicle-style entities — CPU-flattened part matrices in a storage
// buffer, parts drawn with firstInstance = slot × partCount + part (instance_index reads the matrix).
// slots.x = texture-array layer, slots.y = the lamps-on twin, slots.z = the carcols PAINT slot (resolved
// per instance — B5 shares one model across differently-painted cars). fsRigid = opaque (alpha forced 1),
// fsRigidBlend = premultiplied glass on the blend pipeline.
struct RigidVsIn {
  @builtin(instance_index) instance: u32,
  @location(0) position: vec3f,
  @location(1) normal: vec3f,
  @location(2) uv: vec2f,
  @location(3) color: vec4f,
  @location(4) slots: vec4<u32>,
  // Reflection slots straight from the DFF material-effect plugins (B5r): env layer, env coefficient,
  // SA reflection intensity, SA specular level. x = 0 means the material is simply not reflective.
  @location(5) reflect: vec4<u32>,
  // The NIGHT vertex colours (opensa-pack 003 phase 5g). SA bakes the map's lighting into the prelit set
  // and ships a second, darker one for night; a map object drawn by name is the case this serves — a car
  // carries no prelit at all, so its night set is the synthesized ambient and the blend is a no-op tint.
  @location(6) night: vec4f,
};

struct RigidVsOut {
  @builtin(position) clip: vec4f,
  @location(0) uv: vec2f,
  @location(1) normal: vec3f,
  @location(2) world: vec3f,
  @location(3) color: vec4f,
  @location(4) @interpolate(flat) layer: u32,
  @location(5) @interpolate(flat) nightLayer: u32,
  // slots.w LOW nibble: 0 = body, 1 = head lamp, 2 = tail lamp; lamps = [headlights, brakes, intensity].
  @location(6) @interpolate(flat) lampTag: u32,
  // xyz = lamp state. w = the LICENSE-PLATE layer this submesh samples (plan 082/03) — the text-atlas slot
  // on a plateFace, the city background index on a plateBack, 0 on everything else. It rides here
  // rather than in a location of its own because the struct already stands at 15 of the 16 inter-stage
  // locations, and this one was per-instance state with a spare component — the same reason local.w
  // carries sky occlusion.
  @location(7) @interpolate(flat) lamps: vec4f,
  // [env coefficient, SA reflection intensity, SA specular level] — all 0..1, all authored per material.
  // There is no env LAYER beside them: the DFF names an env texture, but this pipe reflects the live probe
  // (rigidEnv), so the name only ever acted as a flag. Location 8 is free again.
  @location(9) @interpolate(flat) reflect: vec3f,
  // MODEL-space position (xyz): the flake hash is anchored to the CAR, so the sparkle rides with it. A
  // world-space hash would make the flakes crawl across the paint as the car drives.
  // w = the model's own SKY OCCLUSION (plan 084), which rides here rather than in a location of its own:
  // the struct is at 15 of the 16 inter-stage locations, and a 16th would push the ped/vehicle pair over.
  @location(10) local: vec4f,
  // slots.w HIGH nibble (074/16 round 2): the material CLASS — 0 matte, 1 paint, 2 chrome, 3 glass.
  @location(11) @interpolate(flat) matClass: u32,
  // Light-pool response, computed per VERTEX (074/16 round 5 — the night-fps fix): the original neo car
  // pipe evaluates ALL of its lighting in the vertex shader, and a per-PIXEL pool loop on a close-up car
  // at 2× retina was the difference between 120 and 60 fps at night. Cars are 3–5 k verts — free there.
  @location(12) poolDiffuse: vec3f,
  // Pool specular (neo pass 2's point-light half), already scaled by the material's specular level.
  @location(13) poolSpec: vec3f,
  // Night EMISSIVE (opensa-pack 003 phase 5g), the rigid twin of the cell path's: a vertex much brighter at
  // night than by day IS a lit window / neon / sign, so it emits instead of merely being tinted. The cell
  // path can also read a BAKED mask; a per-model asset has no cell to carry one, so the luma-delta
  // heuristic is the whole rule here. A car cannot trip it — no prelit means night == day means delta 0.
  @location(14) glow: vec3f,
};

@group(1) @binding(0) var<storage, read> rigidMatrices: array<mat4x4f>;
@group(1) @binding(1) var rigidTexture: texture_2d_array<f32>;
@group(1) @binding(2) var rigidSampler: sampler;
// Carcols paint (074/08 B5), 4 colours per matrix ROW — indexed by instance_index exactly like the
// matrices, so one uploaded model paints a whole street of differently-coloured cars. slots.z picks:
// 0 = the material's own colour, 1..4 = primary/secondary/tertiary/quaternary.
@group(1) @binding(3) var<storage, read> rigidPaint: array<vec4f>;
// Per-instance lamp state (074/08 B5 step 5): x = headlights on, y = braking. Was a GLOBAL day/night gate,
// which lit every parked car in the city at once; only the DRIVEN car should light up.
@group(1) @binding(4) var<storage, read> rigidLamp: array<vec4f>;
// The scene environment probe (074/16 step 2): a mipped cubemap of the ACTUAL world around the player car,
// refreshed one face per frame. frame.params4.w = probe mix (0 until all six faces exist, then 1) — the
// analytic sky reflection stays the fallback for the lab and the first frames after a teleport.
@group(1) @binding(5) var probeTexture: texture_cube<f32>;
@group(1) @binding(6) var probeSampler: sampler;
// Per-instance license plate (plan 082/03), indexed by instance_index exactly like the matrices: x = the
// layer this car's generated text raster sits at in plateTexture, y = which of the three city
// backgrounds it wears. A car that was never given a plate keeps [0, 0] and its plate submeshes sample
// slot 0 of each array — the stock placeholder look, which is also what an unassigned car shows today.
@group(1) @binding(7) var<storage, read> rigidPlate: array<vec4f>;
// The generated plate TEXT rasters (64×16 each), one layer per distinct plate in the world.
@group(1) @binding(8) var plateTexture: texture_2d_array<f32>;
// The three city backgrounds (plateback1..3 = SF / LV / LS), at whatever size the game's TXD ships.
@group(1) @binding(9) var plateBackTexture: texture_2d_array<f32>;
// The UV transform for THIS draw (plan 099): uv·zw + xy, the world lane's exact term. A dynamic offset
// selects the submesh's slot out of the model's own animation list; slot 0 is (0,0,1,1), so a car — and
// every static submesh of an animated model — runs the identity and comes out bit-identical.
@group(1) @binding(10) var<uniform> rigidUvAnim: vec4f;

// MaterialClass — the high nibble of slots.w. Kept in sync with renderware/vehicle/types.ts.
const MAT_PLATE_BACK: u32 = 4u;
const MAT_PLATE_FACE: u32 = 5u;

// skyVisibility / AMBIENT_GROUND / DYNAMIC_INDIRECT are shared dynamic-model lighting helpers — they live in
// <frame> now (next to localLightStatic) so the ped path reuses the exact same indirect term (plan 087 ped).

@vertex
fn vsRigid(in: RigidVsIn) -> RigidVsOut {
  let model = rigidMatrices[in.instance];
  let world = model * vec4f(in.position, 1.0);
  var out: RigidVsOut;
  out.clip = frame.viewProj * world;
  out.uv = in.uv * rigidUvAnim.zw + rigidUvAnim.xy;
  out.normal = normalize((model * vec4f(in.normal, 0.0)).xyz);
  out.world = world.xyz;
  // Day → night on the prelit set, BEFORE the paint override: a car's night set is its day set (no prelit,
  // nothing to darken — its light comes from the world), and mixing after paint would wash the panel out
  // toward the unpainted material colour at midnight.
  var color = vec4f(mix(in.color.rgb, in.night.rgb, frame.params.x), in.color.a);
  if (in.slots.z > 0u) {
    color = vec4f(rigidPaint[in.instance * 4u + (in.slots.z - 1u)].rgb, in.color.a);
  }
  out.color = color;
  // Max-CHANNEL delta, same rule as the world paths: saturated neon reads darker than day in luma.
  let nightDeltaRgb = in.night.rgb - in.color.rgb;
  let nightDelta = max(max(nightDeltaRgb.r, nightDeltaRgb.g), nightDeltaRgb.b);
  out.glow = in.night.rgb * (smoothstep(0.05, 0.32, nightDelta) * frame.params.w * frame.params.x);
  out.layer = in.slots.x;
  out.nightLayer = in.slots.y;
  out.lampTag = in.slots.w & 0xFu;
  out.matClass = in.slots.w >> 4u;
  // The plate row is read HERE, where the instance index still exists, and only the one layer this submesh
  // needs is forwarded: its material class already says which of the two arrays that layer belongs to.
  let matClass = in.slots.w >> 4u;
  let plate = rigidPlate[in.instance];
  var plateLayer = 0.0;
  if (matClass == MAT_PLATE_FACE) {
    plateLayer = plate.x;
  } else if (matClass == MAT_PLATE_BACK) {
    plateLayer = plate.y;
  }
  // A SMASHED lamp does not light (SA CDamageManager::SetLightStatus — plan cleo/scripts 002). The status is
  // per LAMP, but a DFF authors ONE lamp material per end, so the mesh can only go dark per PAIR: both bits
  // of an end have to be set before the lit twin and the glow are withheld. The per-lamp half of the effect —
  // beam, pool light, corona — is geometric and dies one lamp at a time in vehicle-lamp.system.ts.
  let lampRow = rigidLamp[in.instance];
  let smashed = u32(lampRow.w);
  let lampOut = (out.lampTag == 1u && (smashed & 0x3u) == 0x3u) ||
                (out.lampTag == 2u && (smashed & 0xCu) == 0xCu);
  out.lamps = vec4f(select(lampRow.xyz, vec3f(0.0, 0.0, lampRow.z), lampOut), plateLayer);
  out.reflect = vec3f(in.reflect.yzw) / 255.0;
  // The night set's ALPHA is the self-occlusion the builder wrote (vehicle/sky-occlusion.ts). A fixture
  // from before it simply carries the material alpha there, which is 1 on everything opaque - no change.
  out.local = vec4f(in.position, in.night.a);
  // Light pool per VERTEX (round 5): diffuse from the STATIC half (a car is never lit by its own
  // headlights) + neo pass 2's point-light specular over the WHOLE pool (it SHOULD catch its own
  // headlights' bounce off a wall), scaled by the material's specular level here so the fragment adds it raw.
  out.poolDiffuse = localLightStatic(world.xyz, out.normal);
  var poolSpec = vec3f(0.0);
  let toEyeV = normalize(frame.camera.xyz - world.xyz);
  let poolCount = min(u32(frame.params3.x), 64u);
  for (var index = 0u; index < poolCount; index += 1u) {
    let light = localLights[index];
    let toLight = light.position.xyz - world.xyz;
    let dist = length(toLight);
    if (dist < light.position.w) {
      let halfway = normalize(toLight / max(dist, 0.001) + toEyeV);
      let falloff = 1.0 - dist / light.position.w;
      poolSpec += light.color.rgb * (pow(max(dot(out.normal, halfway), 0.0), SPEC_LAMP_POWER) * falloff * falloff);
    }
  }
  out.poolSpec = poolSpec * (out.reflect.z * frame.params4.z);
  return out;
}

// Lamp materials carry a lamps-on TWIN layer (SA's vehiclelights → vehiclelightson swap): pick it when THIS
// car's headlights are on — a per-vehicle state, not the global day/night blend.
fn rigidTexel(in: RigidVsOut) -> vec4f {
  // The plate branches below pick a DIFFERENT texture array, and a branch on a per-fragment value makes the
  // rest of this function non-uniform control flow — where implicit-derivative sampling is illegal (WGSL
  // uniformity rules). The derivatives are taken HERE, while the flow is still uniform, and every path
  // samples with them explicitly: same mip selection as before, no divergence hazard.
  let uvDdx = dpdx(in.uv);
  let uvDdy = dpdy(in.uv);
  // A license plate samples an ENGINE-owned array at a PER-INSTANCE layer instead of the model's own — the
  // whole point of the feature: one uploaded model, a different plate on every car wearing it.
  if (in.matClass == MAT_PLATE_FACE) {
    return textureSampleGrad(plateTexture, rigidSampler, in.uv, u32(in.lamps.w), uvDdx, uvDdy);
  }
  if (in.matClass == MAT_PLATE_BACK) {
    return textureSampleGrad(plateBackTexture, rigidSampler, in.uv, u32(in.lamps.w), uvDdx, uvDdy);
  }
  let lampsOn = in.lamps.x > 0.5 && in.nightLayer != 0u;
  let layer = select(in.layer, in.nightLayer, lampsOn);
  return textureSampleGrad(rigidTexture, rigidSampler, in.uv, layer, uvDdx, uvDdy);
}

// A lit lamp SELF-ILLUMINATES: shading it like painted metal leaves it a dull grey patch at night. Tails run
// dim and go bright on the brakes — the one cue that reads as a car stopping ahead of you.
fn rigidLampGlow(in: RigidVsOut) -> f32 {
  if (in.lampTag == 0u || in.lamps.x <= 0.5) {
    return 0.0;
  }
  if (in.lampTag == 2u) {
    return select(LAMP_TAIL_RUN, LAMP_TAIL_BRAKE, in.lamps.y > 0.5) * in.lamps.z;
  }
  return LAMP_HEAD_GLOW * in.lamps.z;
}

const LAMP_HEAD_GLOW = 2.4;
const LAMP_TAIL_RUN = 1.0;
const LAMP_TAIL_BRAKE = 4.0;

// Vehicle reflections (B5r). SA's env maps are BAKED DAYTIME IMAGES — a painted horizon (xvehicleenv128) for
// paint, a sunset photograph (vehicleenvmap128) for glass. Sampling them raw means a car reflects a sunset at
// midnight. So the DFF gives us the SHAPE and the SETTINGS (which texture, coefficient, intensity, specular
// level) and the LIVE SKY gives the colour: the same Preetham LUT the sky pass and the fog already share, so
// the reflection tracks the hour, the sun and the weather for free.
/**
 * AUTOMOTIVE PAINT (B5r round 2). The first two attempts read as matte, and the reasons are worth keeping:
 *
 *  1. OUR SKY IS LDR. A physically-honest Fresnel (F0 ~ 0.05) times a sky that peaks near 0.3 in linear is
 *     ~0.015 — invisible. Real paint mirrors because the real sky is TENS of times brighter than the paint's
 *     own diffuse. So the reflected environment gets a real HDR gain here; blown-out sky on a wing is not a
 *     bug, it is what a car looks like.
 *  2. NOTHING SWEPT ACROSS THE PANEL. A reflection with no dark ground and no horizon LINE has no contrast to
 *     move — it reads as a tint. The environment now has a hard horizon and a dark road under it.
 *  3. SA PANELS ARE FLAT. On a flat quad the mirror direction is CONSTANT, so a perfect mirror still paints a
 *     constant colour. AAA cars are dense and curved and carry normal maps. Our stand-in is METALLIC FLAKE:
 *     a per-pixel micro-normal, anchored in MODEL space so it rides with the car instead of crawling. It is
 *     what makes a flat SA bonnet sparkle under a street lamp — and it is what real car paint actually is.
 */
const REFLECT_HDR = 4.5; // the sky's missing dynamic range, restored where it matters
const REFLECT_GROUND = 0.10; // the road under the car: dark, so the horizon reads as a hard line
const PAINT_ROUGHNESS = 0.35; // analytic-fallback blur only (mix of the sharp and normal-direction taps)
// THE REFLECTION MODEL IS SKYGFX'S NEO CAR PIPE (074/16 round 4, user-directed — aap's neoVehiclePass1VS):
//   amount = lerp(b⁵, 1, NEO_FRESNEL) × shininess,  b = 1 − saturate(N·V)
//   colour = LERP(lit base, environment, amount)   ← replace, never add: reflections cannot glow
// plus a separate broad specular pass (neo pass 2: power 18 default, point lights at power × 2). The env
// SOURCE is where we go beyond skygfx: their static neo.txd sphere map becomes our live scene probe.
// NEO_FRESNEL 0.4 = the shipped carTweakingTable value (flat across weather/hour in the distribution).
const NEO_FRESNEL = 0.4;
// Prefiltered mips per material class: paint ≈ prod's enhanced preset (roughness 0.15 × 8 mips ≈ 1.2);
// glass and chrome reflect nearly sharp.
const PROBE_PAINT_LOD = 1.2;
const PROBE_GLASS_LOD = 0.5;
const PROBE_CHROME_LOD = 0.4;
// Glass runs the neo curve DAMPED: at the paint's strength a windscreen read as a mirror sheet and hid
// the interior (field round 5) — half strength keeps the street in the glass and the wheel visible through.
const GLASS_REFLECT = 0.5;
// Chrome floors the authored coefficient: the surveyed mods ship ~0.5 everywhere, but bare-metal trim
// should sit near-mirror (neo expresses this through per-material shininess; our class supplies the floor).
const CHROME_COEFFICIENT_FLOOR = 0.85;
const FLAKE_SCALE = 220.0;
// Field rounds 1–3: 0.22 read as dense white noise, 0.10 still frosted the bonnet at close range — the
// flakes must SUGGEST sparkle, not coat the paint. Glass gets none at all.
const FLAKE_AMOUNT = 0.05;
// neo pass 2: broad highlights (power 18 default; the weather table runs 10–70), point lights ×2.
const SPEC_POWER = 18.0;
const SPEC_LAMP_POWER = 36.0;
const SPEC_GAIN = 1.0;

/** Cheap 3D hash -> a unit-ish vector, for the flake micro-normals. */
fn flakeHash(p: vec3f) -> vec3f {
  let h = fract(sin(vec3f(dot(p, vec3f(127.1, 311.7, 74.7)), dot(p, vec3f(269.5, 183.3, 246.1)), dot(p, vec3f(113.5, 271.9, 124.6)))) * 43758.5453);
  return h * 2.0 - vec3f(1.0);
}

/**
 * Metallic flake: perturb the normal per pixel with a stable, model-space hash. Anchored to the CAR, not the
 * world — a world-space hash would make the flakes crawl across the paint as the car drives.
 */
fn flakeNormal(normal: vec3f, local: vec3f) -> vec3f {
  let cell = floor(local * FLAKE_SCALE);
  return normalize(normal + flakeHash(cell) * FLAKE_AMOUNT);
}

/**
 * The world a car reflects: the LIVE sky with its sun/moon discs AND the cloud dome above, the dark road
 * below, split by a hard horizon. The discs are the point — a gradient alone gives a dull sheen; it is the
 * bright blob and the horizon line sliding across a wing as you turn that read as polished lacquer. HDR, so
 * it also feeds the bloom/godray pass for free.
 */
fn reflectedWorld(dir: vec3f) -> vec3f {
  let sky = skyBaseFor(dir) + skyCelestialFor(dir);
  let cloud = cloudLayerFor(dir);
  let above = mix(sky, cloud.rgb, cloud.a * frame.params3.w) * REFLECT_HDR;
  // The road: the ambient sky bounced off asphalt. Dark on purpose — the CONTRAST with the sky is what makes
  // a reflection look like a reflection instead of a tint.
  let ground = skyBaseFor(vec3f(dir.x, 0.15, dir.z)) * REFLECT_GROUND;
  return mix(ground, above, smoothstep(-0.03, 0.03, dir.y));
}

/**
 * The ENVIRONMENT a car reflects (content only — the neo amount decides how much of it shows): the live
 * scene probe when it has faces, the analytic sky as the fallback (the lab without a pak, the first frames
 * after a teleport). NB every tap runs UNCONDITIONALLY: textureSample needs UNIFORM control flow and the
 * class/coefficient are per-vertex varyings — gates multiply, never branch (branching black-canvased both
 * rigid pipelines).
 */
fn rigidEnv(in: RigidVsOut, normal: vec3f, shadingNormal: vec3f, probeLod: f32) -> vec3f {
  let toEye = normalize(frame.camera.xyz - in.world);
  let mirror = reflect(-toEye, shadingNormal);
  let sharp = reflectedWorld(mirror);
  let blurred = reflectedWorld(normalize(mix(mirror, normal, 0.65)));
  let analytic = mix(sharp, blurred, PAINT_ROUGHNESS);
  let probed = textureSampleLevel(probeTexture, probeSampler, mirror, probeLod).rgb;
  return mix(analytic, probed, frame.params4.w);
}

/** neo pass 1's reflection amount: lerp(b⁵, 1, fresnel) × shininess — the LERP weight toward the env. */
fn neoReflAmount(nDotV: f32, coefficient: f32) -> f32 {
  let b = 1.0 - saturate(nDotV);
  let b2 = b * b;
  return clamp(mix(b2 * b2 * b, 1.0, NEO_FRESNEL) * coefficient * frame.params4.z, 0.0, 1.0);
}

/**
 * neo pass 2, the per-PIXEL half: broad Blinn highlights from the sun and moon only — they ride the FLAKED
 * normal, which is what sparkles. The light-pool half lives in the VERTEX shader (round 5): a per-pixel
 * pool loop on a close-up car halved the night frame rate, and the original neo evaluates its whole pass 2
 * per vertex anyway. Callers add in.poolSpec on top.
 */
fn rigidSpecular(in: RigidVsOut, normal: vec3f, level: f32) -> vec3f {
  if (level <= 0.0) {
    return vec3f(0.0);
  }
  let toEye = normalize(frame.camera.xyz - in.world);
  let sun = pow(max(dot(normal, normalize(frame.sunDir.xyz + toEye)), 0.0), SPEC_POWER);
  let moon = pow(max(dot(normal, normalize(frame.moonDir.xyz + toEye)), 0.0), SPEC_POWER);
  return (frame.sunColor.rgb * sun + frame.moonColor.rgb * moon) * (SPEC_GAIN * level);
}



fn rigidShade(in: RigidVsOut, texel: vec4f) -> vec3f {
  let normal = normalize(in.normal);
  if (debugShowNormals()) {
    return debugNormalColor(normal);
  }
  let sunNdl = max(dot(normal, frame.sunDir.xyz), 0.0);
  let moonNdl = clamp((dot(normal, frame.moonDir.xyz) + 0.6) / 1.6, 0.0, 1.0);
  let base = texel.rgb * debugPrelit(in.color.rgb);
  // A LIT lamp is a SOURCE, not a surface: it emits, and its diffuse response is irrelevant. Shading it like
  // painted metal is what "cropped" the tail lights — the lens wraps around the car's corner, so its normal
  // swings ~90° across the lens, and a nearby street lamp painted that swing straight onto the glass as a
  // hard gradient broken at the triangle edge. Prod never showed it because its lamp glass is emissive-
  // dominant (emissiveMap × 1..4), which drowns the diffuse term. Ambient keeps the unlit texel detail alive.
  let ambient = frame.params.y * DYNAMIC_INDIRECT * skyVisibility(normal) * in.local.w;
  let glow = rigidLampGlow(in);
  if (glow > 0.0) {
    return base * (ambient + glow);
  }
  // STATIC lamps only, computed per VERTEX (round 5). A car must not be lit by its OWN headlights (the
  // tail lamp sits a metre behind its own lens); prod has the same rule by construction.
  let lit = vec3f(ambient) + frame.sunColor.rgb * (sunNdl * frame.params.z) + frame.moonColor.rgb * moonNdl +
    in.poolDiffuse;
  return base * (debugLit(lit) + in.glow);
}

fn rigidFog(world: vec3f) -> f32 {
  let toCamera = world - frame.camera.xyz;
  let dist = length(toCamera);
  let fogD = max(dist - frame.fog.y, 0.0);
  let fogK = 2.0 / max(frame.fog.x - frame.fog.y, 1.0);
  var fogFactor = 1.0 - exp(-(fogK * fogD) * (fogK * fogD));
  fogFactor = fogFactor * mix(frame.fog.w, 1.0, exp(-max(world.y, 0.0) * frame.fog.z));
  return max(fogFactor, smoothstep(frame.fog.x * 0.85, frame.fog.x, dist));
}

@fragment
fn fsRigid(in: RigidVsOut) -> @location(0) vec4f {
  let fog = rigidFog(in.world);
  let viewDir = normalize(in.world - frame.camera.xyz);
  let normal = normalize(in.normal);
  // The neo car pipe, branch-free per class: PAINT = flaked normal + the paint mip; CHROME = plain normal,
  // near-sharp mip, coefficient floored toward mirror; MATTE (tyres, trim, the vlo LOD, lamps) = amount 0.
  // The LERP is the model's heart — the reflection REPLACES the paint by its amount instead of adding to
  // it, so it can never glow; specular rides on top; fog dissolves the finished surface.
  let isPaint = f32(in.matClass == 1u);
  let isChrome = f32(in.matClass == 2u);
  let shadingNormal = normalize(mix(normal, flakeNormal(normal, in.local.xyz), isPaint));
  let toEye = normalize(frame.camera.xyz - in.world);
  let coefficient = mix(in.reflect.x, max(in.reflect.x, CHROME_COEFFICIENT_FLOOR), isChrome);
  let amount = neoReflAmount(dot(shadingNormal, toEye), coefficient) * (isPaint + isChrome);
  let env = rigidEnv(in, normal, shadingNormal, mix(PROBE_PAINT_LOD, PROBE_CHROME_LOD, isChrome));
  let specular = rigidSpecular(in, shadingNormal, in.reflect.z * frame.params4.z) + in.poolSpec;
  let shaded = mix(rigidShade(in, rigidTexel(in)), env, amount) + specular;
  let color = mix(shaded, fogColorFor(viewDir, fog), fog);
  return vec4f(color, 1.0);
}

@fragment
fn fsRigidBlend(in: RigidVsOut, @builtin(front_facing) frontFacing: bool) -> @location(0) vec4f {
  // Premultiplied for the (one, 1−src-α) pipeline; fog scales the pair (068 semantics for blends).
  // The alpha is BOTH sources: glass carries it in the material colour, body decals (scratch/crack overlays)
  // carry it in the TEXEL. Taking only the material's would render a decal opaque — its transparent black
  // texels then paint a black panel over the door.
  let texel = rigidTexel(in);
  let fog = rigidFog(in.world);
  let viewDir = normalize(in.world - frame.camera.xyz);
  let normal = normalize(in.normal);
  // The reflection belongs to the OUTER surface only: glass is drawn double-sided, and adding the mirrored
  // world onto BACK faces painted warped ghosts over the view from inside the car ("dioptric glass" —
  // bench round 3). A branch-free gate; back faces keep plain tinted transparency.
  let outside = f32(frontFacing);
  let toEye = normalize(frame.camera.xyz - in.world);
  // GLASS on the neo curve: plain normal (no flakes), a near-sharp probe mip. The neo amount drives BOTH
  // the mirrored colour and the opacity swell — glass turns mirror at grazing angles, and a windscreen you
  // can see straight through from every angle looks like a hole in the car.
  let amount = neoReflAmount(dot(normal, toEye), in.reflect.x) * GLASS_REFLECT * outside;
  let alpha = clamp(texel.a * in.color.a + amount, 0.0, 1.0);
  let env = rigidEnv(in, normal, normal, PROBE_GLASS_LOD);
  let specular = (rigidSpecular(in, normal, in.reflect.z * frame.params4.z) + in.poolSpec) * outside;
  // Premultiplied compositing: the reflected env replaces the tinted glass by its amount, then fog takes
  // the finished pair (068 semantics).
  let glass = mix(rigidShade(in, texel) * alpha, env, amount) + specular;
  let color = mix(glass, fogColorFor(viewDir, fog) * alpha, fog);
  return vec4f(color, alpha);
}
`,skid:`
#include <frame>

// Skid-mark decals (089/03): ground ribbon quads, premultiplied over the opaque world, fading on the
// WALL clock — frame.params2.z is engine uptime in REAL seconds, so the brief's 5-second rule ignores the
// day cycle by construction. SA's particleskid is WHITE with the tread in the alpha channel; the dark
// rubber colour is applied here (the original tints it with a dark vertex colour the same way).
@group(1) @binding(0) var skidTexture: texture_2d<f32>;
@group(1) @binding(1) var skidSampler: sampler;

struct SkidIn {
  @location(0) position: vec3f,
  @location(1) uv: vec2f,
  // x = the laid alpha (slide severity x the grow-in ramp), y = birth seconds on the frame clock.
  @location(2) params: vec2f,
};

struct SkidOut {
  @builtin(position) clip: vec4f,
  @location(0) uv: vec2f,
  @location(1) alpha: f32,
};

// MUST match SKID_LIFE_SECONDS in render/skid-marks.ts (the ring prunes on the same clock this fades on).
const SKID_LIFE = 12.0;
const RUBBER = vec3f(0.04, 0.04, 0.05);
// particleskid's alpha averages ~0.4 — authored for SA's own compositing. Unboosted, a full-severity mark
// darkens this engine's road by ~0.3 and vanishes into the asphalt; the boost keeps the tread PATTERN
// (relative alpha) while making the mark read. An eye-fit — docs/hacks/skid-mark-look-fit.md.
const TREAD_BOOST = 1.8;

@vertex
fn vsSkid(in: SkidIn) -> SkidOut {
  var out: SkidOut;
  out.clip = frame.viewProj * vec4f(in.position, 1.0);
  out.uv = in.uv;
  let fade = clamp(1.0 - (frame.params2.z - in.params.y) / SKID_LIFE, 0.0, 1.0);
  out.alpha = in.params.x * fade;
  return out;
}

@fragment
fn fsSkid(in: SkidOut) -> @location(0) vec4f {
  let texel = textureSample(skidTexture, skidSampler, in.uv);
  let a = min(1.0, texel.a * TREAD_BOOST) * in.alpha;
  return vec4f(texel.rgb * RUBBER * a, a);
}
`,sky:`
#include <frame>

// Fullscreen sky (074/06 row 4 v1): a big triangle at far depth; depth-test LESS-EQUAL against 1.0 keeps it
// behind everything drawn. The gradient + sun glow live in <frame> (shared with the world fog).
struct SkyOut {
  @builtin(position) clip: vec4f,
  @location(0) ndc: vec2f,
};

@vertex
fn vsSky(@builtin(vertex_index) index: u32) -> SkyOut {
  var out: SkyOut;
  let x = f32(i32(index & 1u) * 4 - 1);
  let y = f32(i32(index >> 1u) * 4 - 1);
  // Reversed-Z: the far plane is depth 0.
  out.clip = vec4f(x, y, 0.0, 1.0);
  out.ndc = vec2f(x, y);
  return out;
}

// Procedural night starfield (074/06 row 16, the prod sky.plugin port): gnomonic-projected cell hash —
// ~one star per 10 % of cells, random brightness, gentle twinkle, horizon taper. SKY PASS ONLY: fog and
// world fragments share skyFogFor and must NOT twinkle. (hash21/skyVnoise/skyFbm live in the frame
// include — the cumulus deck and the reflection fallback need them outside the sky module.)
fn starField(dir: vec3f) -> f32 {
  if (dir.y <= 0.02) {
    return 0.0;
  }
  let uv = dir.xz / dir.y * 6.0;
  let cell = floor(uv);
  let f = fract(uv);
  let present = step(0.90, hash21(cell));
  let star = vec2f(hash21(cell + 1.7), hash21(cell + 4.3));
  let d = length(f - star);
  let point = smoothstep(0.06, 0.0, d) * present;
  let bright = 0.35 + 0.65 * hash21(cell + 8.1);
  let twinkle = 0.6 + 0.4 * sin(frame.params2.z * 2.5 + hash21(cell) * 90.0);
  let taper = smoothstep(0.02, 0.35, dir.y);
  return point * bright * twinkle * taper;
}

@fragment
fn fsSky(in: SkyOut) -> @location(0) vec4f {
  let far = frame.invViewProj * vec4f(in.ndc, 1.0, 1.0);
  let dir = normalize(far.xyz / far.w - frame.camera.xyz);
  var col = skyBaseFor(dir);
  let sunDot = max(dot(dir, frame.sunDir.xyz), 0.0);
  // CIRRUS wisps (074/09 sky round 3): thin high streaks; rides the cloud-layer alpha knob so
  // graphics.clouds.opacity still governs.
  let cirrus = cirrusFor(dir, sunDot);
  col = mix(col, cirrus.rgb, cirrus.a * frame.params3.w);
  // CUMULUS deck (sky v2): the procedural weather clouds (the painted panorama is REMOVED). Dense masses
  // occlude the sun/moon discs and stars exactly like the old deck alpha did.
  let cumulus = cumulusFor(dir, sunDot);
  col = mix(col, cumulus.rgb, cumulus.a * frame.params3.w);
  let occl = cumulus.a * clamp(frame.params3.w * 1.6, 0.0, 1.0);
  // Sun/moon discs and stars sit BEHIND the cloud layer: squared falloff kills the disc overshoot under
  // thick cover while thin wisps still let a dimmed disc through (prod's uCloudClear analogue).
  let clear = (1.0 - occl) * (1.0 - occl);
  col += skyCelestialFor(dir) * clear;
  // Stars fade GLOBALLY with the weather's cloud cover (prod uCloudClear; sunCorona.w) — per-pixel
  // occlusion alone let stars leak through gaps in the deck.
  let cloudClear = 1.0 - clamp(frame.sunCorona.w * 1.15, 0.0, 1.0);
  col += vec3f(starField(dir)) * frame.params.x * clear * cloudClear;
  return vec4f(col, 1.0);
}
`,water:`
#include <frame>

// Water v1 (074/06 row 12; plan 069's look, RUNTIME-ONLY — no converter bake): flat water.dat quads +
// the ocean frame, Gerstner SLOPES only (prod's approach — the quads are far too coarse to displace),
// fresnel between the timecyc deep tint and the shared sky dome, sun glint off the wave normal, and the
// 068 fog — the sea dissolves into the horizon exactly like land does.
// group(1): the authored textures (particle.txd, runtime-parsed by the host): waterclear256 = the
// close-up ripple (real detail where the analytic trains are too smooth), waterwake = the shore foam.
@group(1) @binding(0) var waterRipple: texture_2d<f32>;
@group(1) @binding(1) var waterSampler: sampler;
@group(1) @binding(2) var waterFoam: texture_2d<f32>;

struct WaterOut {
  @builtin(position) clip: vec4f,
  @location(0) world: vec3f,
  @location(1) shore: f32,
  @location(2) swell: f32,
  // Water class (plan 075): 0 = sea (full dynamics), 1 = inland (calm — no swell/surf/swash/foam so a pool
  // doesn't spill its waves past its edges).
  @location(3) @interpolate(flat) inland: f32,
};

// The two LONGEST trains DISPLACE the tessellated grid (074/06 row 12 v2 — the baked ~16 u mesh finally
// moves); the short trains stay slope-only in the fragment normal. Damped to a calm sheet at the beach
// by the baked shore field.
fn swellHeight(p: vec2f, t: f32) -> f32 {
  let wind = vec2f(0.825, 0.565);
  let side = vec2f(-wind.y, wind.x);
  let d1 = normalize(wind * 0.8 + side * 0.6);
  return sin(dot(p, wind) * 0.045 + t * 0.9) * 1.0 + sin(dot(p, d1) * 0.083 + t * 1.2) * 0.62;
}

// The BREAKING wave (074/06 row 12 v3): a front running toward the beach along the DEPTH field
// (phase = depth·k − t·speed → crests follow depth contours, parallel to the visual waterline — the
// reference look), peaked in the surf band (0.3–4 m) and dying right at the waterline.
fn surfPhase(depth: f32, t: f32) -> f32 {
  // +t: the constant-phase contour moves toward depth 0 — the front runs AT the beach (field round 5:
  // −t read as waves leaving the shore).
  return sin(depth * 1.4 + t * 1.6);
}

@vertex
fn vsWater(@location(0) position: vec3f, @location(1) depth: f32, @location(2) waterClass: f32) -> WaterOut {
  var out: WaterOut;
  let inland = waterClass > 0.5;
  let damp = smoothstep(1.0, 9.0, depth);
  let swell = swellHeight(vec2f(position.x, position.z), frame.params2.z) * damp;
  // The lower gate keeps the WAVE trains out of the swash zone (field round 7: short-wavelength
  // displacement tore a jagged waterline) — but the SURGE below is smooth and constant there, so it
  // moves the waterline cleanly.
  let surf = surfPhase(depth, frame.params2.z) *
    (1.0 - smoothstep(1.8, 6.0, depth)) * smoothstep(0.5, 1.5, depth);
  // Swash SURGE (round 12 — "move the ocean itself back and forth"): a flat plane's edge only moves via
  // HEIGHT, so the whole shore zone breathes ±0.25 m on the foam clock. The waterline physically runs
  // metres up the sand exactly when the foam front lands (same runup), then pulls back out. The water
  // quads extend under the beach with baked depth 0 there — the revealed strip arrives pre-foamed and
  // near-transparent: the swash sheet on the sand for free.
  let surgeRunup = 0.5 + 0.5 * sin(frame.params2.z * 0.85);
  let surge = (surgeRunup - 0.5) * 0.5 * (1.0 - smoothstep(0.5, 3.0, depth));
  var displaced = position;
  // INLAND water gets NO vertical displacement — a still pool must not heave its surface over the rim.
  displaced.y += select(swell * 0.32 + surf * 0.45 + surge, 0.0, inland);
  out.clip = frame.viewProj * vec4f(displaced, 1.0);
  out.world = displaced;
  out.shore = depth;
  out.swell = select(swell, 0.0, inland);
  out.inland = select(0.0, 1.0, inland);
  return out;
}

// Four analytic wave trains (the prod waterNormal port, slopes only) + the same distance-LOD fade:
// a high-frequency train aliases into moiré bands once a pixel spans many wavelengths.
// Field round 1 fixes: a large-scale DOMAIN WARP breaks the fixed-frequency interference grid (the water
// read as tiled rows), gentler slope amplitude kills the bright "pillow" bands, and the LOD fade range is
// wider so train transitions smear instead of banding by camera distance.
fn waveGradient(p0: vec2f, t: f32, viewDist: f32) -> vec2f {
  let p = p0 + vec2f(sin(p0.y * 0.013 + t * 0.26), sin(p0.x * 0.011 - t * 0.21)) * 9.0;
  let wind = vec2f(0.825, 0.565); // fixed wind heading in v1 (prod exposes uWindAngle — config later)
  let side = vec2f(-wind.y, wind.x);
  var dirs = array<vec2f, 4>(
    wind,
    normalize(wind * 0.8 + side * 0.6),
    normalize(wind * 0.9 - side * 0.5),
    normalize(wind * 0.4 + side * 1.0),
  );
  var freqs = array<f32, 4>(0.045, 0.083, 0.150, 0.260);
  var speeds = array<f32, 4>(0.9, 1.2, 1.6, 2.1);
  var weights = array<f32, 4>(1.0, 0.62, 0.38, 0.22);
  var grad = vec2f(0.0);
  for (var i = 0u; i < 4u; i += 1u) {
    let wavelength = 6.2831853 / freqs[i];
    let fade = smoothstep(wavelength * 90.0, wavelength * 10.0, viewDist);
    let phase = dot(p, dirs[i]) * freqs[i] + t * speeds[i];
    // The two LONG (displaced) trains barely tilt the LIGHTING normal (0.3×): their slopes reflected the
    // bright horizon sky as wide colour bands mid-distance (field round 3); their job is the silhouette.
    let slopeWeight = select(3.5, 1.0, i < 2u);
    grad += dirs[i] * cos(phase) * freqs[i] * weights[i] * slopeWeight * fade;
  }
  // Slow cross-swell keeps the far water alive when the trains have LOD-faded out.
  grad += vec2f(0.011) * cos((p.x + p.y) * 0.022 + t * 0.9);
  return grad;
}

// INLAND liveliness (plan 075): a still pool must not be a dead mirror. Two gentle criss-crossing ripple
// trains + a lazy large-scale drift perturb the LIGHTING NORMAL only (no height displacement → no spillover),
// so the reflection and the sun glint shimmer and slide across the surface. Amplitudes are small on purpose.
fn calmRipple(p: vec2f, t: f32) -> vec2f {
  let a = normalize(vec2f(0.7, 0.3));
  let b = normalize(vec2f(-0.35, 0.6));
  var g = vec2f(0.0);
  g += a * cos(dot(p, a) * 0.55 + t * 1.1) * 0.020;
  g += b * cos(dot(p, b) * 0.90 - t * 0.9) * 0.014;
  // A slow, wide drift of the normal — the lazy "breathing" of a calm sheet.
  g += vec2f(cos(p.x * 0.13 + t * 0.5), sin(p.y * 0.11 - t * 0.4)) * 0.010;
  return g;
}

@fragment
fn fsWater(in: WaterOut) -> @location(0) vec4f {
  let toEye = frame.camera.xyz - in.world;
  let dist = length(toEye);
  let view = toEye / max(dist, 1e-4);
  let inland = in.inland > 0.5;
  // The wave field lives on the horizontal plane: GTA xy == engine xz.
  let p = vec2f(in.world.x, in.world.z);
  let t = frame.params2.z;
  // INLAND (plan 075): swap the OCEAN wave trains for a gentle calm-ripple (normal-only, no displacement) so
  // a pool shimmers and moves its reflection without heaving its surface. SEA keeps the full train gradient.
  var grad = select(waveGradient(p, t, dist), calmRipple(p, t), inland);
  // Close-up detail from the authored waterclear256 ripple (prod's term): two scrolled taps read as a
  // slope — always on, so the surface shimmers even in a dead calm. Sampled UNCONDITIONALLY (implicit-LOD
  // textureSample is illegal in non-uniform control flow) and weighted by the near fade.
  let near = smoothstep(200.0, 20.0, dist);
  let duv = p * 0.09;
  let flow = vec2f(0.825, 0.565) * t * 0.022; // field fix: 0.004 read as frozen
  let e = 0.06;
  let h0 = textureSample(waterRipple, waterSampler, duv + flow).r +
    textureSample(waterRipple, waterSampler, duv * 1.7 - flow * 1.3).r;
  let hx = textureSample(waterRipple, waterSampler, duv + vec2f(e, 0.0) + flow).r +
    textureSample(waterRipple, waterSampler, (duv + vec2f(e, 0.0)) * 1.7 - flow * 1.3).r;
  let hy = textureSample(waterRipple, waterSampler, duv + vec2f(0.0, e) + flow).r +
    textureSample(waterRipple, waterSampler, (duv + vec2f(0.0, e)) * 1.7 - flow * 1.3).r;
  grad += vec2f(hx - h0, hy - h0) * (1.1 * near) * select(1.0, 0.6, inland);
  // Far-field FLATTEN (field round 2 — swell faces mirrored the bright fog horizon as huge white bands):
  // distant water reads as a calm mirror; the swell survives in the silhouette via the displacement.
  var normal = normalize(vec3f(-grad.x, 1.0, -grad.y));
  normal = normalize(mix(normal, vec3f(0.0, 1.0, 0.0), smoothstep(120.0, 500.0, dist)));
  let fresnel = pow(1.0 - clamp(dot(normal, view), 0.0, 1.0), 5.0);
  var refl = reflect(-view, normal);
  refl.y = abs(refl.y); // the sky dome has no below-horizon content
  let sky = skyBaseFor(refl);
  var color = mix(frame.waterColor.rgb, sky, 0.2 + 0.55 * fresnel);
  // Sun glint: TIGHT Blinn toward the sun, whitened (field round 1: raw sunCorona painted pink patches;
  // a real glitter path is near-white with only a warm cast) and modulated by the fine ripple so it
  // sparkles instead of pooling on the smooth train slopes.
  let h = normalize(view + frame.sunDir.xyz);
  let glint = pow(max(dot(normal, h), 0.0), 650.0);
  color += mix(frame.sunCorona.rgb, vec3f(1.0), 0.55) * glint * (0.25 + 0.45 * near);
  var alpha = clamp(frame.waterColor.a + fresnel * 0.25, 0.0, 1.0);
  // Shore water (074/06 row 12 v3, the baked DEPTH field): shallow = brighter and MUCH more
  // transparent (the sand reads through the last metre — the wet-swash look of the reference).
  let shallow = 1.0 - smoothstep(0.0, 4.0, in.shore);
  color = mix(color, color * 1.2 + vec3f(0.01, 0.03, 0.03), shallow * 0.35);
  alpha *= mix(1.0, 0.4, shallow * shallow);
  // waterwake is a WHITE sprite with the shape in ALPHA (field: .r alone painted solid white bands) —
  // shape = a·r. Foam lives in TWO places (the reference look): the WASH at the waterline (depth < 0.8 m,
  // pulsing with the surf runup) and the BREAKING LINE offshore — the crest of the incoming front in the
  // 0.8–3.5 m band, a bright irregular stripe travelling shoreward.
  // Foam, round 8 — TWO synchronized actors on one clock (t·1.6):
  //  · the INCOMING crest carries foam from 3.5 m down to the landing depth (~0.9 m), continuous;
  //  · the SWASH SHEET: its leading edge PHYSICALLY oscillates between 1.4 m and 0.1 m of depth,
  //    delayed to pick up where the crest lands — foam visibly runs up the beach AND pulls back out
  //    (the field ask), dimming on the retreat.
  // Shape mixes waterwake with the waterclear ripple for organic, non-repeating edges.
  let foamUv = p * 0.15 + flow * 6.0;
  let tapA = textureSample(waterFoam, waterSampler, foamUv);
  let tapB = textureSample(waterFoam, waterSampler, foamUv * 0.57 + vec2f(0.37));
  let foamNoise = textureSample(waterRipple, waterSampler, p * 0.045 - flow * 2.0).r;
  let foamShape = clamp(max(tapA.a * tapA.r, tapB.a * tapB.r) * (0.55 + 0.75 * foamNoise), 0.0, 1.0);
  // ONE foam front, round 10 (the field kept seeing TWO events — a crest dying mid-way and a separate
  // shore sheet). A single wave: its FRONT POSITION travels the whole 3 m → 0.08 m and back on one slow
  // clock; the foam mass trails ~1.5–3 m of depth behind the front. Envelopes per the user's spec:
  //  · intensity fades IN as the front leaves deep water (soft birth) and dims on the retreat;
  //  · hardness peaks exactly when the front reaches the edge, melts back to milky as it withdraws.
  // Round 11: BOTH envelopes ride the front POSITION only — no phase-direction terms. The old advancing
  // dimmer killed the foam exactly at the turning point ("reaches the edge and dies"); now brightness
  // stays FULL at the edge and through the retreat, dissolving only once the front is back out deep,
  // and hardness decays purely with distance from the edge (hard at the sand, melting on the way out).
  let cycle = t * 0.85;
  let runup = 0.5 + 0.5 * sin(cycle);
  let front = mix(3.0, 0.08, runup);
  let mass = smoothstep(front - 0.2, front + 0.15, in.shore) *
    (1.0 - smoothstep(front + 1.5, front + 3.2, in.shore));
  let intensity = smoothstep(0.02, 0.3, runup);
  let rim = (1.0 - smoothstep(0.05, 0.3, in.shore)) * 0.35;
  let crest = smoothstep(1.15, 1.55, in.swell) * 0.12;
  let soft = clamp(foamShape * (mass * intensity + rim) * 1.5 + foamShape * crest, 0.0, 1.0);
  let hard = smoothstep(0.35, 0.6, soft);
  let hardness = smoothstep(0.45, 0.97, runup);
  // INLAND water carries NO foam (no surf, no swash) — the whole breaking-wave chain is a SEA effect.
  let foam = mix(soft * 0.85, max(soft, hard), hardness) * select(1.0, 0.0, inland);
  color = mix(color, vec3f(0.95, 0.97, 0.97), foam);
  alpha = max(alpha, foam * 0.95);
  // Unified fog (the 068 shape — identical math to the world shaders).
  let fogD = max(dist - frame.fog.y, 0.0);
  let fogK = 2.0 / max(frame.fog.x - frame.fog.y, 1.0);
  var fogFactor = 1.0 - exp(-(fogK * fogD) * (fogK * fogD));
  fogFactor = fogFactor * mix(frame.fog.w, 1.0, exp(-max(in.world.y, 0.0) * frame.fog.z));
  fogFactor = max(fogFactor, smoothstep(frame.fog.x * 0.85, frame.fog.x, dist));
  color = mix(color, fogColorFor(-view, fogFactor), fogFactor);
  // Fully fogged water must MATCH the sky behind it — fade the surface out with the fog so the horizon
  // line dissolves instead of drawing a hard sea edge (the ocean-horizon regression view).
  alpha = mix(alpha, 1.0, fogFactor);
  return vec4f(color * alpha, alpha);
}
`,world:`
#include <frame>

// origin.w = per-cell channel flag bits: bit 0 = baked sunVis (normal.w meaningful), bit 1 = baked
// emissive mask (high channels byte meaningful). Zero = neither (old paks render unchanged).
// uvAnim (B7·c / plan 074/18) = the UV-scroll transform applied to every vertex: uv·uvAnim.zw + uvAnim.xy.
// IDENTITY (0,0,1,1) for ordinary cells (a uniform-gated no-op); a kind-4 objectTable draw binds a per-object
// cell buffer whose uvAnim the host advances each frame (the LV skull sign's crawling neon).
struct Cell {
  origin: vec4f,
  uvAnim: vec4f,
};
@group(1) @binding(0) var<uniform> cell: Cell;

@group(2) @binding(0) var worldTexture: texture_2d_array<f32>;
@group(2) @binding(1) var worldSampler: sampler;

struct VsIn {
  @location(0) position: vec3f,
  @location(1) uv: vec2f,
  @location(2) dayPrelit: vec4f,
  @location(3) layerChannels: vec2u,
  @location(4) normal: vec4f,
  @location(5) nightPrelit: vec4f,
};

struct VsOut {
  @builtin(position) clip: vec4f,
  @location(0) uv: vec2f,
  @location(1) prelit: vec3f,
  @location(2) @interpolate(flat) layer: u32,
  @location(3) sunNdl: f32,
  @location(4) world: vec3f,
  @location(5) glow: vec3f,
  @location(6) ao: f32,
  @location(7) cone: f32,
  @location(8) moonNdl: f32,
  @location(9) localLight: vec3f,
  // World-space normal — the world is vertex-lit (sunNdl/moonNdl are precomputed), but a MOVING light must
  // be shaded per pixel, and that needs the normal here.
  @location(10) normal: vec3f,
};

@vertex
fn vsWorld(in: VsIn) -> VsOut {
  var out: VsOut;
  var world = in.position + cell.origin.xyz;
  // Wind sway (074/06 row 10, the plan-039 model baked offline): nightPrelit.a = amplitude in METRES
  // (0 for everything rigid — the displacement is a data-driven no-op there). Phase rides world-space
  // position with LOW frequency so one canopy moves nearly as a unit but a row of palms doesn't lockstep.
  let sway = in.nightPrelit.a * frame.params2.w;
  let swayT = frame.params2.z * 1.2 + world.x * 0.05 + world.z * 0.04;
  world.x += sin(swayT) * sway;
  world.z += cos(swayT * 0.7) * sway * 0.6;
  out.clip = frame.viewProj * vec4f(world, 1.0);
  out.world = world;
  // UV-scroll (B7·c): identity for ordinary geometry; a kind-4 draw's per-object cell buffer carries the
  // animated transform. Applied here so it composes with the far-outside-[0,1] GTA UVs the world tiles.
  out.uv = in.uv * cell.uvAnim.zw + cell.uvAnim.xy;
  // Day↔night prelit blend (074/06 row 1): cells without an authored night set carry a converter-synthesized
  // night (day × ambient) — one formula for the whole world, per vertex.
  out.prelit = mix(in.dayPrelit.rgb, in.nightPrelit.rgb, frame.params.x);
  // Night emissives (074/06 rows 8-9, the 071 model): a vertex much brighter at night than by day IS a lit
  // window / neon / sign — it GLOWS instead of being merely tinted. The BAKED mask (07, high channels byte)
  // replaces the runtime heuristic when the cell carries it; dn fades either in. Max-CHANNEL delta, not
  // luma: neon night sets are saturated (the LV strip's red rope light reads DARKER than day in luma).
  let cellFlags = u32(cell.origin.w + 0.5);
  let deltaRgb = in.nightPrelit.rgb - in.dayPrelit.rgb;
  let heuristic = smoothstep(0.05, 0.32, max(max(deltaRgb.r, deltaRgb.g), deltaRgb.b));
  let baked = f32(in.layerChannels.y >> 8u) / 255.0;
  let emissive = mix(heuristic, baked, f32((cellFlags >> 1u) & 1u));
  out.glow = in.nightPrelit.rgb * (emissive * frame.params.w * frame.params.x);
  out.layer = in.layerChannels.x;
  // Sun N·L per vertex (074/06 row 3) — GTA geometry is low-poly; per-vertex matches the shipped look.
  // Baked sun visibility (074/07, 066/03 v1 scalar): normal.w = arc-averaged sun occlusion — the STATIC
  // shadow term (under bridges / canyons the direct sun dies), smooth by construction, no shadow map.
  // Sun-vis SCALAR (074/07 v1, the accepted look): normal.w = arc-averaged sun visibility — soft static
  // occlusion (dark under bridges/canyons), does NOT track the moving sun. The directional v2 is PARKED
  // until the converter can subdivide large receiver polys (see plan 07).
  let sunGate = f32(cellFlags & 1u) * frame.params2.y;
  let sunVis = mix(1.0, clamp(in.normal.w, 0.0, 1.0), sunGate);
  let worldNormal = normalize(in.normal.xyz);
  out.sunNdl = max(dot(worldNormal, frame.sunDir.xyz), 0.0) * sunVis;
  // Moon N·L, WRAPPED (074/06 row 6): the same static occlusion gates moonlight. Prod's moon sits at a
  // FIXED 5° elevation (sin ≈ 0.087) while our disc arcs to the zenith — unnormalized, the wrapped term
  // makes deep night ~1.7× hotter on up-facing ground than prod (field: "night too bright"). The last
  // factor pins the UP-FACING response to prod's geometry; the direction still sweeps with the disc.
  out.moonNdl = clamp((dot(worldNormal, frame.moonDir.xyz) + 0.6) / 1.6, 0.0, 1.0) * sunVis *
    (0.687 / (max(frame.moonDir.y, 0.0) + 0.6));
  // Baked AO/skyVis (074/07): low byte of channels; 0 means UNBAKED (old paks) → fully open, not black.
  let aoByte = in.layerChannels.y & 0xffu;
  let aoVis = select(f32(aoByte) / 255.0, 1.0, aoByte == 0u);
  out.ao = mix(1.0, aoVis, frame.params2.x);
  // Beam cone alpha (074/06 row 11): dayPrelit.a — 1 everywhere except floodlight-cone geometry.
  out.cone = in.dayPrelit.a;
  // Local light pool (074/06 row 7): VERTEX-lit like everything else in SA.
  out.localLight = localLightStatic(world, worldNormal);
  out.normal = worldNormal;
  return out;
}

// Stochastic de-tiling (074/12, the skygfx 3-tap tiling-and-blend): UVs skew into a triangular grid, each
// grid vertex hashes to a random UV offset, 3 taps blend by barycentric weights — macro-repetition dies,
// micro-detail stays. Explicit grads are mandatory twice over: the offsets are DISCONTINUOUS at grid seams
// (implicit gradients pick garbage mips there), and this runs in a non-uniform branch.
fn hash2D2D(s: vec2f) -> vec2f {
  return fract(sin(vec2f(dot(s, vec2f(127.1, 311.7)), dot(s, vec2f(269.5, 183.3))) % 3.14159) * 43758.5453);
}

fn stochasticTexel(uv: vec2f, layer: u32, uvDx: vec2f, uvDy: vec2f) -> vec4f {
  let skew = mat2x2f(vec2f(1.0, -0.57735027), vec2f(0.0, 1.15470054)) * (uv * 3.464);
  let vxID = floor(skew);
  let fracts = fract(skew);
  let bz = 1.0 - fracts.x - fracts.y;
  var v0 = vxID + vec2f(1.0, 1.0);
  var v1 = vxID + vec2f(1.0, 0.0);
  var v2 = vxID + vec2f(0.0, 1.0);
  var w = vec3f(-bz, 1.0 - fracts.y, 1.0 - fracts.x);
  if (bz > 0.0) {
    v0 = vxID;
    v1 = vxID + vec2f(0.0, 1.0);
    v2 = vxID + vec2f(1.0, 0.0);
    w = vec3f(bz, fracts.y, fracts.x);
  }
  return textureSampleGrad(worldTexture, worldSampler, uv + hash2D2D(v0), layer, uvDx, uvDy) * w.x +
    textureSampleGrad(worldTexture, worldSampler, uv + hash2D2D(v1), layer, uvDx, uvDy) * w.y +
    textureSampleGrad(worldTexture, worldSampler, uv + hash2D2D(v2), layer, uvDx, uvDy) * w.z;
}

fn worldShade(in: VsOut, cutout: bool) -> vec4f {
  // Textures ship PREMULTIPLIED (074/02): filtering is correct by construction, transparent texels
  // contribute nothing — the alpha-edge fix. Alpha feeds coverage on the cutout pipeline (A2C).
  // Layer bit 15 = stochastic flag (074/12); grads + the plain tap stay in UNIFORM control flow.
  let layer = in.layer & 0xffu;
  let uvDx = dpdx(in.uv);
  let uvDy = dpdy(in.uv);
  var texel = textureSample(worldTexture, worldSampler, in.uv, layer);
  if ((in.layer & 0x8000u) != 0u && frame.moonDir.w > 0.5) {
    texel = stochasticTexel(in.uv, layer, uvDx, uvDy);
  }
  if (cutout) {
    // Needle-fine foliage minifies to FRACTIONAL sampled alpha across the whole crown (each pixel covers
    // many leaf/gap texels) — raw A2C turns that into a uniform screen-door stipple. Sharpen the SAMPLED
    // alpha toward the vanilla alpha-test look (fwidth keeps real silhouettes antialiased) and
    // un-premultiply the colour so boosted coverage does not render the ×alpha-darkened RGB.
    let sharpened = clamp((texel.a - 0.5) / max(fwidth(texel.a), 0.0001) + 0.5, 0.0, 1.0);
    texel = vec4f(texel.rgb / max(texel.a, 0.05), sharpened);
  }
  // Hybrid lighting (074/06 row 3, the shipped 064 model): prelit is the INDIRECT term, the sun adds a real
  // direct term on the raw albedo. indirect/direct ride frame params — day arcs are a CPU concern.
  // Baked AO modulates ONLY the indirect term (074/07) — sun shadowing is the separate sunVis bake.
  // frame.ambient (plan 093) is SA's own additive ambient floor on top of prelit (ps2BuildingVS
  // Color.rgb += ambient*surfAmb) — normal-independent; vanilla authors shadow prelit as pure
  // black TRUSTING this term, so without it those verts render as holes. AO occludes it like the
  // rest of the indirect light.
  let lit = (debugPrelit(in.prelit) * frame.params.y + frame.ambient.rgb) * in.ao +
    frame.sunColor.rgb * (in.sunNdl * frame.params.z) +
    frame.moonColor.rgb * in.moonNdl +
    in.localLight +
    localLightDynamic(in.world, normalize(in.normal));
  if (debugShowNormals()) {
    return vec4f(debugNormalColor(in.normal), texel.a); // before fog — a fogged normal shows nothing
  }
  var color = texel.rgb * (debugLit(lit) + in.glow);
  // Unified fog (074/06 row 5, the 068 shape): RADIAL distance (view-Z pops at screen edges), exp² over
  // [start, cut], height attenuation (haze hugs the ground), hard horizon cut — and the fog colour is the
  // SKY at this direction, so distant geometry dissolves into exactly what's behind it.
  let toCamera = in.world - frame.camera.xyz;
  let dist = length(toCamera);
  let viewDir = toCamera / max(dist, 0.001);
  let fogD = max(dist - frame.fog.y, 0.0);
  let fogK = 2.0 / max(frame.fog.x - frame.fog.y, 1.0);
  var fogFactor = 1.0 - exp(-(fogK * fogD) * (fogK * fogD));
  let heightAtten = mix(frame.fog.w, 1.0, exp(-max(in.world.y, 0.0) * frame.fog.z));
  fogFactor = fogFactor * heightAtten;
  fogFactor = max(fogFactor, smoothstep(frame.fog.x * 0.85, frame.fog.x, dist));
  // Sky term scaled by texel.a: colour is PREMULTIPLIED, so the blend pipelines (074/06 rows 9/11) stay
  // premult-correct in fog; opaque (a ≈ 1) is unchanged. CUTOUT must NOT scale it (074/21 P2 field fix):
  // A2C coverage already owns the alpha shape, and ×a double-counts it on edge/minified pixels — fully
  // fogged trees left ghost OUTLINES against the sky where the body correctly dissolved.
  let fogAlpha = select(texel.a, 1.0, cutout);
  color = mix(color, fogColorFor(viewDir, fogFactor) * fogAlpha, fogFactor);
  return vec4f(color, texel.a);
}

@fragment
fn fsWorld(in: VsOut) -> @location(0) vec4f {
  return worldShade(in, false);
}

@fragment
fn fsWorldCutout(in: VsOut) -> @location(0) vec4f {
  return worldShade(in, true);
}

@fragment
fn fsBeam(in: VsOut) -> @location(0) vec4f {
  // Floodlight cones (074/06 row 11, plan 032): 'white'-textured geometry whose soft cone lives in the
  // per-vertex prelit ALPHA. Output is PREMULTIPLIED for the (one, one-minus-src-alpha) blend pipeline.
  // No sun/glow terms — a beam is self-lit, tinted only by the dn-mixed prelit colour.
  let texel = textureSample(worldTexture, worldSampler, in.uv, in.layer & 0xffu);
  let alpha = texel.a * in.cone;
  let color = texel.rgb * in.prelit * in.cone;
  // Fog FADES a beam out (scales the premultiplied pair) — mixing toward the sky would tint thin air.
  let dist = length(in.world - frame.camera.xyz);
  let fogD = max(dist - frame.fog.y, 0.0);
  let fogK = 2.0 / max(frame.fog.x - frame.fog.y, 1.0);
  let fade = exp(-(fogK * fogD) * (fogK * fogD)) * (1.0 - smoothstep(frame.fog.x * 0.85, frame.fog.x, dist));
  return vec4f(color * fade, alpha * fade);
}
`},vt=new Set(`as.do.enum.filter.from.get.inline.layout.match.meta.mod.module.move.new.null.of.pass.precise.ref.require.resource.self.set.shared.static.std.target.template.this.type.typedef.union.unless.use.using.where`.split(`.`));function yt(e,t){if(t.includes("`"))throw Error(`<${e}>: backtick in WGSL — it closes the TS template literal (use plain quotes)`);if(/var<uniform>[^;]*:\s*array</.test(t))throw Error(`<${e}>: uniform-space array detected — use a texture or storage buffer (073 guardrail)`);if(/\bloop\s*\{/.test(t)&&!/break/.test(t))throw Error(`<${e}>: unbounded loop detected (073 guardrail)`);let n=[...t.matchAll(/(?:let|var|const)\s+([A-Za-z_]\w*)|(\w+)\s*:\s*(?:vec|mat|f32|u32|i32|bool|array|texture|sampler|ptr)/g)];for(let t of n){let n=t[1]??t[2];if(n&&vt.has(n))throw Error(`<${e}>: '${n}' is a WGSL RESERVED WORD — rename it (the browser is not our linter)`)}}function H(e){let t=new Set,n=e=>{if(t.has(e))throw Error(`shader include cycle at <${e}>`);t.add(e);let r=_t[e];if(!r)throw Error(`unknown shader module <${e}>`);return r.replace(/^#include <(\w+)>$/gm,(e,t)=>n(t))},r=n(e);return yt(e,r),r}var U=`rgba16float`;async function bt(e,t,n,r=t){let i=e.createBindGroupLayout({entries:[{binding:0,buffer:{type:`uniform`},visibility:GPUShaderStage.VERTEX|GPUShaderStage.FRAGMENT},{binding:1,texture:{},visibility:GPUShaderStage.FRAGMENT},{binding:2,sampler:{},visibility:GPUShaderStage.FRAGMENT},{binding:3,buffer:{type:`read-only-storage`},visibility:GPUShaderStage.VERTEX|GPUShaderStage.FRAGMENT},{binding:6,texture:{viewDimension:`2d-array`},visibility:GPUShaderStage.FRAGMENT},{binding:7,texture:{},visibility:GPUShaderStage.FRAGMENT}],label:`frame`}),a=e.createBindGroupLayout({entries:[{binding:0,buffer:{type:`uniform`},visibility:GPUShaderStage.VERTEX}],label:`cell`}),o=e.createBindGroupLayout({entries:[{binding:0,texture:{viewDimension:`2d-array`},visibility:GPUShaderStage.FRAGMENT},{binding:1,sampler:{},visibility:GPUShaderStage.FRAGMENT}],label:`material`}),s=e.createPipelineLayout({bindGroupLayouts:[i,a,o],label:`world`}),c=e.createShaderModule({code:H(`world`),label:`world`}),l=[{arrayStride:36,attributes:[{format:`float32x3`,offset:0,shaderLocation:0},{format:`float32x2`,offset:16,shaderLocation:1},{format:`unorm8x4`,offset:24,shaderLocation:2},{format:`uint16x2`,offset:32,shaderLocation:3},{format:`snorm8x4`,offset:12,shaderLocation:4},{format:`unorm8x4`,offset:28,shaderLocation:5}]}],u=new Map,d=[{blend:!1,cull:`back`,cutout:!1,entry:`fsWorld`,id:`world-opaque-front`},{blend:!1,cull:`none`,cutout:!1,entry:`fsWorld`,id:`world-opaque-double`},{blend:!1,cull:`back`,cutout:!0,entry:`fsWorldCutout`,id:`world-cutout-front`},{blend:!1,cull:`none`,cutout:!0,entry:`fsWorldCutout`,id:`world-cutout-double`},{blend:!0,cull:`back`,cutout:!1,entry:`fsWorld`,id:`world-blend-front`},{blend:!0,cull:`none`,cutout:!1,entry:`fsWorld`,id:`world-blend-double`},{blend:!0,cull:`back`,cutout:!1,entry:`fsBeam`,id:`world-beam-front`},{blend:!0,cull:`none`,cutout:!1,entry:`fsBeam`,id:`world-beam-double`},{additive:!0,blend:!0,cull:`back`,cutout:!1,entry:`fsBeam`,id:`world-additive-front`},{additive:!0,blend:!0,cull:`none`,cutout:!1,entry:`fsBeam`,id:`world-additive-double`}],f={alpha:{dstFactor:`one-minus-src-alpha`,operation:`add`,srcFactor:`one`},color:{dstFactor:`one-minus-src-alpha`,operation:`add`,srcFactor:`one`}},p={alpha:{dstFactor:`one`,operation:`add`,srcFactor:`zero`},color:{dstFactor:`one`,operation:`add`,srcFactor:`one`}},m=e.createShaderModule({code:H(`sky`),label:`sky`}),h=e.createPipelineLayout({bindGroupLayouts:[i],label:`sky`}),g=e.createBindGroupLayout({entries:[{binding:0,texture:{},visibility:GPUShaderStage.FRAGMENT},{binding:1,sampler:{},visibility:GPUShaderStage.FRAGMENT},{binding:2,texture:{},visibility:GPUShaderStage.FRAGMENT}],label:`water`}),_=e.createShaderModule({code:H(`water`),label:`water`});u.set(`water`,e.createRenderPipelineAsync({depthStencil:{depthCompare:`greater`,depthWriteEnabled:!1,format:n},fragment:{entryPoint:`fsWater`,module:_,targets:[{blend:f,format:t}]},label:`water`,layout:e.createPipelineLayout({bindGroupLayouts:[i,g],label:`water`}),multisample:{count:4},primitive:{cullMode:`none`,topology:`triangle-list`},vertex:{buffers:[{arrayStride:20,attributes:[{format:`float32x3`,offset:0,shaderLocation:0},{format:`float32`,offset:12,shaderLocation:1},{format:`float32`,offset:16,shaderLocation:2}]}],entryPoint:`vsWater`,module:_}}));let v=e.createBindGroupLayout({entries:[{binding:0,buffer:{type:`read-only-storage`},visibility:GPUShaderStage.VERTEX},{binding:1,texture:{},visibility:GPUShaderStage.FRAGMENT},{binding:2,sampler:{},visibility:GPUShaderStage.FRAGMENT}],label:`ped`}),y=e.createBindGroupLayout({entries:[{binding:0,buffer:{type:`read-only-storage`},visibility:GPUShaderStage.VERTEX},{binding:1,texture:{viewDimension:`2d-array`},visibility:GPUShaderStage.FRAGMENT},{binding:2,sampler:{},visibility:GPUShaderStage.FRAGMENT},{binding:3,buffer:{type:`read-only-storage`},visibility:GPUShaderStage.VERTEX},{binding:4,buffer:{type:`read-only-storage`},visibility:GPUShaderStage.VERTEX|GPUShaderStage.FRAGMENT},{binding:5,texture:{viewDimension:`cube`},visibility:GPUShaderStage.FRAGMENT},{binding:6,sampler:{},visibility:GPUShaderStage.FRAGMENT},{binding:7,buffer:{type:`read-only-storage`},visibility:GPUShaderStage.VERTEX},{binding:8,texture:{viewDimension:`2d-array`},visibility:GPUShaderStage.FRAGMENT},{binding:9,texture:{viewDimension:`2d-array`},visibility:GPUShaderStage.FRAGMENT},{binding:10,buffer:{hasDynamicOffset:!0,minBindingSize:16,type:`uniform`},visibility:GPUShaderStage.VERTEX}],label:`rigid`}),b=e.createShaderModule({code:H(`rigid`),label:`rigid`}),x=e.createPipelineLayout({bindGroupLayouts:[i,y],label:`rigid`}),S=[{arrayStride:12,attributes:[{format:`float32x3`,offset:0,shaderLocation:0}]},{arrayStride:12,attributes:[{format:`float32x3`,offset:0,shaderLocation:1}]},{arrayStride:8,attributes:[{format:`float32x2`,offset:0,shaderLocation:2}]},{arrayStride:4,attributes:[{format:`unorm8x4`,offset:0,shaderLocation:3}]},{arrayStride:4,attributes:[{format:`uint8x4`,offset:0,shaderLocation:4}]},{arrayStride:4,attributes:[{format:`uint8x4`,offset:0,shaderLocation:5}]},{arrayStride:4,attributes:[{format:`unorm8x4`,offset:0,shaderLocation:6}]}];for(let r of[{blend:!1,entry:`fsRigid`,id:`rigid-opaque`},{blend:!0,entry:`fsRigidBlend`,id:`rigid-blend`}])u.set(r.id,e.createRenderPipelineAsync({depthStencil:{depthCompare:r.blend?`greater-equal`:`greater`,depthWriteEnabled:!r.blend,format:n},fragment:{entryPoint:r.entry,module:b,targets:[{format:t,...r.blend?{blend:{alpha:{dstFactor:`one-minus-src-alpha`,operation:`add`,srcFactor:`one`},color:{dstFactor:`one-minus-src-alpha`,operation:`add`,srcFactor:`one`}}}:{}}]},label:r.id,layout:x,multisample:{count:4},primitive:{cullMode:`none`,frontFace:`ccw`,topology:`triangle-list`},vertex:{buffers:S,entryPoint:`vsRigid`,module:b}}));let C=e.createShaderModule({code:H(`ped`),label:`ped`});u.set(`ped`,e.createRenderPipelineAsync({depthStencil:{depthCompare:`greater`,depthWriteEnabled:!0,format:n},fragment:{entryPoint:`fsPed`,module:C,targets:[{format:t}]},label:`ped`,layout:e.createPipelineLayout({bindGroupLayouts:[i,v],label:`ped`}),multisample:{count:4},primitive:{cullMode:`none`,frontFace:`ccw`,topology:`triangle-list`},vertex:{buffers:[{arrayStride:12,attributes:[{format:`float32x3`,offset:0,shaderLocation:0}]},{arrayStride:12,attributes:[{format:`float32x3`,offset:0,shaderLocation:1}]},{arrayStride:8,attributes:[{format:`float32x2`,offset:0,shaderLocation:2}]},{arrayStride:4,attributes:[{format:`uint8x4`,offset:0,shaderLocation:3}]},{arrayStride:4,attributes:[{format:`unorm8x4`,offset:0,shaderLocation:4}]}],entryPoint:`vsPed`,module:C}}));let w=e.createBindGroupLayout({entries:[{binding:0,buffer:{type:`read-only-storage`},visibility:GPUShaderStage.VERTEX},{binding:1,texture:{viewDimension:`2d-array`},visibility:GPUShaderStage.FRAGMENT},{binding:2,sampler:{},visibility:GPUShaderStage.FRAGMENT}],label:`particle`}),T=e.createShaderModule({code:H(`particle`),label:`particle`}),E=[{arrayStride:8,attributes:[{format:`float32x2`,offset:0,shaderLocation:0}]},{arrayStride:36,attributes:[{format:`float32x3`,offset:0,shaderLocation:1},{format:`float32x3`,offset:12,shaderLocation:2},{format:`float32x3`,offset:24,shaderLocation:3}],stepMode:`instance`}];for(let r of[{add:!0,constants:{oneShot:0},id:`particle-add`},{add:!1,constants:{oneShot:0},id:`particle-blend`},{add:!0,constants:{oneShot:1},id:`particle-add-once`},{add:!1,constants:{oneShot:1},id:`particle-blend-once`}])u.set(r.id,e.createRenderPipelineAsync({depthStencil:{depthCompare:`greater`,depthWriteEnabled:!1,format:n},fragment:{entryPoint:`fsParticle`,module:T,targets:[{blend:r.add?{alpha:{dstFactor:`one`,operation:`add`,srcFactor:`one`},color:{dstFactor:`one`,operation:`add`,srcFactor:`one`}}:f,format:t}]},label:r.id,layout:e.createPipelineLayout({bindGroupLayouts:[i,w],label:`particle`}),multisample:{count:4},primitive:{topology:`triangle-list`},vertex:{buffers:E,constants:r.constants,entryPoint:`vsParticle`,module:T}}));let D=e.createBindGroupLayout({entries:[{binding:0,texture:{},visibility:GPUShaderStage.FRAGMENT},{binding:1,sampler:{},visibility:GPUShaderStage.FRAGMENT}],label:`skid`}),O=e.createShaderModule({code:H(`skid`),label:`skid`});u.set(`skid`,e.createRenderPipelineAsync({depthStencil:{depthCompare:`greater`,depthWriteEnabled:!1,format:n},fragment:{entryPoint:`fsSkid`,module:O,targets:[{blend:f,format:t}]},label:`skid`,layout:e.createPipelineLayout({bindGroupLayouts:[i,D],label:`skid`}),multisample:{count:4},primitive:{cullMode:`none`,topology:`triangle-list`},vertex:{buffers:[{arrayStride:28,attributes:[{format:`float32x3`,offset:0,shaderLocation:0},{format:`float32x2`,offset:12,shaderLocation:1},{format:`float32x2`,offset:20,shaderLocation:2}]}],entryPoint:`vsSkid`,module:O}}));let k=e.createBindGroupLayout({entries:[{binding:0,buffer:{type:`uniform`},visibility:GPUShaderStage.VERTEX|GPUShaderStage.FRAGMENT},{binding:1,texture:{viewDimension:`2d-array`},visibility:GPUShaderStage.FRAGMENT},{binding:2,sampler:{},visibility:GPUShaderStage.FRAGMENT}],label:`debris`}),A=e.createShaderModule({code:H(`debris`),label:`debris`});u.set(`debris`,e.createRenderPipelineAsync({depthStencil:{depthCompare:`greater`,depthWriteEnabled:!1,format:n},fragment:{entryPoint:`fsDebris`,module:A,targets:[{blend:f,format:t}]},label:`debris`,layout:e.createPipelineLayout({bindGroupLayouts:[i,k],label:`debris`}),multisample:{count:4},primitive:{cullMode:`none`,topology:`triangle-list`},vertex:{buffers:[{arrayStride:80,attributes:[{format:`float32x3`,offset:0,shaderLocation:0},{format:`float32x2`,offset:12,shaderLocation:1},{format:`float32x4`,offset:20,shaderLocation:2},{format:`float32x3`,offset:36,shaderLocation:3},{format:`float32x3`,offset:48,shaderLocation:4},{format:`float32x3`,offset:60,shaderLocation:5},{format:`float32x2`,offset:72,shaderLocation:6}]}],entryPoint:`vsDebris`,module:A}}));let j=e.createBindGroupLayout({entries:[{binding:0,buffer:{type:`uniform`},visibility:GPUShaderStage.VERTEX|GPUShaderStage.FRAGMENT}],label:`debug-line`});Ct(e,t,n,j,i,u);let M=e.createShaderModule({code:H(`corona`),label:`corona`});u.set(`corona`,e.createRenderPipelineAsync({depthStencil:{depthCompare:`greater`,depthWriteEnabled:!1,format:n},fragment:{entryPoint:`fsCorona`,module:M,targets:[{blend:{alpha:{dstFactor:`one`,operation:`add`,srcFactor:`one`},color:{dstFactor:`one`,operation:`add`,srcFactor:`one`}},format:t}]},label:`corona`,layout:h,multisample:{count:4},primitive:{topology:`triangle-list`},vertex:{buffers:[{arrayStride:8,attributes:[{format:`float32x2`,offset:0,shaderLocation:0}]},{arrayStride:32,attributes:[{format:`float32x3`,offset:0,shaderLocation:1},{format:`float32`,offset:12,shaderLocation:2},{format:`float32x4`,offset:16,shaderLocation:3}],stepMode:`instance`}],entryPoint:`vsCorona`,module:M}}));let ee=e.createBindGroupLayout({entries:[{binding:0,buffer:{type:`uniform`},visibility:GPUShaderStage.FRAGMENT},{binding:1,texture:{},visibility:GPUShaderStage.FRAGMENT},{binding:2,sampler:{},visibility:GPUShaderStage.FRAGMENT},{binding:3,texture:{},visibility:GPUShaderStage.FRAGMENT}],label:`post`}),te=e.createShaderModule({code:H(`post`),label:`post`});u.set(`post`,e.createRenderPipelineAsync({fragment:{entryPoint:`fsPost`,module:te,targets:[{format:r}]},label:`post`,layout:e.createPipelineLayout({bindGroupLayouts:[ee],label:`post`}),primitive:{topology:`triangle-list`},vertex:{entryPoint:`vsPost`,module:te}}));let{bloomLayout:ne,bloomUpLayout:re}=St(e,t,u),N=wt(e,t,u),P=e.createBindGroupLayout({entries:[{binding:0,buffer:{type:`uniform`},visibility:GPUShaderStage.VERTEX|GPUShaderStage.FRAGMENT}],label:`cloud-field`}),ie=e.createShaderModule({code:H(`cloud-field`),label:`cloud-field`});u.set(`cloud-field`,e.createRenderPipelineAsync({fragment:{entryPoint:`fsCloudField`,module:ie,targets:[{format:`rg16float`}]},label:`cloud-field`,layout:e.createPipelineLayout({bindGroupLayouts:[P],label:`cloud-field`}),primitive:{topology:`triangle-list`},vertex:{entryPoint:`vsCloudField`,module:ie}}));let ae=e.createBindGroupLayout({entries:[{binding:0,texture:{viewDimension:`cube`},visibility:GPUShaderStage.FRAGMENT},{binding:1,sampler:{},visibility:GPUShaderStage.FRAGMENT}],label:`probe-view`}),F=e.createShaderModule({code:H(`probe-view`),label:`probe-view`});u.set(`probe-view`,e.createRenderPipelineAsync({depthStencil:{depthCompare:`always`,depthWriteEnabled:!1,format:n},fragment:{entryPoint:`fsProbeView`,module:F,targets:[{format:t}]},label:`probe-view`,layout:e.createPipelineLayout({bindGroupLayouts:[i,ae],label:`probe-view`}),multisample:{count:4},primitive:{topology:`triangle-list`},vertex:{entryPoint:`vsProbeView`,module:F}})),u.set(`sky`,e.createRenderPipelineAsync({depthStencil:{depthCompare:`greater-equal`,depthWriteEnabled:!1,format:n},fragment:{entryPoint:`fsSky`,module:m,targets:[{format:t}]},label:`sky`,layout:h,multisample:{count:4},primitive:{topology:`triangle-list`},vertex:{entryPoint:`vsSky`,module:m}}));let I=e.createBindGroupLayout({entries:[{binding:0,buffer:{type:`read-only-storage`},visibility:GPUShaderStage.VERTEX},{binding:1,texture:{viewDimension:`2d-array`},visibility:GPUShaderStage.FRAGMENT},{binding:2,sampler:{},visibility:GPUShaderStage.FRAGMENT},{binding:3,buffer:{type:`uniform`},visibility:GPUShaderStage.VERTEX}],label:`clutter`}),oe=e.createShaderModule({code:H(`clutter`),label:`clutter`}),se=e.createPipelineLayout({bindGroupLayouts:[i,I],label:`clutter`}),ce=[{arrayStride:12,attributes:[{format:`float32x3`,offset:0,shaderLocation:0}]},{arrayStride:12,attributes:[{format:`float32x3`,offset:0,shaderLocation:1}]},{arrayStride:8,attributes:[{format:`float32x2`,offset:0,shaderLocation:2}]},{arrayStride:4,attributes:[{format:`unorm8x4`,offset:0,shaderLocation:3}]},{arrayStride:4,attributes:[{format:`uint8x4`,offset:0,shaderLocation:4}]},{arrayStride:4,attributes:[{format:`unorm8x4`,offset:0,shaderLocation:5}]}];for(let r of[!1,!0])u.set(r?`clutter-cutout`:`clutter-opaque`,e.createRenderPipelineAsync({depthStencil:{depthCompare:`greater`,depthWriteEnabled:!0,format:n},fragment:{entryPoint:r?`fsClutterCutout`:`fsClutter`,module:oe,targets:[{format:t}]},label:r?`clutter-cutout`:`clutter-opaque`,layout:se,multisample:{alphaToCoverageEnabled:r,count:4},primitive:{cullMode:`none`,frontFace:`ccw`,topology:`triangle-list`},vertex:{buffers:ce,entryPoint:`vsClutter`,module:oe}}));for(let r of d){let i=Tt(r,f,p);u.set(r.id,e.createRenderPipelineAsync({depthStencil:{depthCompare:r.blend?`greater-equal`:`greater`,depthWriteEnabled:!r.blend,format:n},fragment:{entryPoint:r.entry,module:c,targets:[{format:t,...i===void 0?{}:{blend:i}}]},label:r.id,layout:s,multisample:{alphaToCoverageEnabled:r.cutout,count:4},primitive:{cullMode:r.cull,frontFace:`ccw`,topology:`triangle-list`},vertex:{buffers:l,entryPoint:`vsWorld`,module:c}}))}let le=new Map(await Promise.all([...u].map(async([e,t])=>[e,await t])));return{bloomLayout:ne,bloomUpLayout:re,cellLayout:a,cloudFieldLayout:P,clutterLayout:I,debrisLayout:k,debugLineLayout:j,frameLayout:i,get(e){let t=le.get(e);if(!t)throw Error(`pipeline miss in steady state: ${e} (074 ground rule 3 — enumerate it in compileAll)`);return t},materialLayout:o,particleLayout:w,pedLayout:v,postLayout:ee,probeMipLayout:N,probeViewLayout:ae,rigidLayout:y,skidLayout:D,waterLayout:g}}function xt(e,t){return`world-${[`opaque`,`cutout`,`blend`,`beam`,`additive`][e]??`cutout`}-${t===1?`double`:`front`}`}function St(e,t,n){let r=e.createBindGroupLayout({entries:[{binding:0,buffer:{type:`uniform`},visibility:GPUShaderStage.FRAGMENT},{binding:1,texture:{},visibility:GPUShaderStage.FRAGMENT},{binding:2,sampler:{},visibility:GPUShaderStage.FRAGMENT}],label:`bloom`}),i=e.createBindGroupLayout({entries:[{binding:0,buffer:{type:`uniform`},visibility:GPUShaderStage.FRAGMENT},{binding:1,texture:{},visibility:GPUShaderStage.FRAGMENT},{binding:2,sampler:{},visibility:GPUShaderStage.FRAGMENT},{binding:3,texture:{},visibility:GPUShaderStage.FRAGMENT}],label:`bloom-up`}),a=e.createShaderModule({code:H(`bloom`),label:`bloom`}),o=[[`bloom-prefilter`,`fsBloomPrefilter`,r],[`bloom-down`,`fsBloomDown`,r],[`bloom-up`,`fsBloomUp`,i]];for(let[r,i,s]of o)n.set(r,e.createRenderPipelineAsync({fragment:{entryPoint:i,module:a,targets:[{format:t}]},label:r,layout:e.createPipelineLayout({bindGroupLayouts:[s],label:r}),primitive:{topology:`triangle-list`},vertex:{entryPoint:`vsBloom`,module:a}}));return{bloomLayout:r,bloomUpLayout:i}}function Ct(e,t,n,r,i,a){let o=e.createShaderModule({code:H(`debug-line`),label:`debug-line`}),s=e.createPipelineLayout({bindGroupLayouts:[i,r],label:`debug-line`});for(let[r,i]of[[`debug-line`,`greater`],[`debug-line-through`,`always`]])a.set(r,e.createRenderPipelineAsync({depthStencil:{depthCompare:i,depthWriteEnabled:!1,format:n},fragment:{entryPoint:`fsDebugLine`,module:o,targets:[{format:t}]},label:r,layout:s,multisample:{count:4},primitive:{topology:`line-list`},vertex:{buffers:[{arrayStride:12,attributes:[{format:`float32x3`,offset:0,shaderLocation:0}]}],entryPoint:`vsDebugLine`,module:o}}))}function wt(e,t,n){let r=e.createBindGroupLayout({entries:[{binding:0,texture:{},visibility:GPUShaderStage.FRAGMENT},{binding:1,sampler:{},visibility:GPUShaderStage.FRAGMENT}],label:`probe-mip`}),i=e.createShaderModule({code:H(`probe`),label:`probe`}),a=e.createPipelineLayout({bindGroupLayouts:[r],label:`probe-mip`});for(let[r,o]of[[`probe-blit`,`fsProbeBlit`],[`probe-mip`,`fsProbeMip`]])n.set(r,e.createRenderPipelineAsync({fragment:{entryPoint:o,module:i,targets:[{format:t}]},label:r,layout:a,primitive:{topology:`triangle-list`},vertex:{entryPoint:`vsProbeMip`,module:i}}));return r}function Tt(e,t,n){if(e.blend)return e.additive===!0?n:t}var Et=80,Dt=.5,Ot=2e3,kt=`depth32float`,At=[[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]],jt=[[0,-1,0],[0,-1,0],[0,0,1],[0,0,-1],[0,-1,0],[0,-1,0]],Mt=class{cubeView;sampler;blitBindGroup;depthView;device;faceMipViews;facesDone=0;lastCenter=[0,0,0];mipBindGroups;msaaView;nextFace=0;pipelines;proj=w();scratchView;view=w();constructor(e,t,n){this.device=e,this.pipelines=n,k(this.proj,Math.PI/2,1,Ot,Dt);let r=t.createTexture(`target`,{format:U,label:`env-probe`,mipLevelCount:8,size:{depthOrArrayLayers:6,height:128,width:128},usage:GPUTextureUsage.RENDER_ATTACHMENT|GPUTextureUsage.TEXTURE_BINDING},1053819);this.cubeView=r.createView({dimension:`cube`,label:`env-probe`}),this.sampler=e.createSampler({label:`env-probe`,magFilter:`linear`,minFilter:`linear`,mipmapFilter:`linear`});let i=t.createTexture(`target`,{format:U,label:`env-probe-msaa`,sampleCount:4,size:{height:128,width:128},usage:GPUTextureUsage.RENDER_ATTACHMENT},16384*8*4);this.msaaView=i.createView();let a=t.createTexture(`target`,{format:kt,label:`env-probe-depth`,sampleCount:4,size:{height:128,width:128},usage:GPUTextureUsage.RENDER_ATTACHMENT},16384*4*4);this.depthView=a.createView();let o=t.createTexture(`target`,{format:U,label:`env-probe-scratch`,size:{height:128,width:128},usage:GPUTextureUsage.RENDER_ATTACHMENT|GPUTextureUsage.TEXTURE_BINDING},16384*8);this.scratchView=o.createView(),this.blitBindGroup=e.createBindGroup({entries:[{binding:0,resource:this.scratchView},{binding:1,resource:this.sampler}],label:`env-probe-blit`,layout:n.probeMipLayout}),this.faceMipViews=[],this.mipBindGroups=[];for(let t=0;t<6;t+=1){let i=[];for(let e=0;e<8;e+=1)i.push(r.createView({baseArrayLayer:t,baseMipLevel:e,dimension:`2d`,label:`env-probe:${t}:${e}`,mipLevelCount:1}));this.faceMipViews.push(i);let a=[];for(let r=1;r<8;r+=1)a.push(e.createBindGroup({entries:[{binding:0,resource:i[r-1]},{binding:1,resource:this.sampler}],label:`env-probe-mip:${t}:${r}`,layout:n.probeMipLayout}));this.mipBindGroups.push(a)}}beginFrame(e){Math.hypot(e[0]-this.lastCenter[0],e[1]-this.lastCenter[1],e[2]-this.lastCenter[2])>Et&&(this.facesDone=0,this.nextFace=0),[this.lastCenter[0],this.lastCenter[1],this.lastCenter[2]]=e;let t=this.nextFace,n=this.mix();return this.nextFace=(this.nextFace+1)%6,this.facesDone=Math.min(12,this.facesDone+1),{face:t,mix:n}}encodeFace(e,t,n,r,i,a){let o=e.beginRenderPass({colorAttachments:[{clearValue:i,loadOp:`clear`,resolveTarget:this.scratchView,storeOp:`discard`,view:this.msaaView}],depthStencilAttachment:{depthClearValue:0,depthLoadOp:`clear`,depthStoreOp:`discard`,view:this.depthView},label:`env-probe-face-${t}`,...a.begin});n.length>0&&o.executeBundles([...n]),o.setPipeline(this.pipelines.get(`sky`)),o.setBindGroup(0,r),o.draw(3),o.end(),this.runMipPass(e,`probe-blit`,this.blitBindGroup,this.faceMipViews[t][0],{});for(let n=1;n<8;n+=1)this.runMipPass(e,`probe-mip`,this.mipBindGroups[t][n-1],this.faceMipViews[t][n],n===7?a.end:{})}faceMatrices(e,t,n,r){let i=At[e];E(this.view,t,[t[0]+i[0],t[1]+i[1],t[2]+i[2]],jt[e]),D(n,this.proj,this.view),T(r,n)}mix(){return Math.min(1,this.facesDone/6)}runMipPass(e,t,n,r,i){let a=e.beginRenderPass({colorAttachments:[{clearValue:{a:0,b:0,g:0,r:0},loadOp:`clear`,storeOp:`store`,view:r}],label:t,...i});a.setPipeline(this.pipelines.get(t)),a.setBindGroup(0,n),a.draw(3),a.end()}},Nt=4096,Pt=class{capacity;data;get count(){return this.length}births;cursor=0;length=0;start=0;constructor(e){this.capacity=e,this.data=new Float32Array(e*6*7),this.births=new Float64Array(e)}prune(e){let t=!1;for(;this.length>0&&e-this.births[this.start]>=12;)this.start=(this.start+1)%this.capacity,--this.length,t=!0;return t}push(e,t){let n=this.cursor;this.cursor=(this.cursor+1)%this.capacity,this.length===this.capacity?this.start=this.cursor:this.length+=1,this.births[n]=t;let r=n*6*7,i=this.data,a=(e,n,a,o,s)=>{let c=r+e*7;i[c]=n[0],i[c+1]=n[1],i[c+2]=n[2],i[c+3]=a,i[c+4]=o,i[c+5]=s,i[c+6]=t};return a(0,e.l0,0,e.v0,e.alpha0),a(1,e.r0,1,e.v0,e.alpha0),a(2,e.l1,0,e.v1,e.alpha1),a(3,e.r0,1,e.v0,e.alpha0),a(4,e.r1,1,e.v1,e.alpha1),a(5,e.l1,0,e.v1,e.alpha1),n}ranges(){if(this.length===0)return[];let e=this.start+this.length;return e<=this.capacity?[{count:this.length,first:this.start}]:[{count:this.capacity-this.start,first:this.start},{count:e-this.capacity,first:0}]}},Ft=class{ring=new Pt(Nt);bindGroup;buffer;device;resources;texture;textureBytes;constructor(e,t,n,r){this.device=e,this.resources=t,this.buffer=t.createBuffer(`debris`,{label:`skid-marks`,size:Nt*6*7*4,usage:GPUBufferUsage.VERTEX|GPUBufferUsage.COPY_DST}),this.textureBytes=r.rgba.byteLength,this.texture=t.createTexture(`texture`,{format:`rgba8unorm-srgb`,label:`skid-texture`,size:{height:r.height,width:r.width},usage:GPUTextureUsage.TEXTURE_BINDING|GPUTextureUsage.COPY_DST},this.textureBytes),e.queue.writeTexture({texture:this.texture},r.rgba,{bytesPerRow:r.width*4},{height:r.height,width:r.width}),this.bindGroup=e.createBindGroup({entries:[{binding:0,resource:this.texture.createView()},{binding:1,resource:e.createSampler({addressModeU:`clamp-to-edge`,addressModeV:`repeat`,label:`skid`,magFilter:`linear`,minFilter:`linear`})}],label:`skid`,layout:n})}add(e,t){let n=this.ring.push(e,t);this.device.queue.writeBuffer(this.buffer,n*42*4,this.ring.data,n*42,42)}destroy(){this.resources.destroyBuffer(`debris`,this.buffer),this.resources.destroyTexture(`texture`,this.texture,this.textureBytes)}draw(e,t,n,r){this.ring.prune(r);let i=this.ring.ranges();if(i.length===0)return 0;e.setPipeline(t),e.setBindGroup(0,n),e.setBindGroup(1,this.bindGroup),e.setVertexBuffer(0,this.buffer);for(let t of i)e.draw(t.count*6,1,t.first*6,0);return i.length}},It=[new Float64Array([-1.099459,-.1335146,-4.083223,5.919603,-.1104166,1.600158,-1326538e-12,4.917807,.5127716,-1.169858,-.1832793,.9694744,.09495762,-.04738918,.2194171,.1095749,3.603604,.3815119,-.9665225,-.1403888,5.194457,-1.107607,-.8135181,4.969661,-.2300508,-2.48935,1.279158,-1.292508,-.1299552,-2.071404,-.04752482,1.215598,-1.904179,.3027985,8.707768,.06332446,-.9264666,-.169678,4.57407,-.4232936,-7.575833,5.079755,-.2576343,-4.506805,.6908129,-1.139072,-.1796056,1.923311,6.788529,-2.364389,-1.064041,.171701,1.534681,.501581,-1.107257,-.1384411,-4.285744,5.713157,-.1015992,1.372638,.06555893,5.127514,.6550471,-1.187337,-.1969013,.8551048,.05289708,-.07626406,.01733153,.1779454,3.801038,.4742709,-.9685321,-.1553308,4.732492,-1.178935,-.7852791,4.604492,-.2666518,-2.367663,1.177527,-1.252817,-.05129949,-2.800433,-.01295992,1.308964,-2.204331,.7276011,8.699265,.1188388,-.9459509,-.2322133,4.375041,-.1712018,-7.451681,5.078019,-.4223538,-4.595561,1.074719,-1.125092,-.179675,1.626399,6.989743,-2.406382,-.9060383,.2961611,1.337715,.543814,-1.135338,-.171616,-1.499253,2.373491,-.1654023,.9566404,.1113453,4.528473,.6579439,-1.13278,-.1456214,-1.736672,1.756589,-.1087003,.3757927,.252507,7.178513,.5003814,-1.167176,-.2927225,5.727667,-3.139244,-.6425204,2.822634,-.1457812,-6.78708,1.017072,-1.042529,.04110823,-4.000629,4.362364,1.09054,-1.338674,.8246964,10.95249,.2912211,-1.061598,-.2096143,3.803155,-7.977069,-3.63788,3.707671,-.1903128,-3.397953,.99715,-1.07356,-.2077964,1.492052,16.26322,-5.015304,-.4059889,.2659782,.639538,.5634436,-1.172794,-.2111186,-1.360013,1.60408,-.08473723,.7217312,.154803,4.25701,.6328974,-1.238374,-.2670827,.3247678,.5466311,-.7425952,.527644,.02678026,5.484169,.6814734,-1.176923,-.2574586,2.304045,-2.797678,1.464405,1.998552,.2550559,-4.199772,.7544892,-1.003284,.01943984,-2.145066,10.30924,-15.25413,-2.02301,.5448699,8.159497,.5539148,-1.060017,-.2037206,2.483018,-4.595459,6.526991,4.031804,.1206513,-2.586527,.7875752,-1.081141,-.2123302,1.092275,2.683841,-4.166938,-1.396582,.4371205,1.030233,.6664862,-1.222392,-.2651924,-.4625037,.3521964,.02148855,.5078494,.179159,3.852516,.5998216,-1.42461,-.4710155,-.1826815,1.786277,-1.952442,.5277612,-.01773629,2.415874,.6701272,-1.130655,-.1358609,.9171203,-4.660394,6.251162,1.904529,.2639668,1.85613,.822844,-.9739015,-.06674749,-.4768897,12.48589,-19.94688,-2.353043,.5885575,1.287251,.4830135,-1.082178,-.1974495,1.050245,-4.792855,8.663406,3.246969,.1556731,.8117442,.8050376,-1.063354,-.1727108,.9681592,2.736077,-4.969269,-.836057,.5994612,1.024039,.6786935,-1.261936,-.3053676,-.4262222,.4000196,-.02059388,.4721802,.1480028,3.505343,.6121337,-1.681088,-.6971919,-.1105652,.7437426,-.6594399,.2254221,.08710195,1.263913,.5681865,-.9453001,.03460388,.6067038,-1.985128,3.457236,2.655483,-.01162354,3.304716,1.00195,-1.086609,-.2029011,-.639917,6.926885,-15.12189,-3.793051,.945612,.2222222,.2893725,-1.041259,-.138879,1.147331,6.282086,3.679836,4.398314,-.1355232,1.031134,.9273509,-1.063473,-.1916051,.6556979,-.003371891,-3.699664,-1.926783,.7371154,1.179975,.6367068,-1.33639,-.3778927,-.7259477,.2270247,.4627513,.1366459,.2637347,3.292059,.4998211,-2.119878,-1.055472,.5422052,.7826648,-1.286065,.9517905,-.1432358,-.2379816,.5910513,-.7761432,.2124336,-.6845184,-.9812342,4.347257,.967198,.377315,5.789529,.9646598,-1.118734,-.3513815,.5500918,.9449627,-12.6207,-1.82528,.473126,-3.326892,.3568768,-1.026437,-.08257946,.3221701,11.98372,1.55513,2.560304,.1406465,2.912858,.8643181,-1.069949,-.2029607,.5825042,-.002398595,-3.278335,-1.349882,.7208433,.8505164,.6625391,-1.392309,-.4454945,-.5664,.6283393,-.3761727,.6949802,.07748178,3.192797,.5968661,-2.713405,-1.395112,.202923,.1877272,-.3715859,-.1652929,.2385861,-.4150768,.1375467,-.9588644,.024339,-1.527493,-.9632874,5.496269,1.094931,.2004044,6.084554,1.369604,-.8028546,-.2473563,1.617898,2.073591,-11.49446,-.8394131,.2726847,-4.634538,.1367293,-1.198326,-.1804865,-.3565414,4.0732,1.662086,1.23977,.3367978,2.997402,.9360383,-1.013531,-.185906,.5799857,13.31883,-4.346873,-1.11382,.5275714,.8045177,.6496373,-1.530103,-.6107468,-.3841771,1.881508,-1.464807,.665469,-5950797e-12,2.738912,.8101012,-2.415469,-1.057499,-.4161968,-2.357548,.6300296,.6224915,.01545048,2.038561,-.1339415,-3.096796,-1.465688,-1.199232,4.567061,3.26098,-.9794907,.8950491,2.049235,1.331015,.2713904,.2852852,1.20209,-8.206784,-5.805762,1.804431,-.6090648,-1.990902,.3288858,-1.45658,-.345596,-.06409257,16.67697,-2.311094,-.9771104,.6759863,1.245136,.7911932,-.9860389,-.2099564,.294665,-.0035478,-2.268313,-.06205647,.4705185,.8657995,.6856284,-1.971736,-.9414047,-.3400557,1.468763,-1.474284,.5501062,-110975e-10,2.35637,.9001702,-1.589845,-.7797079,-.558224,-.8137376,.5846617,.1129459,-.02658005,2.707248,-.2112486,-6.940173,-2.823963,-1.620848,1.090696,2.39173,1.370047,.5890462,1.7284,1.331253,1.293144,-.001919778,1.644206,-.8666967,-7.161953,-1.385018,-.1505374,-1.388643,.2530122,-1.48888,-.2495496,-.2377137,11.67714,-.8617124,1.053828,.1992744,.3633564,.8553304,-1.060891,-.4035829,.2823207,-.002369798,-1.876577,-.5950265,.4241017,.3140802,.6631669,-1.101204,-.1351353,-4.030882,6.096353,-.1148599,1.606507,-1555474e-12,4.436084,.5973715,-1.154597,-.1923378,.8512132,.2934895,-.06522777,.1389077,.09091469,3.133307,.2108541,-1.031588,-.1546804,5.266214,-.949139,-.7184867,4.875626,-.1911907,-2.865642,1.087895,-1.159454,-.09546699,-1.508146,-.02031411,1.040653,-2.333508,.2540592,8.594981,.0931677,-1.03594,-.2021151,4.719343,-.9019318,-7.858046,3.901234,-.2233137,-4.344739,.6550733,-1.096669,-.1558196,2.057553,6.274495,-2.678352,-1.814927,.1550676,1.903276,.4998989,-1.114209,-.1473531,-7.602914,8.973685,-.04980074,1.289198,.08366906,4.557987,.6118757,-1.149397,-.1981628,4.914096,-3.498986,-.0625709,.1667401,.104898,2.284689,.5935965,-1.056121,-.1456172,.4272656,2.912649,-.5501745,4.406542,-.138768,1.245555,.9733011,-1.125047,-.04003662,1.058457,-3.462236,.4395278,-2.395805,.5177589,4.866247,.4253189,-1.051444,-.2804541,3.364668,3.293787,-10.15741,3.807407,-.3592377,-3.367415,.7900825,-1.093847,-.1436965,2.38478,5.78707,-2.445987,-1.311171,.2326563,1.158439,.5555416,-1.134824,-.1680468,-3.32562,4.458596,-.1135063,1.1045,.07794544,4.609952,.6854854,-1.143017,-.1565926,.3014687,-.1763027,-.03557925,-.2342406,.2528705,5.884085,.4750602,-1.136801,-.2907502,3.682423,-.4061202,-.8728159,4.00151,-.1522202,-5.528713,1.044847,-1.063652,.07808107,-1.983678,.3648078,2.102276,-3.06505,.8431951,10.3883,.2662834,-1.061015,-.2859814,4.223615,-2.290138,-8.31401,4.405718,-.4613627,-4.50291,1.008383,-1.106302,-.1697123,2.087196,8.238929,-2.992416,-1.821776,.3434859,.7755179,.534119,-1.17111,-.2106304,-1.614361,2.378103,-.1625969,.8504483,.1059312,4.046256,.6618227,-1.20048,-.2235733,1.01439,-1.174074,-.444018,.2262406,.1665868,5.461829,.567631,-1.223587,-.3502622,1.699106,.6724266,1.268567,2.135102,.0008039374,-5.221111,.944569,-.9452673,.1468459,-1.335034,4.346628,-12.85652,-1.807046,.8175243,9.301065,.3656798,-1.134681,-.3310951,3.571244,-2.208948,6.04158,3.107577,-.3112127,-4.186351,.9188333,-1.083237,-.1831394,2.062654,1.385424,-5.00495,-1.332669,.3627352,.332315,.6191181,-1.211527,-.2590617,-.1660874,.3627905,-.1039258,.4697924,.1671653,3.507497,.6022506,-1.433017,-.4733592,.1724445,.9953236,-1.874457,.4432099,.0171581,2.339272,.644147,-1.08492,-.1587903,.8999585,-2.537516,5.877859,2.014554,.09689141,.3177242,.9030399,-1.008242,.00279303,-.3507469,10.283,-20.80454,-2.781026,.899509,3.366951,.3473867,-1.103151,-.2799598,2.525791,-4.255704,9.903388,3.722668,-.3603941,-1.303292,.9369454,-1.102235,-.2025061,2.08566,1.686787,-5.010957,-1.656458,.4584029,-.2751759,.6184162,-1.25613,-.3104904,.163935,.1315502,-.7297583,.477848,.1259265,3.012108,.6202728,-1.620114,-.655267,-.2877157,1.094371,.2818914,.369683,.09428521,1.450951,.5681308,-.9686204,-.03755647,1.46998,-3.103414,2.856583,1.883209,-.05746099,1.286383,1.001751,-1.089377,-.1023062,-1.498891,10.66455,-17.20184,-2.759314,1.061258,2.910211,.2624701,-1.044681,-.2156857,3.230136,-.5863862,6.09664,3.550019,-.4255773,-1.500033,.9687696,-1.133658,-.2505101,1.71784,.008480428,-5.011789,-1.740989,.498343,-.2081829,.6088641,-1.335366,-.3863319,-.5279971,.3638324,.3230699,.08339707,.2483293,2.678646,.4998346,-2.004511,-.9957121,1.250807,.01625025,-.3410754,.7858244,-.09506757,.02651876,.5788643,-.8714157,.1192051,-.8486879,-.3702497,1.818277,1.103427,.2454866,3.841575,.984735,-1.042618,-.2285793,.3620175,2.983368,-9.776844,-1.971587,.6691674,-.7901947,.32132,-1.099112,-.1869868,2.044065,2.062964,1.265668,2.71013,-.1099443,.2179353,.9024108,-1.106985,-.2396881,1.809807,8.523319,-5.011788,-1.590086,.3248449,-.1003187,.6550606,-1.421285,-.4767024,-.3885004,.827459,-.3644229,.6999513,.0519671,2.578431,.624631,-2.611217,-1.398846,.4527425,-.5932142,.2224617,-.5593581,.3389633,-.7767112,.06536004,-.9881543,.04684782,-.8616613,.8799807,4.00313,1.739543,-.08098378,5.524802,1.499673,-.7544759,-.2314808,.812577,-.7724135,-9.577645,-1.629433,.6790832,-4.193895,-.02526624,-1.273719,-.218703,1.401798,5.231832,.7405093,1.775166,-.07269476,1.996087,1.05745,-1.046864,-.2247559,1.679449,11.40057,-4.948829,-1.182664,.3241038,-.2470012,.61159,-1.514607,-.598543,-.187761,1.75693,-1.314206,.611581,-597046e-11,2.412975,.8124304,-2.308414,-1.083797,-.1179959,-1.728246,.7784742,.5494505,.006203168,.9326251,-.1419518,-3.230837,-1.43867,-.9868286,2.974393,1.949339,-.6337857,.8160271,3.278606,1.354373,.5149378,.2754789,1.040965,-4.501186,-3.399057,.9661861,-.4736173,-4.037574,.2794847,-1.62187,-.3192763,.8786242,9.785565,-2.727652,.01903691,.5521261,2.138764,.8419871,-.9951701,-.2550607,1.498952,-.002737197,-3.101832,-.5921329,.2864422,-.4405218,.663141,-1.902954,-.9056918,-.206957,1.191499,-1.092577,.5849556,-9649602e-12,2.048407,.9001527,-1.271627,-.7193923,-.01136606,-.1167951,.003286175,-.05262827,-.02473874,1.716125,-.2187133,-7.647175,-3.114129,-1.490128,-.5266488,3.06309,1.474262,.5481458,2.052174,1.353089,2.191403,.342112,1.44651,2.170943,-7.768187,-1.471207,-.1456708,-1.753574,.2310576,-1.932296,-.3814739,.6245422,6.748294,-.3060171,1.067747,.2500671,-.1252596,.8614611,-.9471101,-.405264,1.300174,-.003951536,-1.908284,-.5385721,.2133578,-.6250292,.6658012]),new Float64Array([-1.14053,-.1982747,-7.51273,8.403899,-.05699038,.9015907,.03392161,4.772522,.5111184,-1.165117,-.1852955,2.963684,-2.262274,-.1571683,.6339974,.04977879,7.243307,.4220053,-1.169936,-.3357429,1.911291,-.2391074,-.4791643,1.446113,-.09178108,-4.700239,.8096219,-1.060246,-.1051633,.5013829,2.832309,-.3707855,1.523131,.09163749,5.604183,.7208566,-1.089753,-.2382167,2.360312,-5.902562,-8.799894,1.377692,-.06131633,-1.415472,.6124057,-1.075481,-.1242391,1.425781,8.810319,-2.922646,1.48652,.0327058,3.889783,.4999482,-1.149342,-.2076337,-7.446587,8.014559,-.04866227,.8203043,.06386483,4.894198,.5452051,-1.120531,-.1513311,2.735504,-2.417591,-.1361114,.4296342,.09427488,8.171403,.4102448,-1.226964,-.3516378,1.308298,-.05097487,-.4846783,1.654619,-.113494,-3.347854,1.131147,-.9664377,.02767589,.1658235,2.407439,-.1300304,.9170958,.2742895,6.642633,.2550064,-1.153358,-.3126223,2.078934,-5.857733,-8.659848,1.758505,-.09616094,-1.230863,.9663832,-1.05385,-.1330743,1.481738,10.49485,-3.528854,.9142363,.124488,2.644615,.5001048,-1.173687,-.2360362,-3.741454,4.088507,-.07528205,.6645237,.07718265,4.65122,.5586318,-1.213757,-.2589561,.7132551,-.4259327,-.1980821,.3627815,.0466656,5.807984,.5847377,-1.108794,-.225987,1.574179,-.3753731,-.5984743,1.659414,-.01681021,.6785219,.8647325,-1.060896,-.0134669,-.7529656,1.711319,-.9792435,.2022433,.3826487,5.725157,.5290714,-1.085145,-.2840715,2.088029,-4.935097,-9.056542,1.976149,-.03912485,-.8636064,.7452125,-1.077983,-.1416633,1.100848,10.15875,-2.943712,.5255135,.2164224,2.941143,.6699937,-1.223293,-.2867444,-1.624136,1.668299,-.09537589,.5015947,.1130741,4.244812,.5082152,-1.325342,-.4280991,.470549,.06926592,-.4572587,.5344144,-.02554192,3.093939,.6639401,-1.113581,-.1192133,.4011536,.7011889,.2052842,.9880724,.01807533,4.69016,.857624,-1.016063,-.1038138,-.2280391,.7898918,-11.27333,.2074545,.5388182,1.364263,.4660455,-1.099582,-.2228607,1.332648,5.135188,1.653152,1.41702,-.1087532,1.809275,.8080874,-1.064357,-.1520775,.8207368,-.001323565,-5.009523,.3946298,.4337902,2.593198,.6719172,-1.278702,-.3512866,-.4511055,.389576,-.2429672,.4270577,.1135348,3.71913,.4998867,-1.580069,-.7095475,-.3198904,1.715748,-1.185915,.4523161,-.01026159,.7927188,.553835,-.9474023,.1173703,.4881381,-2.618684,3.251661,1.213931,-.01736274,8.000768,1.025998,-1.129091,-.3287694,-.3524077,3.352892,-14.16073,-.8485617,.6560766,-2.820937,.3111303,-1.030884,-.1137581,1.109855,8.082276,1.519214,2.112433,-.1592299,3.675905,.8703367,-1.075192,-.1627166,.351491,1.168164,-4.255822,-.6015348,.6265776,2.884818,.6548384,-1.316017,-.3889652,-.5030854,.4488704,-.31868,.4570763,.08909201,3.659274,.5011746,-1.731876,-.8493806,.1194871,2.002781,-2.006547,.4872233,-.02854606,.2662137,.4611629,-.927368,.1380954,-.3302179,-3.553265,4.633345,.9696729,.08799775,8.291129,1.094451,-1.099377,-.3325392,.2501063,2.613712,-13.28142,-.5579527,.4992081,-3.504402,.3022924,-1.04842,-.1227773,.5845373,11.05869,.03813151,1.330409,.01978131,3.95943,.8396439,-1.063233,-.1560639,.2840033,.8751565,-3.41182,-.1436564,.584658,2.899292,.6799095,-1.376715,-.4541567,-1.445491,1.569898,-.1390627,.555827,.04109877,3.349451,.5516123,-1.953391,-1.035869,1.690563,-.196469,-.7787096,.5799605,.02945626,.04217906,.2451373,-1.012422,.07136451,-1.862534,-.7228653,.1947997,.2091805,.06399233,7.928994,1.290733,-.9706708,-.288095,1.107797,-2.731734,-8.445995,.4296774,.5117648,-3.824277,.1761207,-1.110611,-.1789409,.2108488,20.7143,-1.763174,.09554695,-.02943103,3.422079,.8815496,-1.048334,-.1614087,.2475184,.02146938,-2.983901,.2538224,.560137,2.461925,.6777394,-1.393719,-.5002724,-2.40894,2.680983,-.1362825,.7395067,-3300343e-12,3.260889,.8132057,-2.128663,-1.151182,2.923026,-1.931838,-.442617,.2309983,-.00548589,.3279529,-.2229467,-1.618022,-.376649,-3.163544,1.611608,-.3967476,.393368,.3006742,6.835177,1.613765,-.5669064,-.1481749,2.071817,-8.157422,-5.988088,.2387202,.1447191,-4.296385,.05011258,-1.241724,-.2519348,-.1908609,29.52235,-3.33366,-.01837651,.1022249,2.92932,.8867262,-1.02167,-.1667327,.1789771,-.002178108,-2.641572,-.05641484,.5303758,2.138196,.678035,-1.669332,-.7588708,-2.993557,3.17876,-.08066442,.6544672,-808988e-11,2.628924,.9001272,-1.755806,-.8735348,3.258881,-2.504785,-.3300791,.1180565,-.009315982,1.785154,-.3205824,-3.720277,-1.73335,-3.332272,1.515869,.1734218,.8011956,.199544,3.817666,1.638502,.4724641,.3209828,2.051443,-5.105574,-6.509139,-.4232041,.2598931,-2.151756,-.00349391,-1.5256,-.4897606,-.09891121,23.46818,-2.278152,.1681219,-.04469389,1.051,.9294666,-.9908649,-.2008182,.1605143,-.002463113,-2.477349,-.1218647,.4750121,1.460813,.6661364,-2.122119,-1.125475,-3.066599,3.145078,-.05411593,.5133628,-7823408e-12,2.268448,.9001416,-1.528158,-.9370249,2.567559,-1.591439,-.363446,.1763256,.001119624,1.811848,-.2637929,-6.524387,-2.673507,-2.940472,-.6025609,.7852067,1.073499,-.03540435,3.517416,1.490466,.8886026,-.09681828,1.430554,4.993717,-6.071355,-.6053986,.5092997,-1.27301,.07491329,-1.481997,-.5897282,.2659264,1.267239,-.5741291,.05983011,-.2217312,-.3016452,.926083,-1.010943,-.2075134,.05066749,14.70708,-3.780501,.07253223,.4045458,1.320164,.6559925,-1.129907,-.1884011,-8.04767,9.035776,-.05539419,.8823349,.03197135,4.839388,.5042822,-1.133821,-.1510781,3.362822,-2.453381,-.1463925,.4728708,.0595814,7.6363,.4805162,-1.176518,-.3549902,1.729044,-.2160966,-.5075865,1.675584,-.08906902,-5.386842,.5452218,-1.043563,-.07520975,.8750644,2.510518,.007584882,.936125,.07889083,6.066644,.5813108,-1.081304,-.2222253,2.517638,-4.45382,-8.663691,.8662558,-.04802657,-.8965449,.4886656,-1.083774,-.1375469,1.685818,5.63112,-3.100752,.4045941,.02346895,3.390321,.5008309,-1.143158,-.2058334,-9.660198,10.62394,-.04434119,.8607615,.03177325,4.416481,.5918162,-1.146773,-.1727385,4.626048,-4.684602,-.08307137,.1619616,.1484866,7.572868,.2681126,-1.151324,-.3099303,.4125596,2.340752,-.4214444,1.987375,-.191341,-3.845978,1.337311,-1.034258,-.007778759,.7050094,-.8036369,.313857,.2469452,.355997,7.485917,.04790329,-1.096568,-.2673169,2.575654,-.8057121,-8.884928,1.41617,-.2091315,-1.543494,1.065445,-1.083304,-.1528265,1.697727,2.503702,-2.885296,-.12985,.154887,2.479652,.5066496,-1.165736,-.2329945,-5.967964,6.705959,-.05931355,.7485638,.03913878,4.221591,.6183926,-1.212422,-.254591,2.418626,-2.266104,-.1102014,.01363887,.1055411,5.648062,.4557412,-1.070436,-.2163341,.7098718,.7843075,-.432393,2.109823,-.095897,-.1985193,1.060428,-1.104879,-.03013622,.02976276,1.069707,.141,-.488002,.4452288,6.41859,.3195986,-1.048969,-.2655317,2.689426,-3.941038,-9.506461,1.837119,-.1892124,-1.562146,.9043414,-1.106145,-.1601642,1.544544,7.388492,-2.9246,-.4328453,.1763161,2.523111,.5851902,-1.203666,-.2776587,-2.084286,2.45084,-.08746613,.5258507,.07983316,3.860055,.5486167,-1.340448,-.423059,.3462849,.4707607,-.2512626,.1530746,.02724218,3.035216,.5876133,-1.014554,-.116879,.9477794,-1.061218,-.419673,2.058832,-.05989624,3.058168,.9763861,-1.137388,-.0985403,-.2984893,3.64782,-.6585571,-1.47918,.6102932,3.265914,.3480333,-1.021816,-.2344957,2.463671,-7.240685,-8.862697,2.514058,-.2122768,-.03313968,.9028136,-1.126581,-.1874347,1.454154,10.34398,-3.237393,-.8654927,.2457248,1.845769,.6002482,-1.263727,-.3439354,-.1786388,.3980166,-.3349517,.3825166,.1029225,3.331096,.4998955,-1.53001,-.6879698,.2380415,1.608216,-1.682679,.354636,-.00391522,.4517655,.5128605,-.9685659,.09480403,.06076844,-3.217561,4.568074,1.069299,.02083638,7.301088,1.072165,-1.113925,-.3112382,.3954133,5.105907,-14.56866,-.4917378,.5289909,-2.678374,.3014709,-1.046864,-.1215754,1.778308,4.661489,.2565583,1.35368,-.1175767,3.415972,.8457746,-1.10448,-.1940913,1.343668,-.001759206,-5.009204,-.4186951,.312571,1.628183,.6720408,-1.286902,-.3781238,-.08977253,.3545393,-.4866515,.3843664,.08281675,3.122231,.5046991,-1.712597,-.8549112,.4809286,1.515398,-2.212211,.2539029,.02335997,-.06089466,.4268444,-.8807283,.1646097,-.4437898,-3.188247,5.984417,1.334779,-.04026975,7.546431,1.175751,-1.147253,-.3538199,.6101836,4.43778,-15.59813,-1.103222,.6242039,-3.091472,.217429,-1.03823,-.1213475,1.547505,5.893176,1.368738,1.663127,-.137713,3.185279,.8736453,-1.101026,-.1874907,1.272667,3.596524,-5.007243,-.6352483,.3048985,1.931613,.6788844,-1.342753,-.4384971,-1.213491,1.621399,-.1551441,.5614218,.02591739,2.958967,.5782132,-1.937684,-1.066019,1.913336,-.7347719,-.5916167,.158759,.1092568,-.6275002,.1599071,-.9302391,.1486187,-1.603835,.1783713,1.100461,1.174181,-.1602361,7.868331,1.468971,-1.053631,-.372705,1.114117,-.9603286,-10.62469,-1.16214,.7952797,-4.478765,-.04440862,-1.083629,-.1261405,1.229344,11.27825,.131901,1.624729,-.2825898,3.661082,1.036911,-1.09395,-.2067455,1.258035,7.548645,-4.598387,-.8944932,.3292634,1.311304,.6291871,-1.385867,-.5068139,-1.48649,1.969049,-.1698025,.6629167,-5289365e-12,2.760315,.8644368,-2.107367,-1.175639,2.313241,-1.001653,-.4843139,.1124485,3901494e-11,-.3502469,-.320478,-1.475244,-.2833055,-2.085824,1.192563,-.76452,.8380081,.220358,7.157885,1.753702,-.6644372,-.2549735,1.600273,-8.589034,-6.144718,-.7599731,.289837,-5.770923,-.09656242,-1.211687,-.1653494,.83934,27.92988,-3.395461,.9933752,-.03976877,3.776659,.9546526,-1.063757,-.2037563,1.117207,-.001252806,-3.33233,-.6971409,.3388719,1.311398,.6635171,-1.678889,-.7992295,-2.421687,2.871029,-.07662842,.6046208,-7598099e-12,2.002314,.9001307,-1.692144,-.880425,3.060895,-2.000009,-.3183563,.08385862,-.006326713,1.206639,-.3369967,-3.676795,-1.719207,-2.534697,1.005285,.1550407,1.07291,.1318094,3.717018,1.689191,.5424542,.3263528,1.551055,-3.841058,-6.598996,-1.201779,.3530669,-2.542945,-.06482523,-1.553849,-.457686,.9324676,19.50982,-2.344516,1.12102,-.1221537,.7285496,.9582816,-1.02065,-.2215797,1.009774,-.002056855,-2.740338,-.8122355,.3328967,.8982766,.6594676,-2.24736,-1.221267,-3.072346,3.385139,-.04387559,.5084887,-7418833e-12,1.750107,.9001401,-1.248499,-.8442718,3.062611,-2.020314,-.2815341,.05254745,.003345008,1.433225,-.2835911,-7.004119,-2.927978,-2.649852,.7971894,.5466893,1.442667,-.06063912,2.806194,1.547429,1.434882,.09114639,1.170089,.03512808,-5.861915,-1.411843,.5400486,-.7746522,.02386984,-1.559053,-.5502302,1.200396,13.47741,-2.344397,.8868907,-.3292661,-1.362105,.9217826,-1.044436,-.2360719,.7054471,-.002904518,-2.092829,-.5119668,.4174861,.9687435,.6588427]),new Float64Array([-1.372629,-.4905585,-41.00789,41.22169,-.00738936,.4839359,.006474757,3.471755,.5092936,-1.523025,-.6497084,6.249857,-5.662543,-.01908402,.551281,-2181049e-11,2.507663,.4339598,-1.035567,-.0747874,.922103,-2.140047,-.02374146,.3795517,-.01769134,7.479831,.7729303,-1.271086,-.558819,.6908023,2.096832,-.2453967,1.410648,.04475036,-4.719115,.5741186,-.9712598,-.07033926,.9167274,-.9502097,.3004684,.4547054,-.05929017,5.266196,.7204135,-1.087457,-.1888896,.8156686,.3101712,-2.155419,1.422205,.09692261,3.122404,.499943,-1.42528,-.5413508,-34.54883,34.81142,-.008686975,.4914268,-2479243e-12,3.239879,.6094201,-1.688557,-.8070865,7.018459,-6.244574,-.02149341,.3993971,.01252502,1.630662,.109786,-.8664152,.07869125,-.5236535,-1.21896,-.02059093,.6684898,-.05584112,8.602299,1.410496,-1.319763,-.5985323,1.253918,1.914706,-.3216739,.9011213,.1324845,-5.252749,.06231252,-.9706008,-.05914059,.569315,-1.175362,.5221644,.7518213,-.08247655,5.875635,.9850863,-1.08533,-.1956105,.8019605,.5338101,-3.423464,1.110444,.1507923,2.864942,.4999481,-1.431967,-.5478935,-32.86288,33.05288,-.008380797,.477205,-3044274e-12,3.289973,.5976303,-1.801361,-.9315889,5.391756,-4.588592,-.02040076,.4144684,.01814534,1.051795,.1145651,-.7905357,.1451332,-.1605661,-1.592174,.0004561348,.3380323,-.07770275,8.775384,1.489512,-1.308575,-.5539232,.9184133,2.011479,-.3842472,1.432274,.1637153,-4.408856,.05272957,-.9829872,-.08183048,.4464556,-1.442716,1.029641,-.06991617,.008702356,5.706417,.9116452,-1.08713,-.2038013,.7260801,.9164376,-5.006183,1.511271,.1257134,2.715439,.6201652,-1.448662,-.5799075,-28.33268,28.58023,-.009134061,.4404783,-2709026e-12,3.029357,.5540071,-2.061772,-1.14519,7.918478,-7.212525,-.0202076,.2962715,.0468967,.8517209,.2334587,-.6413755,.1780425,-2.412919,1.064484,-.01949986,.6769741,-.175276,7.262714,1.325869,-1.304871,-.3975581,1.219002,.7285178,-.2710105,.7779727,.3247139,-.8818168,.1839517,-1.001104,-.1994801,.3676742,-1.409737,.2901555,.250694,.002468899,3.398923,.8584645,-1.111552,-.2487204,.7410842,1.703749,-5.007855,1.057763,.1354511,2.088715,.6600013,-1.547227,-.6679466,-18.61465,18.84045,-.0124221,.4157339,-2432805e-12,2.812423,.5446957,-2.04389,-1.149081,2.304118,-1.715757,-.02433628,.2816836,.07185458,1.06486,.2706789,-.904072,-.08274472,-.2555676,-.6326215,-.0277088,.6676024,-.2513532,5.903839,1.241452,-1.000013,-.1010774,.3699166,.8774526,-.3042007,.6951053,.4361813,.6793421,.2573892,-1.171332,-.3768188,.3701377,-1.470757,.5525942,.02991456,.01581823,2.365233,.8214514,-1.068667,-.232633,.6725059,2.243733,-4.61437,1.033677,.1376291,2.013334,.6865304,-1.592991,-.7246948,-25.98204,26.2196,-.008365176,.4207571,-2742772e-12,2.623735,.587319,-2.271349,-1.280884,6.308739,-5.75835,-.01977049,.3671835,.06698038,1.150597,.1759218,-.636862,-.007436052,-2.230026,1.640997,-.01548497,.3145331,-.2492644,5.083843,1.260215,-1.177925,-.09628114,.3051152,-.03749544,-.2713209,1.164226,.4559969,2.175429,.2874284,-1.0785,-.3801779,.4788906,-.4795969,.5977621,-.4488535,.03386874,1.538143,.8062054,-1.108028,-.2596892,.5162202,1.557081,-4.265039,1.182535,.1563762,2.095084,.6883383,-1.668427,-.7908511,-27.7969,27.99746,-.007186935,.3757766,-3326858e-12,2.563421,.5439687,-2.156175,-1.220004,3.585732,-3.235988,-.01086239,.1846143,.1046017,1.234427,.2842191,-1.117051,-.4101627,-.846373,.7671472,-.02226609,.8574943,-.3434124,4.475715,1.154824,-.744484,.2312078,-.5393724,.1574213,-.1763914,.2751692,.55642,2.217672,.3483932,-1.273036,-.5275562,.4902512,-.04498436,.4339366,.2386682,.02380879,1.413444,.7855923,-1.084192,-.2936753,.4719432,1.384436,-3.257789,.6119543,.1681884,1.650441,.6936631,-1.84849,-.951267,-30.05251,30.24315,-.005635304,.344778,-2782999e-12,2.309422,.5643559,-2.300008,-1.252335,-1.218876,1.49373,-.0061071,.0797486,.1023449,1.505934,.2360948,-1.483705,-.8547575,-.7797146,.6447971,-.02678052,1.091263,-.3344889,3.830416,1.189425,-.5348005,.3982733,-.4071573,.3265569,-.08658789,-.2370892,.5369097,1.478279,.3143303,-1.320401,-.6043247,.3019196,-.07732911,.4768381,.6745764,.03694098,1.158234,.8169056,-1.10104,-.3420019,.3775661,1.769338,-2.990515,.1649529,.1970125,1.453355,.6759757,-2.251946,-1.229349,-32.71808,32.83114,-.004252027,.3372289,-3001937e-12,2.154046,.5842674,-1.867834,-.9531252,-12.29365,12.69149,-.006844772,.1185107,.07539587,1.846381,.1899412,-3.398629,-2.180862,2.335213,-3.382823,-.008613985,.8431602,-.2393567,3.11246,1.218556,.5708381,.940603,-.6890113,2.746233,-.05772068,.1096005,.3491978,.7281453,.3212049,-1.705909,-.8517224,.113116,-2.141434,.4274043,.33976,.178649,.9026101,.78828,-1.012865,-.3495551,.3369038,3.724205,-3.089586,.1266964,.146179,1.170199,.6931052,-2.890318,-1.665573,-34.93756,35.00369,-.002984251,.2622419,-425936e-11,1.947681,.6905752,-1.956022,-1.0629,-19.19714,19.75164,-.008865396,.216554,.05475637,1.761134,.003164249,-5.612198,-3.101371,4.098034,-6.144001,.009944958,.2905472,-.170711,3.199107,1.33766,.8353756,.4855943,-1.243589,5.147385,-.07013963,.938041,.2335714,.1727744,.2802696,-1.524329,-.7388547,.3259025,-4.050634,.4058549,-.2591384,.1898299,.3556071,.7884126,-1.070371,-.4207858,.1739862,5.29341,-3.136757,.2323856,.1673706,1.007227,.6844287,-1.34172,-.4834889,-46.33447,46.82148,-.006137296,.4599216,.007047323,2.895798,.4999398,-1.529104,-.6498631,15.34103,-14.50675,-.01531439,.3280082,.01682926,1.901587,.5013227,-1.014776,-.1454495,-4.071085,2.954982,-.02630348,.5681531,-.03016505,6.773854,.5003504,-1.172413,-.402632,2.960428,.202071,-.2004947,.9375572,.05998168,-4.945934,.4502898,-.9898161,-.05772814,.4470024,-.5786656,.1158168,.346804,-.0504336,6.867947,.8012363,-1.085111,-.1882675,1.223748,.3565495,-3.688357,.5653723,.06727646,2.69013,.49994,-1.389119,-.529025,-40.55774,41.05972,-.007062577,.456006,-1736334e-12,2.775512,.6671455,-1.584641,-.7200619,12.48067,-11.56028,-.01659568,.3050029,.01099895,1.438927,-.02138015,-.9826068,-.08887254,-2.960031,1.808816,-.02478159,.6035733,-.04868441,7.347705,1.584739,-1.150423,-.4073793,2.412991,.487084,-.2337902,.8295114,.1129914,-5.150045,-.09016643,-1.016933,-.06311501,.5218937,-.571643,.1250993,.3601524,-.05497586,7.060139,1.018333,-1.073151,-.1845444,1.155394,.3004486,-3.431711,.4657031,.09401223,2.68862,.4999544,-1.391257,-.5365815,-42.55881,42.99132,-.005838466,.4229134,-2760038e-12,2.775531,.6234597,-1.780062,-.922888,13.76172,-12.60946,-.01507526,.3117435,.02205045,.6093731,.03463446,-.7388169,.127567,-3.999528,2.223993,-.01856853,.543931,-.08834054,8.037139,1.645951,-1.322387,-.5320143,2.659359,1.086712,-.2129712,.8704649,.1800315,-4.967241,-.138372,-.9378288,-.01599895,.3607555,-1.980561,.3791456,.1212268,-.02845992,6.825542,1.059139,-1.100832,-.2172313,1.211561,2.002721,-5.010011,.5717583,.06777702,2.160006,.5676392,-1.409373,-.5708751,-30.34974,30.79809,-.007280715,.3723304,-2436279e-12,2.577348,.5913377,-1.954312,-1.11651,5.399148,-4.299553,-.01724739,.3742824,.04187077,.1044883,.1232727,-.6772215,.2001396,-.3670523,-1.014628,-.003497152,.4099858,-.1584633,7.7504,1.514559,-1.2916,-.4977437,.9641914,1.56242,-.3227782,.9055427,.3046444,-3.385619,.009546291,-.9750857,-.0877056,.9054256,-1.429236,.8974777,-.1217961,-.05194608,4.909409,.9589153,-1.088007,-.1959301,.9745799,1.260761,-5.008864,.7271248,.1096661,2.717295,.6340731,-1.45605,-.6223072,-22.28088,22.69604,-.009340812,.4118308,-2418083e-12,2.442117,.5589638,-2.176449,-1.302416,2.222836,-1.22273,-.01728051,.1323513,.07027731,.04835745,.2093351,-.5789641,.2215407,.2142291,-1.201725,-.01185728,.8122982,-.238042,6.706841,1.404146,-1.307463,-.4515174,.6447827,1.223841,-.2902391,.4986588,.4073652,-1.706696,.1060885,-.9698678,-.1307094,.9389347,-1.522852,.7768797,-.1368595,-.03857426,3.676935,.8980966,-1.104349,-.2380323,1.047043,1.865421,-5.011664,.7014954,.09622701,1.89136,.6687354,-1.502249,-.6724523,-28.88092,29.3036,-.006685766,.3685464,-2469442e-12,2.310797,.5566754,-2.217125,-1.364924,4.048243,-3.111333,-.01317747,.1921948,.08627702,.001981769,.2213689,-.6215757,.1687995,-.5949131,-.1551293,.0003356129,.6897657,-.2855053,6.271042,1.363084,-1.216317,-.3489429,.7566226,.5409809,-.2830843,.6191825,.4755163,-.9131387,.1383909,-1.030437,-.2034064,.8335995,-1.050947,.8689093,-.367231,-.04056183,3.111269,.8856842,-1.078984,-.2070549,.9683145,1.497022,-5.007653,.7702541,.1285822,2.225188,.6587911,-1.559291,-.7374039,-35.96311,36.3447,-.004667132,.3277964,-2487945e-12,2.215652,.5764681,-2.356929,-1.444755,6.244526,-5.540162,-.00879451,.17921,.09578517,.3737676,.1922194,-.6589752,-.0292691,-1.831779,1.869962,-.002030095,.7552089,-.3168157,4.632196,1.294054,-1.161046,-.1472506,.6494138,-.8327174,-.2320724,.3391212,.5269637,.9376341,.2458573,-1.034427,-.3062504,.8975634,.3203531,.8565142,-.1250162,-.04094017,1.861304,.8223468,-1.109954,-.2740277,1.063811,.7077398,-4.695734,.5621696,.1248956,1.297723,.678972,-1.788293,-.9368751,-43.8298,44.24963,-.00365253,.3094331,-2810503e-12,1.904402,.5861599,-2.268206,-1.312676,2.863082,-2.373727,-.00514498,.1711072,.09316041,.9309598,.1791683,-1.376966,-.7418582,-1.349589,1.563419,-.003124219,.6967139,-.3061887,3.602731,1.255669,-.601754,.2815928,.5424052,-.688545,-.1620001,.2980046,.4995571,.7371203,.2812466,-1.278853,-.5245326,.787052,.3125067,.7748105,-.07788581,.003490956,1.283748,.813019,-1.05093,-.2786331,1.056344,1.053002,-4.047789,.4432174,.1169077,.9532621,.6806764,-2.084927,-1.203954,-48.81638,49.2016,-.002896045,.2882977,-3073517e-12,1.702211,.637418,-2.328567,-1.238023,-1.891019,2.45152,-.005847581,.2084702,.0784813,1.211048,.08095008,-2.634632,-1.78946,-.1370558,-.3326435,.002783737,.5239451,-.2548881,2.896327,1.324116,.06882616,.5997821,.1535398,1.375209,-.1267285,.4239743,.4013122,.1794675,.2395382,-1.430918,-.6439041,.832598,-1.705612,.7236426,-.05567593,.06408718,.6836524,.8388887,-1.037956,-.3215402,.9457349,3.178114,-4.152156,.2230992,.1156198,.7606223,.6656923,-2.967314,-1.728778,-37.30988,37.55578,-.002588835,.2927966,-3935038e-12,1.592161,.6868694,-2.123311,-1.175148,-13.14988,13.86882,-.007828537,.1852026,.05481038,1.294309,.02428177,-5.443597,-3.156344,2.110838,-3.421556,.0118189,.1196951,-.1742902,2.404353,1.272805,1.029898,.5912521,-.3983531,3.286069,-.09252065,1.331381,.2560642,.8001754,.3624178,-1.547574,-.7881604,1.020902,-2.897069,.521347,-.9242315,.1185594,-1.150721,.7317211,-.9621043,-.1991406,.6531287,3.925839,-3.596904,.6317332,.1531334,1.457846,.6966285])],Lt=[new Float64Array([1.962684,1.159831,4.450588,5.079633,4.437388,4.324573,1.946487,1.287515,3.703696,8.782833,3.440437,5.160333,1.88217,1.335878,2.648641,13.58368,3.105473,5.907387,1.738159,1.624289,-.008786695,21.18253,2.770255,7.055672,1.571896,2.301786,-4.028545,29.66806,1.630876,8.711031,1.475048,2.679086,-6.311315,33.77896,2.140975,9.385283,1.326174,3.378759,-9.831444,39.42061,2.852702,10.82542,1.153344,3.967771,-12.65181,41.95016,7.468239,12.2135,.9746081,4.051626,-12.98454,37.54964,17.49232,14.20619,.8448016,3.181809,-8.757338,21.97962,35.24033,16.39549,2.029623,1.364434,4.201529,5.415099,9.825839,10.63328,2.023126,1.494728,3.420413,9.072178,9.205157,11.86639,1.956307,1.648665,2.039712,14.30239,9.039526,13.30453,1.825053,1.985022,-.8036307,22.02493,9.415361,15.17659,1.650367,2.593201,-4.469328,29.69817,9.410977,17.4485,1.555202,2.962925,-6.60817,33.29887,10.64559,18.50816,1.412478,3.439403,-9.196616,36.85077,13.45341,20.03128,1.25299,3.820805,-11.15338,37.21593,20.14916,21.8232,1.091952,3.663027,-10.3133,29.78985,32.96835,23.7545,.9501691,2.664579,-5.545167,12.81159,51.54768,25.74284]),new Float64Array([1.59033,1.355401,1.151412,13.59116,5.857714,8.090833,1.55254,1.51004,.1276413,16.04643,5.912162,8.350009,1.470871,1.880464,-1.865398,20.30808,5.471461,9.109834,1.356563,2.373866,-4.653245,25.70922,5.686009,10.0948,1.244232,2.851519,-7.130942,29.93449,6.38212,11.14578,1.173693,3.120604,-8.491886,31.87393,7.290615,11.80066,1.091845,3.368888,-9.722083,32.68508,10.32424,12.36508,.9858985,3.500541,-10.26328,30.92956,16.10881,13.31222,.8864993,3.172888,-8.68755,23.62161,26.21851,14.74967,.7946973,2.189355,-4.207953,9.399091,40.62849,16.81753,1.711696,1.657311,.9328021,13.1788,15.06751,18.63556,1.666968,1.849993,-.2088601,15.86653,14.8688,19.40719,1.584846,2.170022,-2.019597,19.70826,14.90684,20.45055,1.469412,2.524017,-4.197267,23.65249,16.64588,21.34477,1.369714,2.843548,-6.059031,26.34993,18.81361,22.32186,1.310477,2.984444,-6.831686,26.8234,21.23267,22.59755,1.222552,3.176523,-7.731496,26.7176,24.84358,23.36863,1.115781,3.130635,-7.581744,23.36531,31.71048,24.13859,1.013181,2.699342,-5.602709,15.00158,42.17613,25.15957,.8976323,1.726948,-1.29612,1.183675,55.03215,26.43066]),new Float64Array([.9926518,1.999494,-4.136109,18.5627,13.51028,13.90238,.9634366,2.119694,-4.614523,19.19701,13.76644,14.18731,.9446537,2.17161,-4.915556,19.1824,15.37135,14.0053,.9073074,2.330536,-5.577596,19.61615,16.88365,14.46955,.8739124,2.388682,-5.842995,19.23265,18.87735,14.85698,.8563688,2.391534,-5.769133,18.28709,20.97209,14.69587,.8270533,2.34279,-5.558071,16.84993,23.56498,15.05975,.7908339,2.190341,-4.852571,13.74862,28.06846,15.48444,.7403619,1.783998,-2.983854,7.622563,35.0761,16.15805,.6840111,1.154457,-.239383,-.7896893,42.82765,17.79469,1.1683,1.860993,-2.129074,12.51952,30.32499,29.38716,1.150338,1.918813,-2.413527,12.74862,30.87134,29.51432,1.114719,1.964689,-2.625423,12.47837,32.37949,29.43596,1.077948,2.006292,-2.846934,11.90195,34.59293,29.37492,1.035143,1.986681,-2.752584,10.60972,37.22185,29.18594,1.015992,1.992054,-2.812626,10.01416,38.473,29.24624,.9756887,1.939897,-2.533281,8.319176,40.83907,29.25586,.9264164,1.716454,-1.597044,4.739725,45.07683,28.78915,.8595191,1.346034,-.02801895,-.6582906,50.17523,28.52953,.7754116,.7709245,2.200201,-7.487661,54.36622,28.93432])],Rt=Math.PI/2;function zt(e,t,n){let r=Math.min(10,Math.max(1,e)),i=Math.min(1,Math.max(0,t)),a=Math.max(0,n);return[0,1,2].map(e=>({params:Vt(It[e],r,i,a),radiance:Ht(Lt[e],r,i,a)}))}function Bt(e,t,n,r){let i=e.params,a=Math.exp(i[4]*r),o=n*n,s=(1+o)/(1+i[8]*i[8]-2*i[8]*n)**1.5,c=Math.sqrt(t),l=(1+i[0]*Math.exp(i[1]/(t+.01)))*(i[2]+i[3]*a+i[5]*o+i[6]*s+i[7]*c);return Math.max(0,l*e.radiance)}function W(e,t,n,r,i){let a=1-i;return a**5*e[t+r]+5*a**4*i*e[t+n+r]+10*a**3*i**2*e[t+n*2+r]+10*a**2*i**3*e[t+n*3+r]+5*a*i**4*e[t+n*4+r]+i**5*e[t+n*5+r]}function Vt(e,t,n,r){let i=Math.floor(t),a=t-i,o=(r/Rt)**(1/3),s=new Float64Array(9),c=(e,t)=>54*(10*e+t);for(let t=0;t<9;t+=1){let r=(1-n)*(1-a)*W(e,c(0,i-1),9,t,o)+n*(1-a)*W(e,c(1,i-1),9,t,o);i<10&&(r+=(1-n)*a*W(e,c(0,i),9,t,o)+n*a*W(e,c(1,i),9,t,o)),s[t]=r}return s}function Ht(e,t,n,r){let i=Math.floor(t),a=t-i,o=(r/Rt)**(1/3),s=(e,t)=>6*(10*e+t),c=(1-n)*(1-a)*W(e,s(0,i-1),1,0,o)+n*(1-a)*W(e,s(1,i-1),1,0,o);return i<10&&(c+=(1-n)*a*W(e,s(0,i),1,0,o)+n*a*W(e,s(1,i),1,0,o)),c}var Ut=[5804542996261093e-21,13562911419845635e-21,30265902468824876e-21],Wt=[183999185144339.78,277980239196605.28,407904795438610.94],Gt=1e3,Kt=Math.PI/1.95,qt=1.5,G=e=>Math.min(1,Math.max(0,e)),Jt=.15,Yt=.07;function Xt(e){let{betaM:t,betaR:n,sunE:r,tint:i,turbidity:a}=nn(e),o=new Uint16Array(4608*4),s=G(e.sunElevation),c=Math.max(.02,s),l=Math.sqrt(Math.max(0,1-c*c)),u=.8,d=u*u,f=G((1-c)**5),p=[0,3e-4,75e-5],m=e.model===`preetham`?null:zt(a,Jt,Math.asin(s)),h=0;for(let a=0;a<48;a+=1){let s=-.05+a/47*1.05,g=s,_=Math.sqrt(Math.max(1e-4,1-g*g)),v=Math.acos(Math.min(1,Math.max(0,g))),y=Math.min(1,Math.max(0,g)),b=Math.cos(v)+.15*(93.885-v*180/Math.PI)**-1.253,x=8400/Math.max(1,b),S=1250/Math.max(1,b);for(let a=0;a<96;a+=1){let v=a/95*Math.PI,b=_*Math.cos(v)*l+g*c,C=Math.min(1,Math.max(-1,b)),w=Math.acos(C),T=G(Math.max(0,s))**.55;for(let a=0;a<3;a+=1){let s;if(m)s=Bt(m[a],y,C,w)*Yt*e.exposure*i[a];else{let o=.0596831*(1+b*b),c=.0795775*(1-d)/(1-2*u*b+d)**1.5,l=Math.exp(-(n[a]*x+t[a]*S)),m=(n[a]*o+t[a]*c)/(n[a]+t[a]),h=Math.max(0,r*m*(1-l))**1.5;h*=1+(Math.max(0,r*m*l)**.5-1)*f;let g=((h+.1*l)*.04+p[a])*e.exposure*i[a];s=g/(1+g)}let c=e.skyHorizon[a]+(e.skyTop[a]-e.skyHorizon[a])*T,l=Math.max(G(e.pbrNight),G(e.cloudCover)*.85);o[h+a]=tn(s+(c-s)*l)}o[h+3]=Qt,h+=4}}return o}function Zt(e){let t=(e,t)=>Math.round(e*t);return[e.model??`hosek`,t(e.sunElevation,200),t(e.pbrNight,100),t(e.exposure,100),t(e.cloudCover,50),t(e.cloudDark,50),t(e.mood,50),t(e.skyTop[0],100),t(e.skyTop[1],100),t(e.skyTop[2],100),t(e.skyHorizon[0],100),t(e.skyHorizon[1],100),t(e.skyHorizon[2],100)].join(`,`)}var Qt=15360,$t=new Float32Array(1),en=new Uint32Array($t.buffer);function tn(e){$t[0]=e;let t=en[0],n=t>>16&32768,r=(t>>23&255)-127+15,i=t&8388607;return r<=0?n:r>=31?n|31743:n|r<<10|i>>13}function nn(e){let t=G(e.cloudCover),n=G(e.cloudDark),r=G(e.sunElevation),i=2.2+t*6+n*4,a=2+(1-r)*1.5,o=.005+t*.006,s=Ut.map(e=>e*a),c=.2*i*1e-17,l=Wt.map(e=>.434*c*e*o),u=Gt*Math.max(0,1-Math.exp(-((Kt-Math.acos(r))/qt))),d=Math.max(e.skyTop[0],e.skyTop[1],e.skyTop[2],.001);return{betaM:l,betaR:s,sunE:u,tint:e.skyTop.map(t=>1+(t/d-1)*G(e.mood)),turbidity:i}}var rn=[0,0,1,1];function an(e,t,n,r=0){let i=e.keyframes;if(i.length===0)return;let a=e.duration>0?t%e.duration:0,o=i.length-1;for(;o>0&&i[o].time>a;)--o;let s=i[o],c=i[Math.min(o+1,i.length-1)],l=c.time-s.time,u=l>1e-6?Math.min(Math.max((a-s.time)/l,0),1):0;n[r]=sn(s.uv[4]??0,c.uv[4]??0,u),n[r+1]=sn(s.uv[5]??0,c.uv[5]??0,u),n[r+2]=sn(s.uv[1]??1,c.uv[1]??1,u),n[r+3]=sn(s.uv[2]??1,c.uv[2]??1,u)}function on(e,t){return e===void 0||!Number.isInteger(e)||e<0||e>=t?0:(e+1)*256}function sn(e,t,n){return e+(t-e)*n}function cn(e,t,n,r){let i=t*r,a=i+n*r,o=i&-4,s=a+3&-4,c=new Uint8Array(s-o);return c.set(e.subarray(o,i),0),c.set(e.subarray(a,Math.min(e.byteLength,s)),a-o),{byteOffset:o,bytes:c}}var ln=112,un=class{picking=!1;placementEdits=!1;get count(){return this.cells.size}get pickingBytes(){let e=0;for(let t of this.cells.values())e+=t.indexData.byteLength+t.placements.length*ln;return e}cells=new Map;colorFormat;depthFormat;device;frameBindGroup;pipelines;resources;textures;constructor(e){this.device=e.device,this.resources=e.resources,this.pipelines=e.pipelines,this.textures=e.textures,this.frameBindGroup=e.frameBindGroup,this.colorFormat=e.colorFormat,this.depthFormat=e.depthFormat}all(){return this.cells.values()}breakPlacement(e){for(let t of this.cells.values()){let n=t.breakables.get(e);if(!n)continue;let r=t.index16?2:4;for(let e of n){let n=cn(t.indexData,e.indexOffset,e.indexCount,r);this.device.queue.writeBuffer(t.indexBuffer,n.byteOffset,n.bytes)}t.breakables.delete(e);let i=t.lights.filter(t=>t.owner!==e);return i.length!==t.lights.length&&(t.lights.length=0,t.lights.push(...i)),!0}return!1}has(e){return this.cells.has(e)}hidePlacement(e){let t=0;if(!this.placementEdits)return 0;for(let n of this.cells.values()){let r=n.placements.filter(t=>t.id===e);if(r.length===0)continue;let i=n.index16?2:4;for(let e of r){let t=cn(n.indexData,e.indexOffset,e.indexCount,i);this.device.queue.writeBuffer(n.indexBuffer,t.byteOffset,t.bytes)}n.placements=n.placements.filter(t=>t.id!==e),t+=1}return t}load(e,t){let n=this.cells.get(e);if(n)return n;let r=oe(t),i=this.resources.createBuffer(`cellVertex`,{label:`${e}:vb`,size:dn(r.vertexData.byteLength),usage:GPUBufferUsage.VERTEX|GPUBufferUsage.COPY_DST});this.device.queue.writeBuffer(i,0,pn(r.vertexData));let a=this.resources.createBuffer(`cellIndex`,{label:`${e}:ib`,size:dn(r.indexData.byteLength),usage:GPUBufferUsage.INDEX|GPUBufferUsage.COPY_DST});this.device.queue.writeBuffer(a,0,pn(r.indexData));let o=this.resources.createBuffer(`uniform`,{label:`${e}:cell`,size:32,usage:GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST}),s=((r.channelMask&I.SUN_VIS)===0?0:1)|((r.channelMask&I.EMISSIVE)===0?0:2);this.device.queue.writeBuffer(o,0,new Float32Array([...r.origin,s,0,0,1,1]));let c=this.device.createBindGroup({entries:[{binding:0,resource:{buffer:o}}],label:`${e}:cell`,layout:this.pipelines.cellLayout}),l=new Set;for(let e of r.objects)for(let t=e.groupStart;t<e.groupStart+e.groupCount;t+=1)l.add(t);let u=r.groups.filter((e,t)=>!l.has(t)),d=u.filter(e=>e.pipelineClass<=1),f=u.filter(e=>e.pipelineClass>=2),p=this.record(e,d,r.index16,i,a,c),m={blendBundle:f.length>0?this.record(`${e}:blend`,f,r.index16,i,a,c):null,bounds:[r.bounds[0]+r.origin[0],r.bounds[1]+r.origin[1],r.bounds[2]+r.origin[2],r.bounds[3]],breakables:fn(r.breakables),bundle:p,cellBindGroup:c,draws:u.length,index16:r.index16,indexBuffer:a,indexData:r.breakables.length>0||this.placementEdits?r.indexData:new Uint8Array,key:e,lights:r.lights.map(e=>({color:e.color,farClip:e.farClip,owner:e.owner,size:e.size,x:e.position[0]+r.origin[0],y:e.position[1]+r.origin[1],z:e.position[2]+r.origin[2]})),objects:r.objects.map(t=>{if(t.kind!==4&&t.kind!==5)return{bindGroup:c,groups:r.groups.slice(t.groupStart,t.groupStart+t.groupCount),kind:t.kind,params:t.params,uvAnimUniform:null};let n=this.resources.createBuffer(`uniform`,{label:`${e}:uvscroll:${t.params}`,size:32,usage:GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST});return this.device.queue.writeBuffer(n,0,new Float32Array([...r.origin,s,0,0,1,1])),{bindGroup:this.device.createBindGroup({entries:[{binding:0,resource:{buffer:n}}],label:`${e}:uvscroll:${t.params}`,layout:this.pipelines.cellLayout}),groups:r.groups.slice(t.groupStart,t.groupStart+t.groupCount),kind:t.kind,params:t.params,uvAnimUniform:n}}),particles:r.particles.map(e=>({effectName:e.effectName,x:e.position[0]+r.origin[0],y:e.position[1]+r.origin[1],z:e.position[2]+r.origin[2]})),placements:this.picking?hn(r):[],roadsignQuads:r.roadsignQuads,triangles:u.reduce((e,t)=>e+t.indexCount/3,0),uniform:o,vertexBuffer:i,visible:!0};return this.cells.set(e,m),m}pick(e,t){let n=null;for(let r of this.cells.values())if(r.visible)for(let i of r.placements){let r=mn(e,t,i.bounds);if(r===null||n!==null&&r>=n.distance)continue;let a=i.bounds;n={distance:r,id:i.id,model:i.model,position:[(a[0]+a[3])/2,(a[1]+a[4])/2,(a[2]+a[5])/2],txd:i.txd}}return n}unload(e){let t=this.cells.get(e);if(t){this.cells.delete(e),this.resources.destroyBuffer(`cellVertex`,t.vertexBuffer),this.resources.destroyBuffer(`cellIndex`,t.indexBuffer),this.resources.destroyBuffer(`uniform`,t.uniform);for(let e of t.objects)e.uvAnimUniform&&this.resources.destroyBuffer(`uniform`,e.uvAnimUniform)}}record(e,t,n,r,i,a){let o=this.device.createRenderBundleEncoder({colorFormats:[this.colorFormat],depthStencilFormat:this.depthFormat,label:e,sampleCount:4});o.setBindGroup(0,this.frameBindGroup),o.setBindGroup(1,a),o.setVertexBuffer(0,r),o.setIndexBuffer(i,n?`uint16`:`uint32`);let s=[...t].sort((e,t)=>e.pipelineClass-t.pipelineClass);for(let e of s)o.setPipeline(this.pipelines.get(xt(e.pipelineClass,e.side))),o.setBindGroup(2,this.textures.get(e.textureArrayRef).bindGroup),o.drawIndexed(e.indexCount,1,e.indexOffset,0,0);return o.finish({label:e})}};function dn(e){return Math.ceil(e/4)*4}function fn(e){let t=new Map;for(let n of e){let e=t.get(n.keyHash)??[];e.push({indexCount:n.indexCount,indexOffset:n.indexOffset}),t.set(n.keyHash,e)}return t}function pn(e){if(e.byteLength%4==0)return e;let t=new Uint8Array(dn(e.byteLength));return t.set(e),t}function mn(e,t,n){let r=-1/0,i=1/0;for(let a=0;a<3;a+=1){let o=t[a],s=n[a],c=n[a+3];if(Math.abs(o)<1e-9){if(e[a]<s||e[a]>c)return null;continue}let l=(s-e[a])/o,u=(c-e[a])/o;if(r=Math.max(r,Math.min(l,u)),i=Math.min(i,Math.max(l,u)),r>i)return null}return i<0?null:Math.max(r,0)}function hn(e){return e.placements.map(t=>{let n=new Float64Array(6);for(let r=0;r<3;r+=1)n[r]=t.bounds[r]+e.origin[r],n[r+3]=t.bounds[r+3]+e.origin[r];return{bounds:n,id:t.id,indexCount:t.indexCount,indexOffset:t.indexOffset,model:e.names[t.nameRef]??``,txd:e.names[t.txdRef]??``}})}var K=4,gn=[255,0,255,255],_n=class{arrays=new Map;device;highlightMissing=!1;materialLayout;missingByRef=new Map;pending=new Map;resources;sampler;constructor(e,t,n){this.device=e,this.resources=t,this.materialLayout=n,this.sampler=e.createSampler({addressModeU:`repeat`,addressModeV:`repeat`,magFilter:`linear`,minFilter:`linear`,mipmapFilter:`linear`})}beginLoad(e,t){if(this.arrays.has(e)||this.pending.has(e))return;let n=ct(this.device,this.resources,t,`array-${e}`);this.pending.set(e,{bindGroup:this.materialBindGroup(e,n.texture),task:n})}drainUploads(e){if(this.pending.size===0)return 0;let t=performance.now();for(let[n,r]of this.pending)for(;;){if(r.task.step()){this.pending.delete(n);let{byteEstimate:e,layers:t,texture:i}=r.task,a={bindGroup:r.bindGroup,byteEstimate:e,layers:t,texture:i};this.arrays.set(n,a),this.highlightMissing&&this.paint(n,a,!0);break}if(performance.now()-t>=e)return performance.now()-t}return performance.now()-t}get(e){let t=this.arrays.get(e);if(!t)throw Error(`texture array ${e} not loaded (cells must load after their arrays)`);return t}has(e){return this.arrays.has(e)}load(e,t){let n=this.arrays.get(e);if(n)return n;let{byteEstimate:r,layers:i,texture:a}=lt(this.device,this.resources,t,`array-${e}`),o={bindGroup:this.materialBindGroup(e,a),byteEstimate:r,layers:i,texture:a};return this.arrays.set(e,o),this.highlightMissing&&this.paint(e,o,!0),o}setMissingHighlight(e){if(this.highlightMissing!==e){this.highlightMissing=e;for(let[t,n]of this.arrays)this.paint(t,n,e)}}setMissingLayers(e){this.missingByRef.clear();for(let t of e){let e=this.missingByRef.get(t.array);e?e.push(t):this.missingByRef.set(t.array,[t])}}unload(e){let t=this.pending.get(e);if(t){this.pending.delete(e),this.resources.destroyTexture(`texture`,t.task.texture,t.task.byteEstimate);return}let n=this.arrays.get(e);n&&(this.arrays.delete(e),this.resources.destroyTexture(`texture`,n.texture,n.byteEstimate))}materialBindGroup(e,t){return this.device.createBindGroup({entries:[{binding:0,resource:t.createView({dimension:`2d-array`})},{binding:1,resource:this.sampler}],label:`material-${e}`,layout:this.materialLayout})}paint(e,t,n){let r=this.missingByRef.get(e);if(!r)return;let i=new Uint8Array(K*K*4);for(let e of r){if(e.layer>=t.layers)continue;let r=n?gn:e.color;for(let e=0;e<K*K;e+=1)i.set(r,e*4);this.device.queue.writeTexture({origin:{x:0,y:0,z:e.layer},texture:t.texture},i,{bytesPerRow:K*4,rowsPerImage:K},{depthOrArrayLayers:1,height:K,width:K})}}},vn=`depth32float`,yn=2048,bn=256,xn=.0045,Sn=.9,Cn=.93,wn=1.25,q=8,Tn=.7,En=.3,J=8,Dn=64,On=9,kn=16,An=16,jn=16,Mn=64,Nn=3,Pn={primary:[1,1,1],quaternary:[1,1,1],secondary:[1,1,1],tertiary:[1,1,1]},Fn=80,In=8,Ln=new Float32Array([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1]),Rn=2,zn=64,Bn=12,Vn=2,Hn=class{cells;clutterEnabled=!0;debugNormals=!1;debugPrelitScale=1;debugUnlit=!1;dynamicCoronas=[];dynamicLights=[];environment={ambientColor:[.074,.084,.098],aoStrength:.6,bloomIntensity:.7,bloomThreshold:.7,cloudAlpha:.9,cloudBottomColor:[.45,.48,.55],cloudCover:.12,cloudDark:0,cloudScale:1,cloudTopColor:[.78,.8,.85],dn:0,emissiveBoost:1.6,fogCutDistance:2400,fogHeightK:1/180,fogHeightMin:.35,fogStartDistance:250,godrayStrength:1,hour:12,moonColor:[0,0,0],moonDir:[-.3,.8,-.25],moonPhase:.5,reflectionStrength:1,skyExposure:.55,skyHorizon:[.42,.55,.72],skyModel:`hosek`,skyMood:.7,skyTop:[.12,.32,.65],stochastic:0,sunColor:[1,.96,.88],sunCoreColor:[1,.95,.68],sunCoronaColor:[1,.8,.4],sunDir:[.35,.85,.25],sunDirect:.9,sunElevation:1,sunIndirect:.75,sunSize:4,sunVisStrength:1,tonemap:1,waterAlpha:.72,waterColor:[.05,.14,.18],windStrength:1};particlesEnabled=!0;probeCenter=null;probeView=!1;renderScale=1;skyColor={a:1,b:.71,g:.46,r:.24};textures;waterEnabled=!0;get adapterInfo(){return this.engineDevice.adapterInfo}get bootPhases(){return this.bootTotals}get device(){return this.engineDevice.device}get deviceReport(){return b(this.engineDevice,this.canvasElement)}get firstFrames(){return this.firstFrameTotals}bloomChain=null;bloomPrefilterScratch=new Float32Array(8);bloomPrefilterUniform;bootSpans=new M;bootTotals={byName:[],totalMs:0};canvasContext;canvasElement;cloudFieldBindGroup;cloudFieldTexture;cloudFieldView;clutterBreakables=new Map;clutterCells=new Map;clutterModels=new Map;clutterModelSeq=0;clutterSampler;coronaInstances;coronaQuad;coronaScratch=new Float32Array(yn*8);coronaTexture;debris=[];debugLines=new Map;depthView;dynamicParticles=null;engineDevice;firstFrameDetail=3;firstFrameSpans=new M;firstFrameTotals=[];frameBindGroup;frameBlendBundles=[];frameBlendCells=[];frameBundles=[];frameData=new Float32Array(104);frameTriangles=0;frameUniform;frustumPlanes=new Float32Array(24);identityUvAnim;invViewProj=w();lightPoolBuffer;lightPoolScratch=new Float32Array(zn*Bn);msaaView;nextDebugLineId=1;particles=null;ped=null;pedTextureBytes=0;pedTextures=[];pipelines;plateBackTexture;plateTexture;postBindGroup;postSampler;postUniform;probe;probeFrameData=new Float32Array(104);probeFrustum=new Float32Array(24);probeInvViewProj=w();probeTick=-1;probeViewBindGroup;probeViewProj=w();proj=w();resources;sceneColorView;sceneTargets=[];skidMarks=null;skyLutCurrentKey=``;skyLutTexture;startedMs=performance.now();statsValue={cellsTotal:0,cellsVisible:0,drawsRecorded:0,gpuPassMs:0,gpuPostMs:0,gpuProbeMs:0,residencyBytes:0,roadsignQuadsRecorded:0,submitMs:0,trianglesRecorded:0};targetKey=``;timers;uvAnimations=[];uvAnimScratch=new Float32Array(4);uvAnimTransforms=new Float32Array;vehicleModels=new Map;vehicleModelSeq=0;vehicleParts=new Map;view=w();viewProj=w();water=null;addSkidSegment(e){!this.skidMarks||!this.particlesEnabled||this.skidMarks.add(e,(performance.now()-this.startedMs)/1e3)}breakClutterInstance(e){let t=this.clutterBreakables.get(e);return t?(this.device.queue.writeBuffer(t.matrixBuffer,t.offset,Ln),this.clutterBreakables.delete(e),!0):!1}createClutterModel(e){let t=(e,t,n)=>{let r=Math.max(4,Math.ceil(t.byteLength/4)*4),i=this.resources.createBuffer(`cellVertex`,{label:`clutter-${e}`,size:r,usage:n|GPUBufferUsage.COPY_DST}),a=t;return t.byteLength!==r&&(a=new Uint8Array(r),a.set(t)),this.device.queue.writeBuffer(i,0,a),i},n=[t(`positions`,e.positions,GPUBufferUsage.VERTEX),t(`normals`,e.normals,GPUBufferUsage.VERTEX),t(`uvs`,e.uvs,GPUBufferUsage.VERTEX),t(`colors`,e.colors,GPUBufferUsage.VERTEX),t(`meta`,e.meta,GPUBufferUsage.VERTEX),t(`night`,e.night,GPUBufferUsage.VERTEX)],r=t(`indices`,e.indices,GPUBufferUsage.INDEX),{byteEstimate:i,texture:a}=this.createModelTexture(e.texture,`clutter-texture`),o=this.clutterModelSeq;return this.clutterModelSeq+=1,this.clutterModels.set(o,{buffers:n,cutout:e.cutout,indexBuffer:r,indexCount:e.indices.byteLength/2,texture:a,textureBytes:i}),o}createDebugLines(e,t,n={}){let r=this.nextDebugLineId;this.nextDebugLineId+=1;let i=this.resources.createBuffer(`cellVertex`,{label:`debug-line-${r}`,size:Math.max(4,Math.ceil(e.byteLength/4)*4),usage:GPUBufferUsage.VERTEX|GPUBufferUsage.COPY_DST});this.device.queue.writeBuffer(i,0,e);let a=this.resources.createBuffer(`uniform`,{label:`debug-line-${r}`,size:16,usage:GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST});return this.device.queue.writeBuffer(a,0,new Float32Array(t)),this.debugLines.set(r,{bindGroup:this.device.createBindGroup({entries:[{binding:0,resource:{buffer:a}}],label:`debug-line-${r}`,layout:this.pipelines.debugLineLayout}),throughDepth:n.throughDepth??!1,uniform:a,vertexCount:Math.floor(e.length/3),vertices:i,visible:!0}),r}createVehicle(e){let t=this.vehicleModels.get(e),n=this.vehicleParts.get(e);if(!t||!n)throw Error(`createVehicle: unknown model ${e}`);let r=t.instances.indexOf(null);r===-1&&(r=t.capacity,this.growVehicleModel(t,t.capacity*2));let i={entity:new dt(n),lamps:{brakes:!1,headlights:!1,intensity:1,smashed:0},opaqueOrder:null,paint:Pn,plate:{city:0,textSlot:0},slot:r,submeshVisible:new Uint8Array(t.submeshes.length).fill(1)};return t.instances[r]=i,this.writeVehiclePaint(t,r,Pn),{entity:i.entity,model:e,setLamps:(e,n,r,a)=>{let o=i.lamps;o.headlights===e&&o.brakes===n&&o.intensity===r&&o.smashed===a||(i.lamps={brakes:n,headlights:e,intensity:r,smashed:a},this.writeVehicleLamps(t,i.slot,i.lamps))},setPaint:e=>{this.writeVehiclePaint(t,i.slot,e)},setPlate:(e,n)=>{i.plate.city===n&&i.plate.textSlot===e||(i.plate={city:n,textSlot:e},this.writeVehiclePlate(t,i.slot,e,n))},setSubmeshVisible:(e,t)=>{let n=+!!t;i.submeshVisible[e]!==n&&(i.submeshVisible[e]=n,i.opaqueOrder=null)}}}createVehicleModel(e){let t=(e,t,n)=>{let r=Math.ceil(t.byteLength/4)*4,i=this.resources.createBuffer(`cellVertex`,{label:`vehicle-${e}`,size:r,usage:n|GPUBufferUsage.COPY_DST}),a=t;return t.byteLength!==r&&(a=new Uint8Array(r),a.set(t)),this.device.queue.writeBuffer(i,0,a),i},n=[t(`positions`,e.positions,GPUBufferUsage.VERTEX),t(`normals`,e.normals,GPUBufferUsage.VERTEX),t(`uvs`,e.uvs,GPUBufferUsage.VERTEX),t(`colors`,e.colors,GPUBufferUsage.VERTEX),t(`meta`,e.meta,GPUBufferUsage.VERTEX),t(`reflect`,e.reflect,GPUBufferUsage.VERTEX),t(`night`,e.night,GPUBufferUsage.VERTEX)],r=t(`indices`,e.indices,GPUBufferUsage.INDEX),i=this.createVehicleMatrixBuffer(e.parts.length,J),a=this.createVehiclePaintBuffer(e.parts.length,J),o=this.createVehicleLampBuffer(e.parts.length,J),s=this.createVehiclePlateBuffer(e.parts.length,J),c=this.createModelUvAnim(e.uvAnimations??[]),l=e.textures.map(e=>this.createModelTexture(e,`vehicle-texture`)),u=l.map(e=>e.texture),d=l.map(e=>e.byteEstimate),f=this.vehicleModelSeq;this.vehicleModelSeq+=1;let p={bindGroups:new Map,buffers:n,capacity:J,index16:e.index16??!0,indexBuffer:r,instances:Array(J).fill(null),lampBuffer:o,matrixBuffer:i,paintBuffer:a,partCount:e.parts.length,plateBuffer:s,submeshes:e.submeshes,textureBytes:d,textures:u,uvAnimations:c.animations,uvAnimBuffer:c.buffer,uvAnimOwned:c.owned,worldArrays:e.textures.length===0};return this.vehicleModels.set(f,p),this.vehicleParts.set(f,e.parts),f}debugViewMode(){return this.debugNormals?2:+!!this.debugUnlit}destroyDebugLines(e){let t=this.debugLines.get(e);t&&(this.resources.destroyBuffer(`cellVertex`,t.vertices),this.resources.destroyBuffer(`uniform`,t.uniform),this.debugLines.delete(e))}destroyVehicle(e){let t=this.vehicleModels.get(e.model);if(!t)return;let n=t.instances.findIndex(t=>t?.entity===e.entity);n!==-1&&(t.instances[n]=null)}destroyVehicleModel(e){let t=this.vehicleModels.get(e);if(t){for(let e of t.buffers)this.resources.destroyBuffer(`cellVertex`,e);this.resources.destroyBuffer(`cellVertex`,t.indexBuffer),this.resources.destroyBuffer(`uniform`,t.matrixBuffer),this.resources.destroyBuffer(`uniform`,t.paintBuffer),this.resources.destroyBuffer(`uniform`,t.lampBuffer),this.resources.destroyBuffer(`uniform`,t.plateBuffer),t.uvAnimOwned&&this.resources.destroyBuffer(`uniform`,t.uvAnimBuffer),t.textures.forEach((e,n)=>{this.resources.destroyTexture(`texture`,e,t.textureBytes[n]??0)}),this.vehicleModels.delete(e),this.vehicleParts.delete(e)}}frame(e){let t=performance.now(),n=this.firstFrameDetail>0;n&&--this.firstFrameDetail;let r=(e,t)=>n?this.firstFrameSpans.measure(e,t):t(),i=this.canvasContext.getCurrentTexture();r(`frame:targets`,()=>{this.ensureTargets(i.width,i.height)}),re(this.proj,e),E(this.view,e.eye,e.target,e.up),D(this.viewProj,this.proj,this.view),T(this.invViewProj,this.viewProj);let a=this.frameData;a.set(this.viewProj,0),a.set(this.invViewProj,16),a.set([...e.eye,0],32);let o=this.environment,s=(performance.now()-this.startedMs)/1e3,c=Math.hypot(o.sunDir[0],o.sunDir[1],o.sunDir[2])||1;a.set([o.sunDir[0]/c,o.sunDir[1]/c,o.sunDir[2]/c,o.sunElevation],36),a.set([...o.sunColor,1],40),a.set([o.dn,o.sunIndirect,o.sunDirect,o.emissiveBoost],44),a.set([...o.skyTop,1],48),a.set([...o.skyHorizon,1],52),a.set([o.fogCutDistance,o.fogStartDistance,o.fogHeightK,o.fogHeightMin],56),a.set([o.aoStrength,o.sunVisStrength,s,o.windStrength],60);let l=Math.hypot(o.moonDir[0],o.moonDir[1],o.moonDir[2])||1;a.set([o.moonDir[0]/l,o.moonDir[1]/l,o.moonDir[2]/l,o.stochastic],64),a.set([...o.moonColor,this.debugViewMode()],68),a[72]=this.fillLightPool(),a[88]=this.dynamicLights.length,a[89]=o.moonPhase,a[90]=o.reflectionStrength,a[73]=this.debugPrelitScale,a[74]=o.cloudDark,a[75]=Math.min(1,Math.max(0,o.cloudAlpha)),a.set([...o.sunCoreColor,o.sunSize*xn],76),a.set([...o.sunCoronaColor,Math.min(1,Math.max(0,o.cloudCover))],80),a.set([...o.waterColor,Math.min(1,Math.max(0,o.waterAlpha))],84),a.set([...o.cloudTopColor,o.cloudScale],92),a.set([...o.cloudBottomColor,1],96),a.set([...o.ambientColor,0],100),r(`frame:sky-lut`,()=>{this.refreshSkyLut()}),r(`frame:probe`,()=>{this.scheduleProbe(a)}),this.device.queue.writeBuffer(this.frameUniform,0,a),S(this.frustumPlanes,this.viewProj);let u=()=>n?performance.now():0,d=(e,t)=>{n&&this.firstFrameSpans.add(e,performance.now()-t)},f=u(),p=this.frameBundles,m=this.frameBlendCells;p.length=0,m.length=0;let h=0,g=0,_=0,v=0;this.frameTriangles=0;for(let t of this.cells.all())g+=1,t.visible=!A(e.eye,t.bounds[0],t.bounds[1],t.bounds[2],t.bounds[3],o.fogCutDistance)&&C(this.frustumPlanes,t.bounds[0],t.bounds[1],t.bounds[2],t.bounds[3]),t.visible&&(p.push(t.bundle),t.blendBundle&&m.push({bundle:t.blendBundle,distanceSq:(t.bounds[0]-e.eye[0])**2+(t.bounds[1]-e.eye[1])**2+(t.bounds[2]-e.eye[2])**2}),h+=t.draws,_+=t.triangles,v+=t.roadsignQuads);let y=this.orderBlendBundles(m);d(`frame:cull`,f);let b=u(),x=this.device.createCommandEncoder({label:`frame`}),w=x.beginRenderPass({colorAttachments:[{loadOp:`clear`,storeOp:`store`,view:this.cloudFieldView}],label:`cloud-field`});w.setPipeline(this.pipelines.get(`cloud-field`)),w.setBindGroup(0,this.cloudFieldBindGroup),w.draw(3),w.end();let O=x.beginRenderPass({colorAttachments:[{clearValue:this.skyColor,loadOp:`clear`,resolveTarget:this.sceneColorView,storeOp:`discard`,view:this.msaaView}],depthStencilAttachment:{depthClearValue:0,depthLoadOp:`clear`,depthStoreOp:`discard`,view:this.depthView},label:`world`,...this.timers.passTimestampWrites()});p.length>0&&O.executeBundles(p),this.advanceUvAnimations(s),this.advanceModelUvAnimations(s),h+=this.drawObjects(O),h+=this.drawClutter(O,e),h+=this.drawPed(O),h+=this.drawVehicles(O,!1,e.eye),O.setPipeline(this.pipelines.get(`sky`)),O.setBindGroup(0,this.frameBindGroup),O.draw(3),h+=this.drawWater(O),h+=this.drawSkidMarks(O,s),y.length>0&&O.executeBundles(y),h+=this.drawVehicles(O,!0,e.eye),h+=this.drawParticles(O),h+=this.drawDynamicParticles(O,s),h+=this.drawDebris(O),h+=this.drawCoronas(O,e),h+=this.drawDebugLines(O),this.probeView&&(O.setPipeline(this.pipelines.get(`probe-view`)),O.setBindGroup(0,this.frameBindGroup),O.setBindGroup(1,this.probeViewBindGroup),O.draw(3)),O.end();let k=this.bloomChain,j=k!==null&&this.environment.bloomIntensity>0;if(k&&j){let e=this.bloomPrefilterScratch;e[4]=this.environment.bloomThreshold,e[5]=En,this.device.queue.writeBuffer(this.bloomPrefilterUniform,0,e),this.runFullscreenPass(x,`bloom-prefilter`,k.prefilterBindGroup,k.prefilterView,this.timers.postBeginTimestampWrites());for(let e=0;e<k.downViews.length;e+=1)this.runFullscreenPass(x,`bloom-down`,k.downBindGroups[e],k.downViews[e],{});for(let e=k.upViews.length-1;e>=0;--e)this.runFullscreenPass(x,`bloom-up`,k.upBindGroups[e],k.upViews[e],{})}this.device.queue.writeBuffer(this.postUniform,0,this.fillPostUniform());let M=x.beginRenderPass({colorAttachments:[{clearValue:{a:1,b:0,g:0,r:0},loadOp:`clear`,storeOp:`store`,view:i.createView({format:this.engineDevice.colorFormat})}],label:`post`,...j?this.timers.postEndTimestampWrites():this.timers.postOnlyTimestampWrites()});M.setPipeline(this.pipelines.get(`post`)),M.setBindGroup(0,this.postBindGroup),M.draw(3),M.end(),d(`frame:record`,b);let ee=u();return this.timers.resolve(x),this.device.queue.submit([x.finish()]),this.timers.read(),d(`frame:submit`,ee),n&&this.firstFrameTotals.push(this.firstFrameSpans.drain()),this.statsValue.submitMs=performance.now()-t,this.statsValue.gpuPassMs=this.timers.lastPassMs,this.statsValue.gpuPostMs=this.timers.lastPostMs,this.statsValue.gpuProbeMs=this.timers.lastProbeMs,this.statsValue.cellsTotal=g,this.statsValue.cellsVisible=p.length,this.statsValue.drawsRecorded=h,this.statsValue.trianglesRecorded=_+this.frameTriangles,this.statsValue.roadsignQuadsRecorded=v,this.statsValue.residencyBytes=this.resources.totalBytes(),this.statsValue}async init(e,t){let n=performance.now(),r=(e,t)=>(this.bootSpans.add(e,performance.now()-t),performance.now());this.engineDevice=await x();let i=r(`init:device`,n);this.canvasElement=e,this.canvasContext=y(e,this.engineDevice),this.resources=new j(this.device),this.timers=new ne(this.device,this.engineDevice.hasTimestamps),i=r(`init:canvas`,i),this.pipelines=await bt(this.device,U,vn,this.engineDevice.colorFormat),i=r(`init:pipelines`,i),this.probe=new Mt(this.device,this.resources,this.pipelines),this.plateTexture=this.createPlateTexture(Mn,jn,256,`plate-text`),this.plateBackTexture=this.createPlateTexture(1,1,Nn,`plate-backgrounds`),this.probeViewBindGroup=this.device.createBindGroup({entries:[{binding:0,resource:this.probe.cubeView},{binding:1,resource:this.probe.sampler}],label:`probe-view`,layout:this.pipelines.probeViewLayout}),this.identityUvAnim=this.resources.createBuffer(`uniform`,{label:`uv-anim-identity`,size:256,usage:GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST}),this.device.queue.writeBuffer(this.identityUvAnim,0,new Float32Array(rn)),this.frameUniform=this.resources.createBuffer(`uniform`,{label:`frame`,size:416,usage:GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST}),this.lightPoolBuffer=this.resources.createBuffer(`uniform`,{label:`light-pool`,size:this.lightPoolScratch.byteLength,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST}),this.skyLutTexture=this.resources.createTexture(`texture`,{format:`rgba16float`,label:`sky-lut`,size:{height:48,width:96},usage:GPUTextureUsage.TEXTURE_BINDING|GPUTextureUsage.COPY_DST},4608*8),this.cloudFieldTexture=this.resources.createTexture(`texture`,{format:`rg16float`,label:`cloud-field`,size:{height:bn,width:bn},usage:GPUTextureUsage.RENDER_ATTACHMENT|GPUTextureUsage.TEXTURE_BINDING},bn*bn*4),this.cloudFieldView=this.cloudFieldTexture.createView(),this.cloudFieldBindGroup=this.device.createBindGroup({entries:[{binding:0,resource:{buffer:this.frameUniform}}],label:`cloud-field`,layout:this.pipelines.cloudFieldLayout});let a=t??Gn();this.coronaTexture=this.resources.createTexture(`texture`,{format:`rgba8unorm-srgb`,label:`corona-sprites`,size:{depthOrArrayLayers:a.layers,height:a.height,width:a.width},usage:GPUTextureUsage.TEXTURE_BINDING|GPUTextureUsage.COPY_DST},a.rgba.byteLength);let o=a.width*a.height*4;for(let e=0;e<a.layers;e+=1)this.device.queue.writeTexture({origin:{x:0,y:0,z:e},texture:this.coronaTexture},a.rgba.subarray(e*o,(e+1)*o),{bytesPerRow:a.width*4},{height:a.height,width:a.width});this.frameBindGroup=this.device.createBindGroup({entries:[{binding:0,resource:{buffer:this.frameUniform}},{binding:1,resource:this.skyLutTexture.createView()},{binding:2,resource:this.device.createSampler({label:`sky-lut`,magFilter:`linear`,minFilter:`linear`})},{binding:3,resource:{buffer:this.lightPoolBuffer}},{binding:6,resource:this.coronaTexture.createView({dimension:`2d-array`})},{binding:7,resource:this.cloudFieldView}],label:`frame`,layout:this.pipelines.frameLayout}),i=r(`init:resources`,i),this.refreshSkyLut(),i=r(`init:sky-lut`,i),this.textures=new _n(this.device,this.resources,this.pipelines.materialLayout),this.coronaQuad=this.resources.createBuffer(`cellVertex`,{label:`corona-quad`,size:48,usage:GPUBufferUsage.VERTEX|GPUBufferUsage.COPY_DST}),this.device.queue.writeBuffer(this.coronaQuad,0,new Float32Array([-1,-1,1,-1,1,1,-1,-1,1,1,-1,1])),this.coronaInstances=this.resources.createBuffer(`cellVertex`,{label:`corona-instances`,size:yn*32,usage:GPUBufferUsage.VERTEX|GPUBufferUsage.COPY_DST}),this.postUniform=this.resources.createBuffer(`uniform`,{label:`post`,size:48,usage:GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST}),this.postSampler=this.device.createSampler({label:`post`,magFilter:`linear`,minFilter:`linear`}),this.bloomPrefilterUniform=this.resources.createBuffer(`uniform`,{label:`bloom-prefilter`,size:32,usage:GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST}),this.clutterSampler=this.device.createSampler({addressModeU:`repeat`,addressModeV:`repeat`,label:`clutter`,magFilter:`linear`,minFilter:`linear`}),this.cells=new un({colorFormat:U,depthFormat:vn,device:this.device,frameBindGroup:this.frameBindGroup,pipelines:this.pipelines,resources:this.resources,textures:this.textures}),this.ensureTargets(e.width,e.height),r(`init:targets`,i),this.bootTotals=this.bootSpans.drain()}initDynamicParticles(e){this.removeDynamicParticles(),e.systems.length!==0&&(this.dynamicParticles=new gt(this.device,this.resources,this.pipelines.particleLayout,e))}initSkidMarks(e){this.removeSkidMarks(),this.skidMarks=new Ft(this.device,this.resources,this.pipelines.skidLayout,e)}ledger(){return this.resources.ledger()}releaseWorldArray(e){for(let t of this.vehicleModels.values())if(!(!t.worldArrays||!t.instances.some(e=>e!==null))&&t.submeshes.some(t=>(t.array??0)===e))return!1;for(let t of this.vehicleModels.values())t.worldArrays&&t.bindGroups.delete(e);return this.textures.unload(e),!0}removeCellClutter(e){let t=this.clutterCells.get(e);if(t){for(let e of t){for(let t of e.keyHashes)this.clutterBreakables.delete(t);this.resources.destroyBuffer(`uniform`,e.matrixBuffer),this.resources.destroyBuffer(`uniform`,e.drawDistanceBuffer)}this.clutterCells.delete(e)}}removeDynamicParticles(){this.dynamicParticles?.destroy(),this.dynamicParticles=null}removeParticles(){this.particles&&=(this.resources.destroyBuffer(`cellVertex`,this.particles.instancesAdd),this.resources.destroyBuffer(`cellVertex`,this.particles.instancesBlend),this.resources.destroyBuffer(`cellVertex`,this.particles.systems),this.resources.destroyTexture(`texture`,this.particles.texture,this.particles.textureBytes),null)}removePedProbe(){if(this.ped){for(let e of this.ped.buffers)this.resources.destroyBuffer(`cellVertex`,e);this.resources.destroyBuffer(`cellVertex`,this.ped.indexBuffer),this.resources.destroyBuffer(`uniform`,this.ped.paletteBuffer);for(let e of this.pedTextures)this.resources.destroyTexture(`texture`,e,this.pedTextureBytes/Math.max(1,this.pedTextures.length));this.pedTextures=[],this.ped=null}}removeSkidMarks(){this.skidMarks?.destroy(),this.skidMarks=null}setCellClutter(e,t){this.removeCellClutter(e);let n=[];for(let r of t){let t=this.clutterModels.get(r.model);if(!t||r.matrices.length===0)continue;let i=this.resources.createBuffer(`uniform`,{label:`clutter-matrices:${e}:${r.model}`,size:r.matrices.byteLength,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST});this.device.queue.writeBuffer(i,0,r.matrices);let a=this.resources.createBuffer(`uniform`,{label:`clutter-range:${e}:${r.model}`,size:16,usage:GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST});this.device.queue.writeBuffer(a,0,new Float32Array([r.drawDistance*r.drawDistance,0,0,0]));let o=[],s=r.matrices.length/16;if(r.keyHashes)for(let e=0;e<s;e+=1){let t=r.keyHashes[e];t!==0&&(this.clutterBreakables.set(t,{matrixBuffer:i,offset:e*64}),o.push(t))}n.push({bindGroup:this.device.createBindGroup({entries:[{binding:0,resource:{buffer:i}},{binding:1,resource:t.texture.createView({dimension:`2d-array`})},{binding:2,resource:this.clutterSampler},{binding:3,resource:{buffer:a}}],label:`clutter:${e}:${r.model}`,layout:this.pipelines.clutterLayout}),bounds:Wn(r.matrices),drawDistance:r.drawDistance,drawDistanceBuffer:a,instanceCount:s,keyHashes:o,matrixBuffer:i,model:r.model})}n.length>0&&this.clutterCells.set(e,n)}setDebugLinesVisible(e,t){let n=this.debugLines.get(e);n&&(n.visible=t)}setParticles(e){if(this.removeParticles(),e.systems.length===0)return;let t=(e,t,n)=>{let r=Math.max(16,Math.ceil(t.byteLength/4)*4),i=this.resources.createBuffer(`cellVertex`,{label:`particle-${e}`,size:r,usage:n|GPUBufferUsage.COPY_DST});return this.device.queue.writeBuffer(i,0,t),i},n=e.atlas.width*e.atlas.height*4,r=this.resources.createTexture(`texture`,{format:`rgba8unorm-srgb`,label:`particle-atlas`,size:{depthOrArrayLayers:Math.max(1,e.atlas.layers),height:e.atlas.height,width:e.atlas.width},usage:GPUTextureUsage.TEXTURE_BINDING|GPUTextureUsage.COPY_DST},e.atlas.rgba.byteLength);for(let t=0;t<e.atlas.layers;t+=1)this.device.queue.writeTexture({origin:{x:0,y:0,z:t},texture:r},e.atlas.rgba.subarray(t*n,(t+1)*n),{bytesPerRow:e.atlas.width*4},{height:e.atlas.height,width:e.atlas.width});let i=t(`systems`,e.systems,GPUBufferUsage.STORAGE);this.particles={bindGroup:this.device.createBindGroup({entries:[{binding:0,resource:{buffer:i}},{binding:1,resource:r.createView({dimension:`2d-array`})},{binding:2,resource:this.device.createSampler({label:`particle`,magFilter:`linear`,minFilter:`linear`})}],label:`particle`,layout:this.pipelines.particleLayout}),countAdd:e.instancesAdd.length/On,countBlend:e.instancesBlend.length/On,instancesAdd:t(`add`,e.instancesAdd,GPUBufferUsage.VERTEX),instancesBlend:t(`blend`,e.instancesBlend,GPUBufferUsage.VERTEX),systems:i,texture:r,textureBytes:e.atlas.rgba.byteLength}}setPedProbe(e){this.removePedProbe();let t=(e,t,n)=>{let r=Math.ceil(t.byteLength/4)*4,i=this.resources.createBuffer(`cellVertex`,{label:`ped-${e}`,size:r,usage:n|GPUBufferUsage.COPY_DST}),a=t;return t.byteLength!==r&&(a=new Uint8Array(r),a.set(t)),this.device.queue.writeBuffer(i,0,a),i},n=[t(`positions`,e.positions,GPUBufferUsage.VERTEX),t(`normals`,e.normals,GPUBufferUsage.VERTEX),t(`uvs`,e.uvs,GPUBufferUsage.VERTEX),t(`joints`,e.joints,GPUBufferUsage.VERTEX),t(`weights`,e.weights,GPUBufferUsage.VERTEX)],r=t(`indices`,e.indices,GPUBufferUsage.INDEX),i=new Float32Array((1+e.boneCount)*16),a=this.resources.createBuffer(`uniform`,{label:`ped-palette`,size:i.byteLength,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST}),o=e.textures.map(e=>this.createModelTexture(e,`ped-texture`)),s=this.device.createSampler({label:`ped`,magFilter:`linear`,minFilter:`linear`}),c=e.submeshes.map(e=>({bindGroup:this.device.createBindGroup({entries:[{binding:0,resource:{buffer:a}},{binding:1,resource:(o[e.array]??o[0]).texture.createView({arrayLayerCount:1,baseArrayLayer:e.layer,dimension:`2d`})},{binding:2,resource:s}],label:`ped`,layout:this.pipelines.pedLayout}),indexCount:e.indexCount,indexOffset:e.indexOffset}));return this.ped={buffers:n,indexBuffer:r,palette:i,paletteBuffer:a,submeshes:c},this.pedTextures=o.map(e=>e.texture),this.pedTextureBytes=o.reduce((e,t)=>e+t.byteEstimate,0),{palette:i}}setUvAnimations(e){this.uvAnimations=e.map(e=>({duration:e.duration,keyframes:[...e.keyframes].sort((e,t)=>e.time-t.time)})),this.uvAnimTransforms=new Float32Array(this.uvAnimations.length*4);for(let e=0;e<this.uvAnimations.length;e+=1)this.uvAnimTransforms.set([0,0,1,1],e*4)}setWater(e,t,n,r){let i=this.resources.createBuffer(`cellVertex`,{label:`water-vertices`,size:e.byteLength,usage:GPUBufferUsage.VERTEX|GPUBufferUsage.COPY_DST});this.device.queue.writeBuffer(i,0,e);let a=this.resources.createBuffer(`cellIndex`,{label:`water-indices`,size:t.byteLength,usage:GPUBufferUsage.INDEX|GPUBufferUsage.COPY_DST});this.device.queue.writeBuffer(a,0,t);let o=(e,t,n)=>{let r=e?.width??1,i=e?.height??1,a=this.resources.createTexture(`texture`,{format:`rgba8unorm`,label:t,size:{height:i,width:r},usage:GPUTextureUsage.TEXTURE_BINDING|GPUTextureUsage.COPY_DST},r*i*4);return this.device.queue.writeTexture({texture:a},e?.rgba??n,{bytesPerRow:r*4},{height:i,width:r}),a},s=o(n,`water-ripple`,new Uint8Array([128,128,128,255])),c=o(r,`water-foam`,new Uint8Array([0,0,0,0])),l=this.device.createBindGroup({entries:[{binding:0,resource:s.createView()},{binding:1,resource:this.device.createSampler({addressModeU:`repeat`,addressModeV:`repeat`,label:`water`,magFilter:`linear`,minFilter:`linear`})},{binding:2,resource:c.createView()}],label:`water`,layout:this.pipelines.waterLayout});this.water={bindGroup:l,indexCount:t.length,indices:a,vertices:i}}spawnDebris(e){this.debris.length>=In&&this.destroyDebris(this.debris.shift());let t=this.resources.createBuffer(`debris`,{label:`debris:vb`,size:e.vertices.byteLength,usage:GPUBufferUsage.VERTEX|GPUBufferUsage.COPY_DST});this.device.queue.writeBuffer(t,0,e.vertices);let n=this.resources.createBuffer(`uniform`,{label:`debris:uniform`,size:16,usage:GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST}),r=(performance.now()-this.startedMs)/1e3;this.device.queue.writeBuffer(n,0,new Float32Array([r,e.lifetime,e.fade,e.gravity]));let{byteEstimate:i,texture:a}=this.createModelTexture(e.texture,`debris:shards`);this.debris.push({bindGroup:this.device.createBindGroup({entries:[{binding:0,resource:{buffer:n}},{binding:1,resource:a.createView({dimension:`2d-array`})},{binding:2,resource:this.device.createSampler({label:`debris`,magFilter:`linear`,minFilter:`linear`})}],label:`debris`,layout:this.pipelines.debrisLayout}),expiresAt:r+e.lifetime,texture:a,textureBytes:i,uniform:n,vertexBuffer:t,vertexCount:e.vertices.byteLength/Fn})}spawnParticle(e,t,n,r,i,a,o,s,c=1){if(!this.dynamicParticles||!this.particlesEnabled)return!1;let l=(performance.now()-this.startedMs)/1e3;return this.dynamicParticles.spawn(l,e,t,n,r,i,a,o,s,c)}updateDebugLines(e,t){let n=this.debugLines.get(e);n&&(this.device.queue.writeBuffer(n.vertices,0,t),n.vertexCount=Math.floor(t.length/3))}updatePedPalette(){this.ped&&this.device.queue.writeBuffer(this.ped.paletteBuffer,0,this.ped.palette)}updateVehicles(){for(let e of this.vehicleModels.values()){let t=e.partCount*64;for(let n of e.instances)n&&(n.entity.flatten(),this.device.queue.writeBuffer(e.matrixBuffer,n.slot*t,n.entity.matrices))}}uploadPlateBackgrounds(e){let t=e[0];if(!(!t||e.length!==Nn)){this.plateBackTexture.destroy(),this.plateBackTexture=this.createPlateTexture(t.width,t.height,Nn,`plate-backgrounds`),e.forEach((e,n)=>{e.width===t.width&&e.height===t.height&&this.writePlateLayer(this.plateBackTexture,n,e.rgba,e.width,e.height)});for(let e of this.vehicleModels.values())e.bindGroups.clear()}}uploadPlateText(e,t){e<0||e>=256||t.byteLength!==Mn*jn*4||this.writePlateLayer(this.plateTexture,e,t,Mn,jn)}advanceModelUvAnimations(e){for(let t of this.vehicleModels.values())t.uvAnimations.length===0||!t.instances.some(e=>e!==null)||t.uvAnimations.forEach((n,r)=>{an(n,e,this.uvAnimScratch,0),this.device.queue.writeBuffer(t.uvAnimBuffer,(r+1)*256,this.uvAnimScratch)})}advanceUvAnimations(e){for(let t=0;t<this.uvAnimations.length;t+=1)an(this.uvAnimations[t],e,this.uvAnimTransforms,t*4)}bindRigidSubmesh(e,t,n,r){let i=n.array??0,a=on(n.uvAnim,t.uvAnimations.length);if(i===r.array&&a===r.offset)return!0;let o=this.rigidBindGroup(t,i);return o?(e.setBindGroup(1,o,[a]),r.array=i,r.offset=a,!0):!1}buildBloomChain(e,t){let n=this.bloomChain;if(n){for(let{bytes:e,texture:t}of n.textures)this.resources.destroyTexture(`target`,t,e);for(let e of n.uniforms)this.resources.destroyBuffer(`uniform`,e)}let r=[],i=[],a=(e,t,n)=>{let i=t*n*8,a=this.resources.createTexture(`target`,{format:U,label:e,size:{height:n,width:t},usage:GPUTextureUsage.RENDER_ATTACHMENT|GPUTextureUsage.TEXTURE_BINDING},i);return r.push({bytes:i,texture:a}),a.createView()},o=(e,t,n,r)=>{let a=this.resources.createBuffer(`uniform`,{label:e,size:32,usage:GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST});return this.device.queue.writeBuffer(a,0,new Float32Array([1/t,1/n,0,0,0,0,r,0])),i.push(a),a},s=a(`bloom-prefilter`,e,t),c=this.device.createBindGroup({entries:[{binding:0,resource:{buffer:this.bloomPrefilterUniform}},{binding:1,resource:this.sceneColorView},{binding:2,resource:this.postSampler}],label:`bloom-prefilter`,layout:this.pipelines.bloomLayout}),l=[],u=[],d=[],f=e,p=t;for(let e=0;e<q;e+=1){let t=f,n=p;f=Math.max(1,Math.round(f*.5)),p=Math.max(1,Math.round(p*.5)),l.push({height:p,width:f}),u.push(a(`bloom-down-${e}`,f,p)),d.push(this.device.createBindGroup({entries:[{binding:0,resource:{buffer:o(`bloom-down-${e}`,t,n,0)}},{binding:1,resource:e===0?s:u[e-1]},{binding:2,resource:this.postSampler}],label:`bloom-down-${e}`,layout:this.pipelines.bloomLayout}))}let m=[],h=[];for(let e=0;e<q-1;e+=1)m.push(a(`bloom-up-${e}`,l[e].width,l[e].height));for(let e=0;e<q-1;e+=1){let t=l[e+1];h.push(this.device.createBindGroup({entries:[{binding:0,resource:{buffer:o(`bloom-up-${e}`,t.width,t.height,Tn)}},{binding:1,resource:e===q-2?u[q-1]:m[e+1]},{binding:2,resource:this.postSampler},{binding:3,resource:u[e]}],label:`bloom-up-${e}`,layout:this.pipelines.bloomUpLayout}))}this.bloomChain={downBindGroups:d,downSizes:l,downViews:u,prefilterBindGroup:c,prefilterView:s,resultView:m[0],textures:r,uniforms:i,upBindGroups:h,upViews:m}}createModelTexture(e,t=`model-texture`){if(e.kind===`ostex`){let n=lt(this.device,this.resources,e.bytes,t);return{byteEstimate:n.byteEstimate,texture:n.texture}}let n=e.width*e.height*4,r=this.resources.createTexture(`texture`,{format:`rgba8unorm-srgb`,label:t,size:{depthOrArrayLayers:e.layers,height:e.height,width:e.width},usage:GPUTextureUsage.TEXTURE_BINDING|GPUTextureUsage.COPY_DST},e.rgba.byteLength);for(let t=0;t<e.layers;t+=1)this.device.queue.writeTexture({origin:{x:0,y:0,z:t},texture:r},e.rgba.subarray(t*n,(t+1)*n),{bytesPerRow:e.width*4},{height:e.height,width:e.width});return{byteEstimate:e.rgba.byteLength,texture:r}}createModelUvAnim(e){if(e.length===0)return{animations:e,buffer:this.identityUvAnim,owned:!1};let t=this.resources.createBuffer(`uniform`,{label:`vehicle-uv-anim`,size:(e.length+1)*256,usage:GPUBufferUsage.UNIFORM|GPUBufferUsage.COPY_DST});return this.device.queue.writeBuffer(t,0,new Float32Array(rn)),{animations:e,buffer:t,owned:!0}}createPlateTexture(e,t,n,r){return this.device.createTexture({dimension:`2d`,format:`rgba8unorm`,label:r,size:{depthOrArrayLayers:n,height:t,width:e},usage:GPUTextureUsage.TEXTURE_BINDING|GPUTextureUsage.COPY_DST})}createVehicleBindGroup(e){return this.device.createBindGroup({entries:[{binding:0,resource:{buffer:e.matrixBuffer}},{binding:1,resource:e.texture.createView({dimension:`2d-array`})},{binding:2,resource:this.device.createSampler({addressModeU:`repeat`,addressModeV:`repeat`,label:`vehicle`,magFilter:`linear`,minFilter:`linear`})},{binding:3,resource:{buffer:e.paintBuffer}},{binding:4,resource:{buffer:e.lampBuffer}},{binding:5,resource:this.probe.cubeView},{binding:6,resource:this.probe.sampler},{binding:7,resource:{buffer:e.plateBuffer}},{binding:8,resource:this.plateTexture.createView({dimension:`2d-array`})},{binding:9,resource:this.plateBackTexture.createView({dimension:`2d-array`})},{binding:10,resource:{buffer:e.uvAnimBuffer,offset:0,size:16}}],label:`vehicle`,layout:this.pipelines.rigidLayout})}createVehicleLampBuffer(e,t){return this.resources.createBuffer(`uniform`,{label:`vehicle-lamps`,size:e*t*kn,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST})}createVehicleMatrixBuffer(e,t){return this.resources.createBuffer(`uniform`,{label:`vehicle-matrices`,size:e*t*64,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST})}createVehiclePaintBuffer(e,t){return this.resources.createBuffer(`uniform`,{label:`vehicle-paint`,size:e*t*Dn,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST})}createVehiclePlateBuffer(e,t){return this.resources.createBuffer(`uniform`,{label:`vehicle-plates`,size:e*t*An,usage:GPUBufferUsage.STORAGE|GPUBufferUsage.COPY_DST})}destroyDebris(e){this.resources.destroyBuffer(`debris`,e.vertexBuffer),this.resources.destroyBuffer(`uniform`,e.uniform),this.resources.destroyTexture(`texture`,e.texture,e.textureBytes)}drawClutter(e,t){if(!this.clutterEnabled)return 0;let n=0,[r,i,a]=t.eye;for(let t of this.clutterCells.values())for(let o of t){let t=this.clutterModels.get(o.model),[s,c,l,u]=o.bounds;Math.hypot(s-r,c-i,l-a)-u>o.drawDistance||!t||t.indexCount===0||o.instanceCount===0||!C(this.frustumPlanes,o.bounds[0],o.bounds[1],o.bounds[2],o.bounds[3])||(e.setPipeline(this.pipelines.get(t.cutout?`clutter-cutout`:`clutter-opaque`)),e.setBindGroup(0,this.frameBindGroup),e.setBindGroup(1,o.bindGroup),t.buffers.forEach((t,n)=>e.setVertexBuffer(n,t)),e.setIndexBuffer(t.indexBuffer,`uint16`),e.drawIndexed(t.indexCount,o.instanceCount),this.frameTriangles+=t.indexCount/3*o.instanceCount,n+=1)}return n}drawCoronas(e,t){let n=Math.min(1,Math.max(0,this.environment.dn*1.5)),r=0,i=this.coronaScratch;for(let e of this.dynamicCoronas){if(r>=yn)break;let t=r*8;i[t]=e.position[0],i[t+1]=e.position[1],i[t+2]=e.position[2],i[t+3]=e.size,i[t+4]=e.color[0],i[t+5]=e.color[1],i[t+6]=e.color[2],i[t+7]=e.fade,r+=1}for(let e of n<=.02?[]:this.cells.all())if(!(!e.visible||e.lights.length===0))for(let a of e.lights){if(r>=yn)break;let e=a.x-t.eye[0],o=a.y-t.eye[1],s=a.z-t.eye[2],c=Math.hypot(e,o,s),l=Math.max(a.farClip,350);if(c>l)continue;let u=n*Math.min(1,(1-c/l)*4)*(a.color[3]/255),d=r*8;i[d]=a.x,i[d+1]=a.y,i[d+2]=a.z,i[d+3]=a.size*1.5,i[d+4]=(a.color[0]/255)**2.2,i[d+5]=(a.color[1]/255)**2.2,i[d+6]=(a.color[2]/255)**2.2,i[d+7]=u,r+=1}return r===0?0:(this.device.queue.writeBuffer(this.coronaInstances,0,i,0,r*8),e.setPipeline(this.pipelines.get(`corona`)),e.setBindGroup(0,this.frameBindGroup),e.setVertexBuffer(0,this.coronaQuad),e.setVertexBuffer(1,this.coronaInstances),e.draw(6,r),this.frameTriangles+=2*r,1)}drawDebris(e){let t=(performance.now()-this.startedMs)/1e3;for(;this.debris.length>0&&this.debris[0].expiresAt<=t;)this.destroyDebris(this.debris.shift());if(this.debris.length===0)return 0;e.setPipeline(this.pipelines.get(`debris`)),e.setBindGroup(0,this.frameBindGroup);for(let t of this.debris)e.setBindGroup(1,t.bindGroup),e.setVertexBuffer(0,t.vertexBuffer),e.draw(t.vertexCount);return this.debris.length}drawDebugLines(e){if(this.debugLines.size===0)return 0;e.setBindGroup(0,this.frameBindGroup);let t=0,n=null;for(let r of this.debugLines.values())r.visible&&(n!==r.throughDepth&&(e.setPipeline(this.pipelines.get(r.throughDepth?`debug-line-through`:`debug-line`)),n=r.throughDepth),e.setBindGroup(1,r.bindGroup),e.setVertexBuffer(0,r.vertices),e.draw(r.vertexCount),t+=1);return t}drawDynamicParticles(e,t){if(!this.dynamicParticles||!this.particlesEnabled)return 0;let n=this.dynamicParticles.draw(e,this.pipelines,this.frameBindGroup,this.coronaQuad,t);return this.frameTriangles+=2*this.dynamicParticles.count,n}drawObjectGroups(e,t){if((t.kind===4||t.kind===5)&&t.uvAnimUniform){let e=(t.kind===5?t.params&65535:t.params)*4;e+4<=this.uvAnimTransforms.length&&(this.uvAnimScratch.set(this.uvAnimTransforms.subarray(e,e+4)),this.device.queue.writeBuffer(t.uvAnimUniform,16,this.uvAnimScratch))}e.setBindGroup(1,t.bindGroup);let n=0;for(let r of t.groups)e.setPipeline(this.pipelines.get(xt(r.pipelineClass,r.side))),e.setBindGroup(2,this.textures.get(r.textureArrayRef).bindGroup),e.drawIndexed(r.indexCount,1,r.indexOffset,0,0),this.frameTriangles+=r.indexCount/3,n+=1;return n}drawObjects(e){let t=(this.environment.hour%24+24)%24,n=0;for(let r of this.cells.all()){if(!r.visible||r.objects.length===0)continue;let i=!1;for(let a of r.objects)(a.kind===4||a.kind===0&&Kn(a.params,t)||a.kind===5&&Kn(a.params>>16&65535,t))&&(i||=(e.setBindGroup(0,this.frameBindGroup),e.setVertexBuffer(0,r.vertexBuffer),e.setIndexBuffer(r.indexBuffer,r.index16?`uint16`:`uint32`),!0),n+=this.drawObjectGroups(e,a))}return n}drawParticles(e){if(!this.particles||!this.particlesEnabled)return 0;let t=0;for(let[n,r,i]of[[`particle-blend`,this.particles.instancesBlend,this.particles.countBlend],[`particle-add`,this.particles.instancesAdd,this.particles.countAdd]])i!==0&&(e.setPipeline(this.pipelines.get(n)),e.setBindGroup(0,this.frameBindGroup),e.setBindGroup(1,this.particles.bindGroup),e.setVertexBuffer(0,this.coronaQuad),e.setVertexBuffer(1,r),e.draw(6,i),this.frameTriangles+=2*i,t+=1);return t}drawPed(e){if(!this.ped)return 0;e.setPipeline(this.pipelines.get(`ped`)),e.setBindGroup(0,this.frameBindGroup),this.ped.buffers.forEach((t,n)=>e.setVertexBuffer(n,t)),e.setIndexBuffer(this.ped.indexBuffer,`uint16`);for(let t of this.ped.submeshes)e.setBindGroup(1,t.bindGroup),e.drawIndexed(t.indexCount,1,t.indexOffset),this.frameTriangles+=t.indexCount/3;return this.ped.submeshes.length}drawSkidMarks(e,t){if(!this.skidMarks||!this.particlesEnabled)return 0;let n=this.skidMarks.draw(e,this.pipelines.get(`skid`),this.frameBindGroup,t);return this.frameTriangles+=2*this.skidMarks.ring.count,n}drawVehicleModel(e,t,n,r){let i=0,a=!1,o={array:-1,offset:-1},s=t.index16?`uint16`:`uint32`;for(let c of t.instances)if(c)for(let l of this.submeshDrawOrder(c,t,n,r)){let r=t.submeshes[l];a||=(e.setPipeline(this.pipelines.get(n?`rigid-blend`:`rigid-opaque`)),e.setBindGroup(0,this.frameBindGroup),t.buffers.forEach((t,n)=>e.setVertexBuffer(n,t)),e.setIndexBuffer(t.indexBuffer,s),!0),this.bindRigidSubmesh(e,t,r,o)&&(e.drawIndexed(r.indexCount,1,r.indexOffset,0,c.slot*t.partCount+r.part),this.frameTriangles+=r.indexCount/3,i+=1)}return i}drawVehicles(e,t,n){let r=0;for(let i of this.vehicleModels.values())r+=this.drawVehicleModel(e,i,t,n);return r}drawWater(e){return!this.water||!this.waterEnabled?0:(e.setPipeline(this.pipelines.get(`water`)),e.setBindGroup(0,this.frameBindGroup),e.setBindGroup(1,this.water.bindGroup),e.setVertexBuffer(0,this.water.vertices),e.setIndexBuffer(this.water.indices,`uint32`),e.drawIndexed(this.water.indexCount),this.frameTriangles+=this.water.indexCount/3,1)}ensureTargets(e,t){let n=Math.min(1,Math.max(.5,this.renderScale)),r=Math.max(2,Math.round(e*n)),i=Math.max(2,Math.round(t*n)),a=`${r}x${i}`;if(this.targetKey===a)return;this.targetKey=a;for(let{bytes:e,texture:t}of this.sceneTargets)this.resources.destroyTexture(`target`,t,e);this.sceneTargets.length=0;let o=r*i*12*4,s=this.resources.createTexture(`target`,{format:U,label:`msaa-color`,sampleCount:4,size:{height:i,width:r},usage:GPUTextureUsage.RENDER_ATTACHMENT},o/2);this.sceneTargets.push({bytes:o/2,texture:s});let c=this.resources.createTexture(`target`,{format:U,label:`scene-color`,size:{height:i,width:r},usage:GPUTextureUsage.RENDER_ATTACHMENT|GPUTextureUsage.TEXTURE_BINDING},r*i*8);this.sceneTargets.push({bytes:r*i*8,texture:c}),this.sceneColorView=c.createView(),this.buildBloomChain(r,i);let l=this.bloomChain;if(!l)throw Error(`bloom chain must exist after buildBloomChain`);this.postBindGroup=this.device.createBindGroup({entries:[{binding:0,resource:{buffer:this.postUniform}},{binding:1,resource:this.sceneColorView},{binding:2,resource:this.postSampler},{binding:3,resource:l.resultView}],label:`post`,layout:this.pipelines.postLayout});let u=this.resources.createTexture(`target`,{format:vn,label:`msaa-depth`,sampleCount:4,size:{height:i,width:r},usage:GPUTextureUsage.RENDER_ATTACHMENT},o/2);this.sceneTargets.push({bytes:o/2,texture:u}),this.msaaView=s.createView(),this.depthView=u.createView()}fillLightPool(){let e=this.lightPoolScratch,t=0,n=(n,r,i,a,o,s,c,l)=>{if(t>=zn)return;let u=t*Bn;e[u]=n,e[u+1]=r,e[u+2]=i,e[u+3]=a,e[u+4]=o,e[u+5]=s,e[u+6]=c,e[u+7]=0,e[u+8]=l?l.direction[0]:0,e[u+9]=l?l.direction[1]:0,e[u+10]=l?l.direction[2]:1,e[u+11]=l?l.cosAngle:Vn,t+=1};for(let e of this.dynamicLights)n(e.position[0],e.position[1],e.position[2],e.radius,...e.color,e.cone);return t>0&&this.device.queue.writeBuffer(this.lightPoolBuffer,0,e,0,t*Bn),t}fillPostUniform(){let e=new Float32Array(12),t=this.environment,n=this.viewProj,r=Math.hypot(t.sunDir[0],t.sunDir[1],t.sunDir[2])||1,[i,a,o]=[t.sunDir[0]/r,t.sunDir[1]/r,t.sunDir[2]/r],s=n[0]*i+n[4]*a+n[8]*o,c=n[1]*i+n[5]*a+n[9]*o,l=n[3]*i+n[7]*a+n[11]*o,u=0,d=.5,f=.5;if(l>1e-4&&a>0){d=.5+.5*s/l,f=.5-.5*c/l;let e=Math.max(0,-d,d-1,-f,f-1),n=Math.max(0,1-e/.45),r=Math.min(1,Math.max(...t.sunCoreColor)),i=Math.min(1,a/.045);u=Sn*n*r*i*Math.max(0,t.godrayStrength)}return e.set([d,f,u,Cn],0),e.set([...t.sunCoronaColor,wn],4),e[8]=t.tonemap,e[9]=Math.max(0,t.bloomIntensity),e}growVehicleModel(e,t){this.resources.destroyBuffer(`uniform`,e.matrixBuffer),this.resources.destroyBuffer(`uniform`,e.paintBuffer),this.resources.destroyBuffer(`uniform`,e.lampBuffer),this.resources.destroyBuffer(`uniform`,e.plateBuffer),e.matrixBuffer=this.createVehicleMatrixBuffer(e.partCount,t),e.paintBuffer=this.createVehiclePaintBuffer(e.partCount,t),e.lampBuffer=this.createVehicleLampBuffer(e.partCount,t),e.plateBuffer=this.createVehiclePlateBuffer(e.partCount,t),e.bindGroups.clear(),e.instances.length=t,e.instances.fill(null,e.capacity,t),e.capacity=t;let n=e.partCount*64;for(let t of e.instances)t&&(this.device.queue.writeBuffer(e.matrixBuffer,t.slot*n,t.entity.matrices),this.writeVehiclePaint(e,t.slot,t.paint),this.writeVehicleLamps(e,t.slot,t.lamps),this.writeVehiclePlate(e,t.slot,t.plate.textSlot,t.plate.city))}orderBlendBundles(e){e.sort((e,t)=>t.distanceSq-e.distanceSq);let t=this.frameBlendBundles;t.length=0;for(let n of e)t.push(n.bundle);return t}refreshSkyLut(){let e=this.environment,t=Math.min(1,Math.max(0,(e.sunDir[1]+.22)/.21)),n={cloudCover:e.cloudCover,cloudDark:e.cloudDark,exposure:e.skyExposure,model:e.skyModel,mood:e.skyMood,pbrNight:1-t*t*(3-2*t),skyHorizon:e.skyHorizon,skyTop:e.skyTop,sunElevation:e.sunElevation},r=Zt(n);r!==this.skyLutCurrentKey&&(this.skyLutCurrentKey=r,this.device.queue.writeTexture({texture:this.skyLutTexture},Xt(n),{bytesPerRow:768},{height:48,width:96}))}renderProbeFace(e,t){let{face:n,mix:r}=this.probe.beginFrame(e);this.probe.faceMatrices(n,e,this.probeViewProj,this.probeInvViewProj);let i=this.probeFrameData;i.set(t),i.set(this.probeViewProj,0),i.set(this.probeInvViewProj,16),i[32]=e[0],i[33]=e[1],i[34]=e[2],i[91]=r,this.device.queue.writeBuffer(this.frameUniform,0,i),S(this.probeFrustum,this.probeViewProj);let a=[];for(let t of this.cells.all()){let n=t.bounds[0]-e[0],r=t.bounds[1]-e[1],i=t.bounds[2]-e[2],o=350+t.bounds[3];n*n+r*r+i*i>o*o||C(this.probeFrustum,t.bounds[0],t.bounds[1],t.bounds[2],t.bounds[3])&&a.push(t.bundle)}let o=this.device.createCommandEncoder({label:`env-probe`});return this.probe.encodeFace(o,n,a,this.frameBindGroup,this.skyColor,{begin:this.timers.probeBeginTimestampWrites(),end:this.timers.probeEndTimestampWrites()}),this.device.queue.submit([o.finish()]),r}rigidBindGroup(e,t){let n=e.bindGroups.get(t);if(n)return n;let r;if(e.worldArrays){if(!this.textures.has(t))return null;r=this.textures.get(t).texture}else r=e.textures[t]??e.textures[0];if(!r)return null;let i=this.createVehicleBindGroup({...e,texture:r});return e.bindGroups.set(t,i),i}runFullscreenPass(e,t,n,r,i){let a=e.beginRenderPass({colorAttachments:[{clearValue:{a:0,b:0,g:0,r:0},loadOp:`clear`,storeOp:`store`,view:r}],label:t,...i});a.setPipeline(this.pipelines.get(t)),a.setBindGroup(0,n),a.draw(3),a.end()}scheduleProbe(e){let t=this.probeCenter;if(!t||this.environment.reflectionStrength<=0){e[91]=0,this.timers.probeSkipped();return}this.probeTick=(this.probeTick+1)%Rn,e[91]=this.probeTick===0?this.renderProbeFace(t,e):this.probe.mix()}submeshDrawOrder(e,t,n,r){if(!n&&e.opaqueOrder!==null)return e.opaqueOrder;let i=[];for(let a=0;a<t.submeshes.length;a+=1)t.submeshes[a].translucent===n&&e.submeshVisible[a]!==0&&i.push({distSq:n?this.submeshSortDistance(e,t,a,r):0,index:a});return n?(i.sort((e,t)=>t.distSq-e.distSq),i.map(e=>e.index)):(i.sort((e,n)=>(t.submeshes[e.index].array??0)-(t.submeshes[n.index].array??0)),e.opaqueOrder=i.map(e=>e.index),e.opaqueOrder)}submeshSortDistance(e,t,n,r){let i=t.submeshes[n],a=e.entity.matrices,o=i.part*16,s=(e,t,n)=>{let i=a[o]*e+a[o+4]*t+a[o+8]*n+a[o+12],s=a[o+1]*e+a[o+5]*t+a[o+9]*n+a[o+13],c=a[o+2]*e+a[o+6]*t+a[o+10]*n+a[o+14];return Math.hypot(i-r[0],s-r[1],c-r[2])},c=i.bounds;if(!c){let e=i.center??[0,0,0];return s(e[0],e[1],e[2])-(i.radius??0)}let[l,u,d]=[r[0]-a[o+12],r[1]-a[o+13],r[2]-a[o+14]],f=a[o]*a[o]+a[o+1]*a[o+1]+a[o+2]*a[o+2],p=f>0?1/f:0,m=(a[o]*l+a[o+1]*u+a[o+2]*d)*p,h=(a[o+4]*l+a[o+5]*u+a[o+6]*d)*p,g=(a[o+8]*l+a[o+9]*u+a[o+10]*d)*p;return s(Math.min(Math.max(m,c.min[0]),c.max[0]),Math.min(Math.max(h,c.min[1]),c.max[1]),Math.min(Math.max(g,c.min[2]),c.max[2]))}writePlateLayer(e,t,n,r,i){this.device.queue.writeTexture({origin:{x:0,y:0,z:t},texture:e},n,{bytesPerRow:r*4,rowsPerImage:i},{depthOrArrayLayers:1,height:i,width:r})}writeVehicleLamps(e,t,n){let r=new Float32Array(e.partCount*4);for(let t=0;t<e.partCount;t+=1)r[t*4]=+!!n.headlights,r[t*4+1]=+!!n.brakes,r[t*4+2]=n.intensity,r[t*4+3]=n.smashed;this.device.queue.writeBuffer(e.lampBuffer,t*e.partCount*kn,r)}writeVehiclePaint(e,t,n){let r=e.instances[t];r&&(r.paint=n);let i=new Float32Array(e.partCount*16);for(let t=0;t<e.partCount;t+=1){let e=t*16;i.set(n.primary,e),i.set(n.secondary,e+4),i.set(n.tertiary,e+8),i.set(n.quaternary,e+12)}this.device.queue.writeBuffer(e.paintBuffer,t*e.partCount*Dn,i)}writeVehiclePlate(e,t,n,r){let i=new Float32Array(e.partCount*4);for(let t=0;t<e.partCount;t+=1)i[t*4]=n,i[t*4+1]=r;this.device.queue.writeBuffer(e.plateBuffer,t*e.partCount*An,i)}},Un=8;function Wn(e){let t=1/0,n=1/0,r=1/0,i=-1/0,a=-1/0,o=-1/0;for(let s=0;s<e.length;s+=16){let[c,l,u]=[e[s+12],e[s+13],e[s+14]];t=Math.min(t,c),n=Math.min(n,l),r=Math.min(r,u),i=Math.max(i,c),a=Math.max(a,l),o=Math.max(o,u)}let s=[(t+i)/2,(n+a)/2,(r+o)/2];return[s[0],s[1],s[2],Math.hypot(i-s[0],a-s[1],o-s[2])+Un]}function Gn(){let e=new Uint8Array(16384*4*2),t=127/2;for(let n=0;n<2;n+=1)for(let r=0;r<128;r+=1)for(let i=0;i<128;i+=1){let a=Math.hypot(i-t,r-t)/t,o=n===0?Math.max(0,1-a)**2.2+Math.max(0,1-a)**8*.7:+(a<.92),s=(n*128*128+r*128+i)*4;e[s]=255,e[s+1]=255,e[s+2]=255,e[s+3]=Math.round(Math.min(1,o)*255)}return{height:128,layers:2,rgba:e,width:128}}function Kn(e,t){let n=e&255,r=e>>8&255;return n<r?t>=n&&t<r:t>=n||t<r}var qn=class{get cachedBytes(){return this.fromCacheBytes}get cachedRequests(){return this.fromCacheRequests}get requests(){return this.totalRequests}get totalBytes(){return this.bytes}bytes=0;fromCacheBytes=0;fromCacheRequests=0;kinds=new Map;totalRequests=0;record(e,t){let n=Jn(e),r=this.kinds.get(n)??{bytes:0,requests:0};r.bytes+=t,r.requests+=1,this.kinds.set(n,r),this.bytes+=t,this.totalRequests+=1}recordCacheHit(e){this.fromCacheBytes+=e,this.fromCacheRequests+=1}report(){return[...this.kinds.entries()].map(([e,t])=>({bytes:t.bytes,kind:e,requests:t.requests})).sort((e,t)=>t.bytes-e.bytes)}reset(){this.kinds.clear(),this.bytes=0,this.fromCacheBytes=0,this.fromCacheRequests=0,this.totalRequests=0}};function Jn(e){if(e.startsWith(`array-`))return`texture-array`;if(e.startsWith(`collision-`))return`collision`;let t=e.split(`,`);return t.length===3&&t[2]!==``?`cell-${t[2]}`:e}var Yn=new qn;function Xn(e,t,n){Yn.record(t,n.length),e.postMessage({...n.enc===void 0?{}:{enc:n.enc},key:t,length:n.length,offset:n.offset,type:`fetch`})}var Zn=`collision-`,Qn=class{cellSize;entries;pending=new Map;warned=new Set;worker;constructor(e,t){if(e.collision===void 0||e.collisionCellSize===void 0)throw Error(`PakCollisionSource needs a manifest with collision entries and their collisionCellSize`);this.entries=e.collision,this.cellSize=e.collisionCellSize,this.worker=t,t.addEventListener(`message`,e=>this.onBlob(e.data))}has(e,t){return this.entries[`${e},${t}`]!==void 0}async read(e,t){let n=`${e},${t}`,r=this.entries[n];if(!r)return null;let i=`${Zn}${n}`,a=this.pending.get(i);return a?new Promise(e=>a.push(e)):new Promise(e=>{this.pending.set(i,[e]),Xn(this.worker,i,r)})}onBlob(e){if(e.type!==`blob`||!e.key.startsWith(`collision-`))return;let t=this.pending.get(e.key);if(!t)return;this.pending.delete(e.key),!e.buffer&&!this.warned.has(e.key)&&(this.warned.add(e.key),console.warn(`[stream] baked collision ${e.key} failed: ${e.error??`unknown`} — parsing COL`));let n=e.buffer?new Uint8Array(e.buffer):null;for(let e of t)e(n)}},$n=class{camera;pixelHeight;planes=new Float32Array(24);constructor(e){this.camera=e.camera,this.pixelHeight=Math.max(1,e.pixelHeight);let t=re(w(),e.camera),n=E(w(),e.camera.eye,e.camera.target,e.camera.up);S(this.planes,D(w(),t,n))}distanceToBox(e,t,n){let[r,i,a]=this.camera.eye,o=Math.max(e[0]-r,0,r-e[1]),s=Math.max(t-i,0,i-n),c=Math.max(e[2]-a,0,a-e[3]);return Math.hypot(o,s,c)}screenError(e,t,n=0){return e/this.unitsPerPixel(t,n)}sees(e,t,n,r){return er(this.planes,[e[0]-r,e[1]+r,e[2]-r,e[3]+r],t-r,n+r)}unitsPerPixel(e,t=0){let{fovYRad:n,orthoHalfHeight:r}=this.camera;return r===void 0?2*Math.tan(n/2)*Math.max(e+t,0)/this.pixelHeight:2*(r+t)/this.pixelHeight}};function er(e,t,n,r){for(let i=0;i<6;i+=1){let a=e[i*4],o=e[i*4+1],s=e[i*4+2],c=e[i*4+3],l=a>=0?t[1]:t[0],u=o>=0?r:n,d=s>=0?t[3]:t[2];if(a*l+o*u+s*d+c<0)return!1}return!0}function tr(e){let t=new Map;for(let[n,r]of Object.entries(e.cells)){if(r.aabbY===void 0)return null;t.set(n,r.aabbY)}return t.size>0?t:null}function nr(){return new Worker(new URL(`/assets/pak-worker-Dq_fR62Z.js`,``+import.meta.url),{type:`module`})}var rr=380,ir=1e3,ar=60,or=150,sr=1.5,cr=1.5,lr=150,ur=300,dr=260,fr=.1,pr=class{arrayUsers=new Map;blobs=new Map;cells=new Map;cellSize;engine;extents;hdRadius;keyToSlot=new Map;lastFocus=null;lodRadius;manifest;manual=null;requested=new Set;stats={blobMs:0,blockedOnArrays:0,blockedOnBlob:0,created:0,evicted:0,lateCreates:0,loadedCells:0,pendingCells:0,uploadMs:0,worstBlobMs:0,worstCreateMs:0};teleportGrace=!0;velocity=[0,0];warnedArrays=new Set;worker;constructor(e,t,n,r={}){this.engine=e,this.manifest=t,this.worker=n,this.hdRadius=r.hdRadius??rr,this.lodRadius=r.lodRadius??ir;let i=t.cellSize??250;this.cellSize=i,this.extents=tr(t);for(let[e,n]of Object.entries(t.cells)){let[t,r,a]=e.split(`,`),o=Number(t),s=Number(r),c=`${o},${s}`,l=this.cells.get(c);if(!l){let e=[o*i,(o+1)*i,-(s+1)*i,-s*i];l={centre:[(o+.5)*i,-(s+.5)*i],current:null,cx:o,cy:s,evictRect:e,keys:{},pending:null,rect:e,rects:{}},this.cells.set(c,l)}l.keys[a]=e,n.aabb&&(l.rects[a]=n.aabb),this.keyToSlot.set(e,l)}for(let e of this.cells.values()){let t=Object.keys(e.keys).map(t=>e.rects[t]??e.rect);e.evictRect=t.reduce((e,t)=>[Math.min(e[0],t[0]),Math.max(e[1],t[1]),Math.min(e[2],t[2]),Math.max(e[3],t[3])],t[0])}n.addEventListener(`message`,e=>{let t=performance.now();this.onBlob(e.data);let n=performance.now()-t;this.stats.blobMs+=n,this.stats.worstBlobMs=Math.max(this.stats.worstBlobMs,n)})}dispose(){this.worker.terminate()}listCells(){return[...this.cells.values()].map(e=>[e.cx,e.cy])}setManualCells(e,t=!1){this.manual=e===null?null:{keys:new Set(e.map(([e,t])=>`${e},${t}`)),level:t?`lod`:`hd`}}unloadAll(){for(let e of this.cells.values())this.unload(e);this.blobs.clear(),this.requested.clear(),this.teleportGrace=!0}update(e,t){let[n,r]=this.advanceVelocity(e[0],e[2]);this.stats.uploadMs=this.engine.textures.drainUploads(cr);let i=t!==void 0&&this.extents!==null?new $n(t):null,{loaded:a,wanted:o}=this.retarget(n,r,e[0],e[2],i),s=o.length,c=a,l=0,u=0,d=0,f=0;for(let t of o){if(!this.requested.has(t.key)){this.requestBlob(t.key),this.texturesReady(t.key);continue}if(u>0&&(u>=2||l>=sr))continue;let n=this.blobs.get(t.key);if(!n){d+=1;continue}if(!this.texturesReady(t.key)){f+=1;continue}let r=t.slot.current!==null;l+=this.create(t.slot,t.level,t.key,n,Y(this.levelRect(t.slot,t.level),e[0],e[2])),u+=1,--s,r||(c+=1)}this.stats.pendingCells=s,this.stats.loadedCells=c,this.stats.blockedOnBlob=d,this.stats.blockedOnArrays=f,this.teleportGrace&&s===0&&(this.teleportGrace=!1),this.pruneStaleBlobs();let p={...this.stats};return this.stats.blobMs=0,this.stats.worstBlobMs=0,p}advanceVelocity(e,t){if(this.lastFocus===null)this.lastFocus=[e,t];else{let n=e-this.lastFocus[0],r=t-this.lastFocus[1];this.lastFocus[0]=e,this.lastFocus[1]=t,Math.hypot(n,r)>dr?(this.velocity[0]=0,this.velocity[1]=0,this.teleportGrace=!0):(this.velocity[0]+=(n-this.velocity[0])*fr,this.velocity[1]+=(r-this.velocity[1])*fr)}let n=this.velocity[0]*lr,r=this.velocity[1]*lr,i=Math.hypot(n,r);return i>ur&&(n*=ur/i,r*=ur/i),[e+n,t+r]}claimTextures(e){for(let t of this.manifest.cells[e].textures??[]){let n=this.arrayUsers.get(t)??new Set;n.add(e),this.arrayUsers.set(t,n)}}create(e,t,n,r,i){let a=performance.now();!this.teleportGrace&&e.current===null&&i<this.engine.environment.fogCutDistance&&(this.stats.lateCreates+=1),this.engine.cells.load(n,r),this.claimTextures(n);let o=e.current?e.keys[e.current]:void 0;o!==void 0&&o!==n&&(this.engine.cells.unload(o),this.releaseTextures(o),this.requested.delete(o)),e.current=t,e.pending=null,this.blobs.delete(n),this.requested.delete(n),this.stats.created+=1;let s=performance.now()-a;return this.stats.worstCreateMs=Math.max(this.stats.worstCreateMs,s),s}desiredLevel(e,t,n,r){if(this.manual!==null){let{keys:t,level:n}=this.manual;return t.has(`${e.cx},${e.cy}`)&&e.keys[n]?n:null}let i=e.current===null?this.lodRadius:this.lodRadius+ar;return Y(e.evictRect,t,n)>=i||r!==null&&!this.inView(e,t,n,r)?null:e.keys.hd&&this.wantsHd(e,t,n,r)?`hd`:e.keys.lod&&Y(this.levelRect(e,`lod`),t,n)<i?`lod`:null}evictIfBeyondRing(e,t,n){e.current!==null&&(this.manual!==null||Y(e.evictRect,t,n)>this.lodRadius+or)&&this.unload(e)}inView(e,t,n,r){if(Y(e.evictRect,t,n)<this.hdRadius)return!0;for(let t of Object.keys(e.keys)){let n=this.extents?.get(e.keys[t]);if(n&&r.sees(this.levelRect(e,t),n[0],n[1],this.cellSize))return!0}return!1}levelRect(e,t){return e.rects[t]??e.rect}onBlob(e){if(e.type===`blob`&&!e.key.startsWith(`collision-`)){if(e.key.startsWith(`array-`)){e.buffer?this.engine.textures.beginLoad(Number(e.key.slice(6)),new Uint8Array(e.buffer)):(this.requested.delete(e.key),console.warn(`[stream] array ${e.key} failed: ${e.error??`unknown`} — will retry`));return}if(e.buffer){this.blobs.set(e.key,new Uint8Array(e.buffer));return}this.requested.delete(e.key),console.warn(`[stream] entry ${e.key} failed: ${e.error??`unknown`} — will retry`)}}pruneStaleBlobs(){for(let e of this.blobs.keys()){let t=this.keyToSlot.get(e);(!t||t.keys[t.pending??`hd`]!==e||t.pending===null)&&(this.blobs.delete(e),this.requested.delete(e))}}releaseTextures(e){for(let t of this.manifest.cells[e].textures??[]){let n=this.arrayUsers.get(t);n&&(n.delete(e),n.size===0&&(this.arrayUsers.delete(t),this.engine.releaseWorldArray(t)&&this.requested.delete(`array-${t}`)))}}requestBlob(e){this.requested.add(e),Xn(this.worker,e,this.manifest.cells[e])}retarget(e,t,n,r,i){let a=0,o=[];for(let s of this.cells.values()){let c=this.desiredLevel(s,e,t,i),l=c===null?void 0:s.keys[c];c===null?(s.pending=null,this.evictIfBeyondRing(s,n,r)):l===void 0||c===s.current?s.pending=null:(s.pending=c,o.push({key:l,level:c,priority:Y(s.evictRect,n,r),slot:s})),s.current!==null&&(a+=1)}return{loaded:a,wanted:o.sort((e,t)=>e.priority-t.priority)}}texturesReady(e){let t=this.manifest.cells[e]?.textures;if(t===void 0)return!0;let n=!0;for(let r of t){if(this.engine.textures.has(r))continue;n=!1;let t=`array-${r}`;if(!this.requested.has(t)){let n=this.manifest.textures[t];if(!n){this.warnedArrays.has(r)||(this.warnedArrays.add(r),console.warn(`[stream] cell ${e} needs ${t}, which the pak does not carry`));continue}this.requested.add(t),Xn(this.worker,t,n)}}return n}unload(e){let t=e.current?e.keys[e.current]:void 0;t!==void 0&&(this.engine.cells.unload(t),this.releaseTextures(t),this.requested.delete(t)),e.current=null,e.pending=null,this.stats.evicted+=1}wantsHd(e,t,n,r){let i=e.current===`hd`?ar:0,a=e.keys.lod,o=a===void 0?void 0:this.manifest.cells[a].geometricError,s=this.manifest.lodPixelThreshold;if(r===null||o===void 0||s===void 0)return Math.hypot(e.centre[0]-t,e.centre[1]-n)<this.hdRadius+i;let c=this.extents?.get(a),l=this.levelRect(e,`lod`),u=c?r.distanceToBox(l,c[0],c[1]):Y(l,t,n);return r.screenError(o,u,i)>s}};function Y(e,t,n){let r=Math.max(e[0]-t,0,t-e[1]),i=Math.max(e[2]-n,0,n-e[3]);return Math.hypot(r,i)}async function mr(e=`/pak`,t={}){let n=await _r(e);Ge(n);let r=typeof e==`string`?{...n.buildTime===void 0?{}:{buildTime:n.buildTime},type:`init`,url:`${e}/world.ospak`}:{blob:await vr(e,`world.ospak`),type:`init`},i=t.createWorker?t.createWorker():nr();return i.addEventListener(`message`,e=>{let t=e.data;t.type===`blob`&&t.cached===!0&&Yn.recordCacheHit(t.wire??0)}),await new Promise((e,t)=>{i.addEventListener(`message`,n=>{n.data.type===`ready`&&(n.data.error?t(Error(n.data.error)):e())},{once:!0}),i.postMessage(r)}),{manifest:n,worker:i}}function hr(e,t){let n=We(t).filter(t=>!e.features.has(t));if(n.length>0)throw Error(`this world's textures need GPU feature(s) this device does not have: ${n.join(`, `)}. The format was chosen when the pak was built and cannot be changed at runtime — build the world for this device (opensa-pack --rgba8) or run it on a GPU that carries the feature.`)}async function gr(e,t=`/pak`,n={},r={},i){let{manifest:a,worker:o}=i??await mr(t,r);hr(e.device,a),e.setUvAnimations(a.uvAnimations??[]),e.textures.setMissingLayers(a.missingLayers??[]);let s=Object.values(a.cells).every(e=>e.textures!==void 0)?[]:Object.entries(a.textures);await new Promise(t=>{let n=s.length;if(n===0){t();return}let r=i=>{let a=i.data;a.type!==`blob`||!a.key.startsWith(`array-`)||!a.buffer||(e.textures.load(Number(a.key.replace(`array-`,``)),new Uint8Array(a.buffer)),--n,n===0&&(o.removeEventListener(`message`,r),t()))};o.addEventListener(`message`,r);for(let[e,t]of s)Xn(o,e,t)});let c=a.cellSize??250,l=1/0,u=-1/0,d=1/0,f=-1/0;for(let e of Object.keys(a.cells)){let[t,n]=e.split(`,`).map(Number),r=(t+.5)*c,i=-(n+.5)*c;l=Math.min(l,r),u=Math.max(u,r),d=Math.min(d,i),f=Math.max(f,i)}let p=new pr(e,a,o,n);return{...a.buildTime===void 0?{}:{buildTime:a.buildTime},cellSize:c,center:[(l+u)/2,0,(d+f)/2],...a.collision!==void 0&&a.collisionCellSize!==void 0?{collision:new Qn(a,o)}:{},...a.districts===void 0?{}:{districts:a.districts},...a.water===void 0?{}:{water:a.water},dispose:()=>p.dispose(),driver:p,radius:Math.max((u-l)/2,(f-d)/2,400)}}async function _r(e){if(typeof e!=`string`)return JSON.parse(await(await vr(e,`manifest.json`)).text());let t=await fetch(`${e}/manifest.json`),n=t.ok?await t.text():``;if(!t.ok||n.trimStart().startsWith(`<`))throw Error(`no pak at ${e}/manifest.json — point the dev server's public dir at an opensa-pack output (the pmb 'opensa' target), or pass ?src=<dir> for one served elsewhere`);return JSON.parse(n)}async function vr(e,t){let n=await e.open(t);if(!n)throw Error(`no pak ${t} in the picked folder — pick the game dir (build/<game>/opensa: self-contained, pak/ inside), or reconvert the install first`);return n}var yr=[{kind:`rgb`,name:`amb`},{kind:`rgb`,name:`ambObj`},{kind:`rgb`,name:`dir`},{kind:`rgb`,name:`skyTop`},{kind:`rgb`,name:`skyBot`},{kind:`rgb`,name:`sunCore`},{kind:`rgb`,name:`sunCorona`},{kind:`float`,name:`sunSize`},{kind:`float`,name:`spriteSize`},{kind:`float`,name:`spriteBright`},{kind:`int`,name:`shadow`},{kind:`int`,name:`lightShadow`},{kind:`int`,name:`poleShadow`},{kind:`float`,name:`farClip`},{kind:`float`,name:`fogStart`},{kind:`float`,name:`lightOnGround`},{kind:`rgb`,name:`lowClouds`},{kind:`rgb`,name:`bottomClouds`},{kind:`rgba`,name:`water`},{kind:`int`,name:`alpha1`},{kind:`rgb`,name:`rgb1`},{kind:`int`,name:`alpha2`},{kind:`rgb`,name:`rgb2`},{kind:`int`,name:`cloudAlpha`},{kind:`int`,name:`intensityLimit`},{kind:`int`,name:`waterFogAlpha`},{kind:`float`,name:`dirMult`}],X=[`EXTRASUNNY_LA`,`SUNNY_LA`,`EXTRASUNNY_SMOG_LA`,`SUNNY_SMOG_LA`,`CLOUDY_LA`,`SUNNY_SF`,`EXTRASUNNY_SF`,`CLOUDY_SF`,`RAINY_SF`,`FOGGY_SF`,`SUNNY_VEGAS`,`EXTRASUNNY_VEGAS`,`CLOUDY_VEGAS`,`EXTRASUNNY_COUNTRYSIDE`,`SUNNY_COUNTRYSIDE`,`CLOUDY_COUNTRYSIDE`,`RAINY_COUNTRYSIDE`,`EXTRASUNNY_DESERT`,`SUNNY_DESERT`,`SANDSTORM_DESERT`,`UNDERWATER`,`EXTRACOLOURS_1`,`EXTRACOLOURS_2`],Z=8,br={float:1,int:1,rgb:3,rgba:4};function xr(e){let t=[];for(let n=0;n<21;n+=1)t.push(...Tr(e.slice(n*Z,n*Z+Z)));return t}function Sr(e){if(e.length===504||e.length===X.length*24)return e;if(e.length===X.length*Z)return xr(e);throw Error(`timecyc: ${e.length} rows — expected 24h (504 or ${X.length*24}) or vanilla 8-keyframe (${X.length*Z})`)}function Cr(e){let t=[];for(let n of e.split(/\r?\n/)){let e=n.trim();e===``||e.startsWith(`//`)||t.push(Dr(e.split(/\s+/)))}return t}function Q(e,t,n){let r=[],i=0;for(let a of yr){let o=br[a.kind];for(let s=0;s<o;s+=1){let o=(1-n)*e[i+s]+n*t[i+s];r.push(a.kind===`float`?Math.round(o*100)/100:Math.trunc(o))}i+=o}return r}function wr(e){if(e===void 0)return null;let t=Number(e);return Number.isFinite(t)?t:null}function Tr(e){return[e[0],Q(e[0],e[1],1/5),Q(e[0],e[1],2/5),Q(e[0],e[1],3/5),Q(e[0],e[1],4/5),e[1],e[2],e[3],Q(e[3],e[4],1/5),Q(e[3],e[4],2/5),Q(e[3],e[4],3/5),Q(e[3],e[4],4/5),e[4],Q(e[4],e[5],1/7),Q(e[4],e[5],2/7),Q(e[4],e[5],3/7),Q(e[4],e[5],4/7),Q(e[4],e[5],5/7),Q(e[4],e[5],6/7),e[5],e[6],Q(e[6],e[7],1/2),e[7],Q(e[7],e[0],1/2)]}function Er(e,t,n){if(n===`int`){let n=$(e[t]);return n===null?{next:t+t,values:[-1e3]}:{next:t+1,values:[n]}}if(n===`float`){let n=wr(e[t]);return n===null?{next:t+t,values:[1]}:{next:t+1,values:[n]}}if(n===`rgb`){let n=[$(e[t]),$(e[t+1]),$(e[t+2])];return n.some(e=>e===null)?{next:t+3,values:[-100,-100,-100]}:{next:t+3,values:n}}let r=[$(e[t]),$(e[t+1]),$(e[t+2]),$(e[t+3])];return r.some(e=>e===null)?{next:t,values:[-100,-100,-100,-100]}:{next:t+4,values:r}}function Dr(e){let t=[],n=0;for(let r of yr){let{next:i,values:a}=Er(e,n,r.kind);t.push(...a),n=i}return t}function $(e){return e!==void 0&&/^[+-]?\d+$/.test(e)?Number(e):null}function Or(e){let t=[];for(let n=0;n<21;n+=1)t.push({hours:e.slice(n*24,n*24+24),name:X[n]});return{weathers:t}}function kr(e,t,n,r,i){if(i<=0||t===n)return jr(Ar(e,t,r));if(i>=1)return jr(Ar(e,n,r));let a=Ar(e,t,r),o=Ar(e,n,r);return jr(a.map((e,t)=>e+(o[t]-e)*i))}function Ar(e,t,n){let r=e.weathers[t]??e.weathers[0],i=(n%24+24)%24,a=Math.floor(i),o=(a+1)%24,s=i-a,c=r.hours[a],l=r.hours[o];return c.map((e,t)=>e+(l[t]-e)*s)}function jr(e){let t=0,n=()=>{let n=[e[t],e[t+1],e[t+2]];return t+=3,n},r=()=>{let n=[e[t],e[t+1],e[t+2],e[t+3]];return t+=4,n},i=()=>{let n=e[t];return t+=1,n},a=n(),o=n(),s=n(),c=n(),l=n(),u=n(),d=n(),f=i(),p=i(),m=i(),h=i(),g=i(),_=i(),v=i(),y=i(),b=i(),x=n(),S=n(),C=r(),w=i(),T=n(),E=i(),D=n(),O=i(),k=i(),A=i();return{alpha1:w,alpha2:E,amb:a,ambObj:o,bottomClouds:S,cloudAlpha:O,dir:s,dirMult:i(),farClip:v,fogStart:y,intensityLimit:k,lightOnGround:b,lightShadow:g,lowClouds:x,poleShadow:_,rgb1:T,rgb2:D,shadow:h,skyBot:l,skyTop:c,spriteBright:m,spriteSize:p,sunCore:u,sunCorona:d,sunSize:f,water:C,waterFogAlpha:A}}var Mr=[.3,.32,.4],Nr=1e6;function Pr(e,t){let n=Array.from({length:Math.max(1,t)},()=>[]);for(let t of e)n[t.materialIndex<n.length?t.materialIndex:0].push(t);return n}function Fr(e,t){if(e.texture?.name.toLowerCase()!==`white`||!t.prelitColors)return!1;for(let e=3;e<t.prelitColors.length;e+=4)if(t.prelitColors[e]<255)return!0;return!1}function Ir(e){let t=[];for(let n of e.atomics){let r=e.geometries[n.geometryIndex];if(!r)continue;Rr(r.positions);let i=r.materials.some(e=>Fr(e,r));t.push({color:r.prelitColors?Hr(r.prelitColors,i):null,frameIndex:n.frameIndex,geometryIndex:n.geometryIndex,nightColor:r.nightColors?Hr(r.nightColors,!1).array:null,normals:Gr(r),parts:Ur(r),positions:r.positions,sphere:zr(r.positions),sway:r.prelitColors?Wr(r.prelitColors):null,uv:r.uvLayers.length>0?r.uvLayers[0]:null})}return t}function Lr(e,t,n){let r=new Set;for(let t=0;t<e.length/3;t+=1){let n=e[t*3],i=e[t*3+1],a=e[t*3+2],o=n*n+i*i+a*a;(!Number.isFinite(o)||o<1e-8)&&r.add(t)}if(r.size!==0){for(let i of n){if(!r.has(i.a)&&!r.has(i.b)&&!r.has(i.c))continue;let n=Vr(t,i.a,i.b,i.c);if(n)for(let t of[i.a,i.b,i.c])r.delete(t)&&(e[t*3]=n[0],e[t*3+1]=n[1],e[t*3+2]=n[2])}for(let t of r)e[t*3]=0,e[t*3+1]=0,e[t*3+2]=1}}function Rr(e){let t=[],n=0,r=0,i=0,a=0;for(let o=0;o<e.length/3;o+=1){let s=e[o*3],c=e[o*3+1],l=e[o*3+2];Math.abs(s)>Nr||Math.abs(c)>Nr||Math.abs(l)>Nr||!Number.isFinite(s+c+l)?t.push(o):(n+=s,r+=c,i+=l,a+=1)}if(t.length===0)return;let o=a>0?n/a:0,s=a>0?r/a:0,c=a>0?i/a:0;for(let n of t)e[n*3]=o,e[n*3+1]=s,e[n*3+2]=c}function zr(e){let t=1/0,n=1/0,r=1/0,i=-1/0,a=-1/0,o=-1/0;for(let s=0;s<e.length;s+=3)t=Math.min(t,e[s]),n=Math.min(n,e[s+1]),r=Math.min(r,e[s+2]),i=Math.max(i,e[s]),a=Math.max(a,e[s+1]),o=Math.max(o,e[s+2]);if(e.length===0)return{center:[0,0,0],radius:0};let s=(t+i)/2,c=(n+a)/2,l=(r+o)/2,u=0;for(let t=0;t<e.length;t+=3){let n=e[t]-s,r=e[t+1]-c,i=e[t+2]-l;u=Math.max(u,n*n+r*r+i*i)}return{center:[s,c,l],radius:Math.sqrt(u)}}function Br(e,t){let n=new Float32Array(e.length);for(let r of t){let t=r.a*3,i=r.b*3,a=r.c*3,o=e[a]-e[i],s=e[a+1]-e[i+1],c=e[a+2]-e[i+2],l=e[t]-e[i],u=e[t+1]-e[i+1],d=e[t+2]-e[i+2],f=s*d-c*u,p=c*l-o*d,m=o*u-s*l;for(let e of[t,i,a])n[e]+=f,n[e+1]+=p,n[e+2]+=m}for(let e=0;e<n.length;e+=3){let t=Math.hypot(n[e],n[e+1],n[e+2]);t>0&&(n[e]/=t,n[e+1]/=t,n[e+2]/=t)}return n}function Vr(e,t,n,r){let i=e[n*3]-e[t*3],a=e[n*3+1]-e[t*3+1],o=e[n*3+2]-e[t*3+2],s=e[r*3]-e[t*3],c=e[r*3+1]-e[t*3+1],l=e[r*3+2]-e[t*3+2],u=a*l-o*c,d=o*s-i*l,f=i*c-a*s,p=Math.hypot(u,d,f);return p<1e-6?null:[u/p,d/p,f/p]}function Hr(e,t){if(t){let t=new Float32Array(e.length);for(let n=0;n<e.length;n+=1)t[n]=e[n]/255;return{array:t,itemSize:4}}let n=new Float32Array(e.length/4*3);for(let t=0,r=0;t<e.length;t+=4,r+=3)n[r]=e[t]/255,n[r+1]=e[t+1]/255,n[r+2]=e[t+2]/255;return{array:n,itemSize:3}}function Ur(e){let t=e.positions.length/3,n=[];return Pr(e.triangles,e.materials.length).forEach((e,r)=>{if(e.length===0)return;let i=t>65536?new Uint32Array(e.length*3):new Uint16Array(e.length*3);e.forEach((e,t)=>{i[t*3]=e.a,i[t*3+1]=e.b,i[t*3+2]=e.c}),n.push({index:i,materialIndex:r})}),n}function Wr(e){let t=255;for(let n=3;n<e.length;n+=4)e[n]<t&&(t=e[n]);if(t===255)return null;let n=new Float32Array(e.length/4);for(let t=3,r=0;t<e.length;t+=4,r+=1)n[r]=(255-e[t])/255;return{minAlpha:t,weights:n}}function Gr(e){let t=e.normals??Br(e.positions,e.triangles);return Lr(t,e.positions,e.triangles),t}var Kr=new Set([n.EXTENSION,n.STRUCT]);function qr(e){let t=new s(e),n=Zr(t);if(n){let e=$r(t,n);if(e.length>0)return{textures:e}}let r=ni(t);if(r.length>0)return{textures:r};if(n)return{textures:[]};throw Error(`Not a TXD: no TexDictionary (0x16) chunk and no recoverable TEXTURE_NATIVE chunks`)}function Jr(e,n,r){switch(e){case o.DXT1:return`dxt1`;case o.DXT2:case o.DXT3:return`dxt3`;case o.DXT4:case o.DXT5:return`dxt5`;default:break}if(n&t.PAL8)return`rgba8888`;if(n&t.PAL4)return null;let i=n&t.PIXEL_FORMAT_MASK;return r===32||i===t.C8888||i===t.C888||i===t.C565||i===t.C1555||i===t.C4444?`rgba8888`:null}function Yr(e,n){let r=new Uint8Array(e.length*2);for(let i=0;i<e.length;i+=2){let a=e[i]|e[i+1]<<8,o=i*2;n===t.C565?(r[o]=Math.round((a>>11&31)*(255/31)),r[o+1]=Math.round((a>>5&63)*(255/63)),r[o+2]=Math.round((a&31)*(255/31)),r[o+3]=255):n===t.C1555?(r[o]=Math.round((a>>10&31)*(255/31)),r[o+1]=Math.round((a>>5&31)*(255/31)),r[o+2]=Math.round((a&31)*(255/31)),r[o+3]=a&32768?255:0):(r[o]=(a>>8&15)*17,r[o+1]=(a>>4&15)*17,r[o+2]=(a&15)*17,r[o+3]=(a>>12&15)*17)}return r}function Xr(e,t){let n=new Uint8Array(e.length*4);for(let r=0;r<e.length;r+=1){let i=e[r]*4;n[r*4+0]=t[i+2],n[r*4+1]=t[i+1],n[r*4+2]=t[i+0],n[r*4+3]=t[i+3]}return n}function Zr(t){for(t.seek(0);t.position+12<=t.length;){let r=t.position,i=e(t);if(i.type===n.TEXTURE_DICTIONARY)return i;t.seek(i.end>r?i.end:r+12)}return null}function Qr(e){let t=e=>e>0&&e<=4096&&(e&e-1)==0;if(!t(e.width)||!t(e.height)||e.name.length===0)return!1;for(let t of e.name){let e=t.charCodeAt(0);if(e<32||e>126)return!1}return!0}function $r(e,t){let i=r(e,t.dataStart,t.end,n.STRUCT),o=[];if(a(e,t.dataStart,t.end,t=>{if(t.type===n.TEXTURE_NATIVE){let n=ei(e,t);n&&o.push(n)}}),i){e.seek(i.dataStart);let n=e.u16();if(o.length<n)return ri(e,t,i.end,n)}return o}function ei(e,i){let a=r(e,i.dataStart,i.end,n.STRUCT);if(!a)return null;e.seek(a.dataStart),e.u32(),e.u32();let o=e.string(32),s=e.string(32),c=e.u32(),l=e.u32(),u=e.u16(),d=e.u16(),f=e.u8(),p=e.u8();e.u8();let m=(e.u8()&1)!=0,h=Jr(l,c,f);if(!h)return null;let g=null;c&t.PAL8&&(g=e.bytes(256*4));let _=c&t.PIXEL_FORMAT_MASK,v=ti(e,u,d,p,h,g,f,_,m);return v.length===0?null:{format:g?`rgba8888`:h,hasAlpha:m,height:d,maskName:s,mipmaps:v,name:o,width:u}}function ti(e,t,n,r,i,a,o,s,c){let l=[],u=t,d=n;for(let t=0;t<r;t+=1){let t=e.u32(),n=e.bytes(t);if(n.length>0){let e=n;a?e=Xr(n,a):i===`rgba8888`&&(e=o===16?Yr(n,s):ii(n,c)),l.push({data:e,height:Math.max(1,d),width:Math.max(1,u)})}u=Math.max(1,u>>1),d=Math.max(1,d>>1)}return l}function ni(e){let t=[],r=new Set;for(let i=0;i+16<=e.length;i+=1){if(e.seek(i),e.u32()!==n.TEXTURE_NATIVE)continue;let a=e.u32(),o=e.u32();if((o&65535)!=65535||(e.seek(i+12),e.u32()!==n.STRUCT))continue;let s=ei(e,{dataStart:i+12,end:Math.min(i+12+a,e.length),size:a,type:n.TEXTURE_NATIVE,version:o});s&&Qr(s)&&!r.has(s.name.toLowerCase())&&(r.add(s.name.toLowerCase()),t.push(s))}return t}function ri(e,t,r,a){let o=[];for(let s of i(e,r,t.end,a,n.TEXTURE_NATIVE,Kr)){let t=ei(e,s);t&&o.push(t)}return o}function ii(e,t){let n=new Uint8Array(e.length);for(let r=0;r<e.length;r+=4)n[r+0]=e[r+2],n[r+1]=e[r+1],n[r+2]=e[r+0],n[r+3]=t?e[r+3]:255;return n}function ai(e,t,n,r){let i=new Uint8Array(n*r*4),a=e===`dxt1`?8:16,o=Math.max(1,Math.ceil(n/4)),s=Math.max(1,Math.ceil(r/4)),c=0;for(let l=0;l<s;l+=1)for(let s=0;s<o;s+=1)li(e,t,c,s*4,l*4,n,r,i),c+=a;return i}function oi(e){return[Math.round((e>>11&31)*(255/31)),Math.round((e>>5&63)*(255/63)),Math.round((e&31)*(255/31))]}function si(e,t,n){let[r,i,a]=oi(e),[o,s,c]=oi(t),l=!n||e>t;return[[r,i,a,255],[o,s,c,255],l?[Math.round((2*r+o)/3),Math.round((2*i+s)/3),Math.round((2*a+c)/3),255]:[Math.round((r+o)/2),Math.round((i+s)/2),Math.round((a+c)/2),255],l?[Math.round((r+2*o)/3),Math.round((i+2*s)/3),Math.round((a+2*c)/3),255]:[0,0,0,0]]}function ci(e,t,n){if(e===`dxt3`){let e=[];for(let r=0;r<16;r+=1){let i=t[n+(r>>1)]>>(r&1)*4&15;e.push(i*17)}return e}let r=t[n],i=t[n+1],a=[r,i,0,0,0,0,0,0];if(r>i)for(let e=1;e<=6;e+=1)a[e+1]=Math.round(((7-e)*r+e*i)/7);else{for(let e=1;e<=4;e+=1)a[e+1]=Math.round(((5-e)*r+e*i)/5);a[6]=0,a[7]=255}let o=0;for(let e=0;e<6;e+=1)o+=t[n+2+e]*2**(8*e);let s=[];for(let e=0;e<16;e+=1)s.push(a[Math.floor(o/2**(3*e))&7]);return s}function li(e,t,n,r,i,a,o,s){let c=e===`dxt1`?null:ci(e,t,n),l=e===`dxt1`?n:n+8,u=si(t[l]|t[l+1]<<8,t[l+2]|t[l+3]<<8,e===`dxt1`),d=t[l+4]|t[l+5]<<8|t[l+6]<<16|t[l+7]<<24;for(let e=0;e<16;e+=1){let t=r+e%4,n=i+Math.floor(e/4);if(t>=a||n>=o)continue;let l=u[d>>>e*2&3],f=(n*a+t)*4;s[f]=l[0],s[f+1]=l[1],s[f+2]=l[2],s[f+3]=c?c[e]:l[3]}}export{Be as A,I as B,He as C,Le as D,Ie as E,De as F,ee as G,ie as H,Ce as I,D as J,w as K,we as L,je as M,ke as N,Re as O,Oe as P,Te as R,nt as S,R as T,M as U,se as V,te as W,k as X,O as Y,c as Z,Xe as _,Fr as a,$e as b,kr as c,Cr as d,mr as f,qe as g,Hn as h,Pr as i,Ve as j,ze as k,X as l,Yn as m,qr as n,Ir as o,gr as p,E as q,Mr as r,Or as s,ai as t,Sr as u,Ze as v,Pe as w,tt as x,Qe as y,ve as z};